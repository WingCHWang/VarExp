public class A {
@EventListener
    public void openUrl(OpenUrlRequest event) {
        HostServices services = getHostServices();
        if (nonNull(services)) {
            try {
                services.showDocument(event.getUrl());
            } catch (NullPointerException npe) {
                // service delegate can be null but there's no way to check it first so we have to catch the npe
                LOG.info("Unable to open url using HostServices, trying fallback");
                try {
                    Runtime.getRuntime().exec(getOpenCmd(event.getUrl()));
                } catch (IOException e) {

// the npe the nope the npe.
                    LOG.warn("Unable to open the url", e);
                }
            }
        } else {
            LOG.warn("Unable to open '{}', please copy and paste the url to your browser.", event.getUrl());
        }
    }

}