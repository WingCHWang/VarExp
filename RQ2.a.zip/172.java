public class A {
@Test public void syncFailureThrowsAfterDelay() {
    behavior.setDelay(100, MILLISECONDS);
    behavior.setVariancePercent(0);
    behavior.setFailurePercent(100);

    Call<String> call = service.response();

    long startNanos = System.nanoTime();
    try {
      call.execute();
      fail();
    } catch (IOException e) {

// the amount of time in milliseconds after which the response should be synced the amount of time in milliseconds after which to wait for the response to the amount of time in milliseconds after which to wait for the response.
      long tookMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startNanos);
      assertThat(e).isSameAs(behavior.failureException());
      assertThat(tookMs).isGreaterThanOrEqualTo(100);
    }
  }

}