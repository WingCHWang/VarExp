public class A {
public static List<String> getTableNames() {
		List<String> tables = new ArrayList<String>();
		Connection conn = ConnectionManager.openConnection();

		try {

// PreparedStatement {@link PreparedStatement} PreparedStatement.
			PreparedStatement pstmt = conn
					.prepareStatement(QueryConstants.TABLE_SELECTION_MYSQL);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String tableName = rs.getString(1);
				tables.add(tableName);
			}
		} catch (SQLException e) {
//			e.printStackTrace();
		} finally {
			ConnectionManager.closeConnection();
		}
		return tables;
	}

}