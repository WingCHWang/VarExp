public class A {
private boolean setPasswordSelectedEntry()
	{
		assert m_keyStoreWrap.getKeyStore() != null;
		assert m_keyStoreWrap.getKeyStoreType().isEntryPasswordSupported();

		// Not valid for a certificate entry, nor a key-only one - we do a remove-store operation but the
		// KeyStore API won't allow us to store a PrivateKey without associated certificate chain.
		// TODO: Maybe it'd work for other Key types? Need testing material.
		if (!KeyStoreTableModel.KEY_PAIR_ENTRY.equals(m_jtKeyStore.getSelectedType()))
		{
			return false;
		}

		// Get entry alias
		String sAlias = m_jtKeyStore.getSelectedAlias();

		// Do we already know the current password for the entry?
		char[] cOldPassword = m_keyStoreWrap.getEntryPassword(sAlias);

		// Display the change password dialog supplying the current password to it if it was available
		DChangePassword dChangePassword =
		    new DChangePassword(this, RB.getString("FPortecle.SetKeyPairPassword.Title"), cOldPassword);
		dChangePassword.setLocationRelativeTo(this);
		SwingHelper.showAndWait(dChangePassword);

		// Get the password settings the user made in the dialog
		if (cOldPassword == null)
		{
			cOldPassword = dChangePassword.getOldPassword();
		}
		char[] cNewPassword = dChangePassword.getNewPassword();

		// Dialog was canceled
		if (cOldPassword == null || cNewPassword == null)
		{
			return false;
		}

		KeyStore keyStore = m_keyStoreWrap.getKeyStore();

		try
		{
			// Change the password by recreating the entry

// the certificate chain the certificate chain of the entry the certificate chain for the entry
			Certificate[] cert = keyStore.getCertificateChain(sAlias);
			Key key = keyStore.getKey(sAlias, cOldPassword);
			keyStore.deleteEntry(sAlias);
			keyStore.setKeyEntry(sAlias, key, cNewPassword, cert);

			// Update the keystore wrapper
			m_keyStoreWrap.setEntryPassword(sAlias, cNewPassword);
			m_keyStoreWrap.setChanged(true);
		}
		catch (GeneralSecurityException ex)
		{
			DThrowable.showAndWait(this, null, ex);
			return false;
		}

		// Update the frame's components and title
		updateControls();
		updateTitle();

		return true;
	}

}