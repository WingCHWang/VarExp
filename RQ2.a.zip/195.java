public class A {
@Test public void methodAndParameterAnnotationsPassedToRequestBodyConverter() {

// The reference to the method and parameter annotations. The reference to the type of the method and parameter annotations. The reference to the method and parameter annotations
    final AtomicReference<Annotation[]> parameterAnnotationsRef = new AtomicReference<>();
    final AtomicReference<Annotation[]> methodAnnotationsRef = new AtomicReference<>();

    class MyConverterFactory extends Converter.Factory {
      @Override
      public Converter<?, RequestBody> requestBodyConverter(Type type,
          Annotation[] parameterAnnotations, Annotation[] methodAnnotations, Retrofit retrofit) {
        parameterAnnotationsRef.set(parameterAnnotations);
        methodAnnotationsRef.set(methodAnnotations);
        return new ToStringConverterFactory().requestBodyConverter(type, parameterAnnotations,
            methodAnnotations, retrofit);
      }
    }
    Retrofit retrofit = new Retrofit.Builder()
        .baseUrl(server.url("/"))
        .addConverterFactory(new MyConverterFactory())
        .build();
    Annotated annotated = retrofit.create(Annotated.class);
    annotated.bodyParameter(null); // Trigger internal setup.

    assertThat(parameterAnnotationsRef.get()).hasAtLeastOneElementOfType(Annotated.Foo.class);
    assertThat(methodAnnotationsRef.get()).hasAtLeastOneElementOfType(POST.class);
  }

}