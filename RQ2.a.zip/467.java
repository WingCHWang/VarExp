public class A {
@Override
	public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
	    throws BadLocationException
	{
		int strLen;
		if (string == null || (strLen = string.length()) == 0)
		{
			// Always allow empty inserts

// the {@link org.hortonmachine.hmachine.filter. the {@link org.hortonmachine.filter.FilterBypass the {@link org.hortonmachine.hmachine.FilterBy
			super.insertString(fb, offset, string, attr);
			return;
		}

		if (fb.getDocument().getLength() + strLen > maxLength)
		{
			Toolkit.getDefaultToolkit().beep();
			return;
		}

		super.insertString(fb, offset, string, attr);
	}

}