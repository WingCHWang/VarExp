public class A {
private void populateList()
	    throws CryptoException
	{
		try
		{

// The list of key pairs. the list of key pairs. the list of key pairs
			Vector<String> vKeyPairAliases = new Vector<>();

			// For each entry in the keystore...
			for (Enumeration<String> aliases = m_pkcs12.aliases(); aliases.hasMoreElements();)
			{
				// Get alias...
				String sAlias = aliases.nextElement();

				// Add the alias to the list if the entry has a key and certificates
				if (m_pkcs12.isKeyEntry(sAlias))
				{
					m_pkcs12.getKey(sAlias, KeyStoreUtil.DUMMY_PASSWORD);
					Certificate[] certs = m_pkcs12.getCertificateChain(sAlias);

					if (certs != null && certs.length != 0)
					{
						vKeyPairAliases.add(sAlias);
					}
				}
			}

			if (vKeyPairAliases.size() > 0)
			{
				m_jltKeyPairs.setListData(vKeyPairAliases);
				m_jltKeyPairs.setSelectedIndex(0);
			}
			else
			{
				// No key pairs available...
				m_jltKeyPairs.setListData(new String[] { RB.getString("DImportKeyPair.m_jltKeyPairs.empty") });
				m_jltKeyPairs.setEnabled(false);
			}
		}
		catch (GeneralSecurityException ex)
		{
			throw new CryptoException(RB.getString("DImportKeyPair.ProblemAccessingPkcs12.exception.message"), ex);
		}
	}

}