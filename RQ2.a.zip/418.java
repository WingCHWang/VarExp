public class A {
@Override
		public Icon getIcon(File f)
		{
			// The f.isDirectory() check is superfluous here, but it reportedly avoids some odd
			// delays on Windows (sf.net#3129497).
			if (f.isDirectory() || !f.isFile())
			{

// a {@link java.io.File} object. {@inheritDoc} a {@link java.io.File} object
				return super.getIcon(f);
			}

			String fn = f.getName().toLowerCase(Locale.ENGLISH);

			for (String ext : KeyStoreType.getKeyStoreFilenameExtensions())
			{
				if (fn.endsWith("." + ext) || fn.equals("cacerts"))
				{
					return KEYSTORE_ICON;
				}
			}

			for (String ext : CERT_EXTS)
			{
				if (fn.endsWith("." + ext))
				{
					return CERTIFICATE_ICON;
				}
			}

			for (String ext : CSR_EXTS)
			{
				if (fn.endsWith("." + ext))
				{
					return CSR_ICON;
				}
			}

			for (String ext : CRL_EXTS)
			{
				if (fn.endsWith("." + ext))
				{
					return CRL_ICON;
				}
			}

			return super.getIcon(f);
		}

}