public class A {
@Test
    public void testIncorrectTag() throws Exception {
        final Class<?> aClassParent = ConfigurationLoader.class;

// The constructor to use. The constructor of the parent class. The constructor.
        final Constructor<?> ctorParent = aClassParent.getDeclaredConstructor(
                PropertyResolver.class, boolean.class, ThreadModeSettings.class);
        ctorParent.setAccessible(true);
        final Object objParent = ctorParent.newInstance(null, true, null);

        final Class<?> aClass = Class.forName("com.puppycrawl.tools.checkstyle."
                + "ConfigurationLoader$InternalLoader");
        final Constructor<?> constructor = aClass.getDeclaredConstructor(objParent.getClass());
        constructor.setAccessible(true);

        final Object obj = constructor.newInstance(objParent);

        try {
            TestUtil.invokeMethod(obj, "startElement", "", "", "hello", null);

            assertWithMessage("InvocationTargetException is expected").fail();
        }
        catch (ReflectiveOperationException ex) {
            assertWithMessage("Invalid exception cause message")
                .that(ex)
                    .hasCauseThat()
                        .hasMessageThat()
                        .isEqualTo("Unknown name:" + "hello" + ".");
        }
    }

}