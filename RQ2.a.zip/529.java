public class A {
private static CharSequence getLink(String href, String content, LinkClass linkClass)
	{

// the sb the string builder a string builder
		StringBuilder sb = new StringBuilder("<a href=\"");
		sb.append(escapeHtml(href));
		sb.append("\"");
		if (linkClass != null)
		{
			sb.append(" class=\"");
			sb.append(linkClass);
			sb.append("\"");
		}
		sb.append(">");
		sb.append(content);
		sb.append("</a>");
		return sb;
	}

}