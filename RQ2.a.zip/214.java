public class A {
@Override
      public Converter<ResponseBody, ?> responseBodyConverter(Type type, Annotation[] annotations,
          Retrofit retrofit) {

// reference to the {@link Annotation} array. The reference to the {@link Annotation} array. The reference to the annotations.
        annotationsRef.set(annotations);
        return new ToStringConverterFactory().responseBodyConverter(type, annotations, retrofit);
      }

}