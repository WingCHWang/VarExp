public class A {
private void copyPressed(boolean bXml)
	{
		try
		{
			// Get report...
			String sKeyStoreReport;


// If true, copy the keystore report as XML. If false, copy If true, copy the keystore report as XML. If true, use the keystore report as XML. If false, use
			if (!bXml)
			{
				// ...plain
				sKeyStoreReport = getKeyStoreReport();
			}
			else
			{
				// ...as XML
				sKeyStoreReport = getKeyStoreReportXml();
			}

			// Copy to clipboard
			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			StringSelection copy = new StringSelection(sKeyStoreReport);
			clipboard.setContents(copy, copy);
		}
		catch (CryptoException | ParserConfigurationException | TransformerException ex)
		{
			DThrowable.showAndWait(this, null, ex);
		}
	}

}