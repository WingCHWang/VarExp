public class A {
@Test
    public void clearCantMove() {
        SelectionChangedEvent victim = clearSelectionEvent();

// The type of move. The move type. the move type.
        stream(MoveType.values()).forEach(m -> assertFalse(victim.canMove(m)));
    }

}