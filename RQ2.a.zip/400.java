public class A {
private Function<JsonNode, JsonNode> andCliOptionOverrider(
            Function<JsonNode, JsonNode> overrider,
            Function<URL, Optional<JsonNode>> parser,
            BinaryOperator<JsonNode> singleConfigMerger) {

        if (optionMetadata.isEmpty()) {
            return overrider;
        }

        List<OptionSpec<?>> detectedOptions = cli.detectedOptions();
        if (detectedOptions.isEmpty()) {
            return overrider;
        }

        for (OptionSpec<?> cliOpt : detectedOptions) {


// The option metadata. The option metadata The option metadata to override
            OptionMetadata omd = findMetadata(cliOpt);

            if (omd == null) {
                continue;
            }

            // config decorators are loaded first, and then can be overridden from options...
            for (OptionRefWithConfig decorator : optionDecorators) {
                if (decorator.getOptionName().equals(omd.getName())) {
                    overrider = overrider.andThen(new InPlaceResourceOverrider(decorator.getConfigResource().getUrl(),
                            parser, singleConfigMerger));
                }
            }

            for (OptionRefWithConfigPath pathDecorator : optionPathDecorators) {
                if (pathDecorator.getOptionName().equals(omd.getName())) {
                    String cliValue = cli.optionString(omd.getName());
                    overrider = overrider.andThen(new InPlaceMapOverrider(
                            singletonMap(pathDecorator.getConfigPath(), cliValue)
                    ));
                }
            }
        }

        return overrider;
    }

}