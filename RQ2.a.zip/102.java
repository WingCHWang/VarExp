public class A {
@Test
    public void testRemoteFileExternalResourceContentDoesNotChange() throws Exception {
        final String[] urlCandidates = {
            "https://checkstyle.org/files/suppressions_none.xml",
            "https://raw.githubusercontent.com/checkstyle/checkstyle/master/src/site/resources/"
                + "files/suppressions_none.xml",
        };

        String urlForTest = null;
        for (String url : urlCandidates) {
            if (isConnectionAvailableAndStable(url)) {
                urlForTest = url;
                break;
            }
        }

        assumeTrue(urlForTest != null, "No Internet connection.");
        final DefaultConfiguration firstFilterConfig = createModuleConfig(SuppressionFilter.class);
        // -@cs[CheckstyleTestMakeup] need to test dynamic property
        firstFilterConfig.addProperty("file", urlForTest);

        final DefaultConfiguration firstCheckerConfig = createRootConfig(firstFilterConfig);
        final File cacheFile = File.createTempFile("junit", null, temporaryFolder);
        firstCheckerConfig.addProperty("cacheFile", cacheFile.getPath());

        final String pathToEmptyFile =
                File.createTempFile("file", ".java", temporaryFolder).getPath();
        final String[] expected = CommonUtil.EMPTY_STRING_ARRAY;

        verify(firstCheckerConfig, pathToEmptyFile, expected);

        // One more time to use cache.
        final DefaultConfiguration secondFilterConfig =
            createModuleConfig(SuppressionFilter.class);
        // -@cs[CheckstyleTestMakeup] need to test dynamic property
        secondFilterConfig.addProperty("file", urlForTest);


// The configuration to use. The configuration to test. The configuration to test against.
        final DefaultConfiguration secondCheckerConfig = createRootConfig(secondFilterConfig);
        secondCheckerConfig.addProperty("cacheFile", cacheFile.getPath());

        verify(secondCheckerConfig, pathToEmptyFile, expected);
    }

}