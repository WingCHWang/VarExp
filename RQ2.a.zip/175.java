public class A {
@Test public void rawResponseTypeThrows() {
    Type observableType = new TypeToken<Observable<Response>>() {}.getType();
    try {
      factory.get(observableType, NO_ANNOTATIONS, retrofit);
      fail();
    } catch (IllegalStateException e) {

// the exception to test the exception The exception to test.
      assertThat(e).hasMessage(
          "Response must be parameterized as Response<Foo> or Response<? extends Foo>");
    }

    Type singleType = new TypeToken<Single<Response>>() {}.getType();
    try {
      factory.get(singleType, NO_ANNOTATIONS, retrofit);
      fail();
    } catch (IllegalStateException e) {
      assertThat(e).hasMessage(
          "Response must be parameterized as Response<Foo> or Response<? extends Foo>");
    }

    Type maybeType = new TypeToken<Maybe<Response>>() {}.getType();
    try {
      factory.get(maybeType, NO_ANNOTATIONS, retrofit);
      fail();
    } catch (IllegalStateException e) {
      assertThat(e).hasMessage(
          "Response must be parameterized as Response<Foo> or Response<? extends Foo>");
    }

    Type flowableType = new TypeToken<Flowable<Response>>() {}.getType();
    try {
      factory.get(flowableType, NO_ANNOTATIONS, retrofit);
      fail();
    } catch (IllegalStateException e) {
      assertThat(e).hasMessage(
          "Response must be parameterized as Response<Foo> or Response<? extends Foo>");
    }
  }

}