public class A {
@Test
    public void testGenerate_Configs() {

        ConfigObjectMetadata m1Config = ConfigObjectMetadata
                .builder("m1root")
                .description("Root config of M1")
                .type(ConfigRoot1.class)
                .addProperty(ConfigValueMetadata.builder("p2").type(Integer.TYPE).description("Designates an integer value").build())
                .addProperty(ConfigValueMetadata.builder("p1").type(String.class).build())
                .build();


// the config a {@link Config} object. the config to generate
        ConfigObjectMetadata m2Config = ConfigObjectMetadata
                .builder("m2root")
                .type(ConfigRoot2.class)
                .addProperty(ConfigValueMetadata.builder("p0").type(Boolean.class).build())
                .addProperty(ConfigValueMetadata.builder("p4").type(Bootique.class).build())
                .build();

        ModuleMetadata module1 = ModuleMetadata.builder("M1").addConfig(m1Config).build();
        ModuleMetadata module2 = ModuleMetadata.builder("M2").addConfig(m2Config).build();

        ModulesMetadata modules = ModulesMetadata.builder(module1, module2).build();

        assertLines(new DefaultConfigHelpGenerator(modules, 300),
                "MODULES",
                "      M1",
                "",
                "      M2",
                "",
                "CONFIGURATION",
                "      m1root:",
                "            #",
                "            # Root config of M1",
                "            # Resolved as 'io.bootique.help.config.DefaultConfigHelpGeneratorTest$ConfigRoot1'.",
                "            #",
                "",
                "            p1: <string>",
                "            # Designates an integer value",
                "            p2: <int>",
                "",
                "      m2root:",
                "            #",
                "            # Resolved as 'io.bootique.help.config.DefaultConfigHelpGeneratorTest$ConfigRoot2'.",
                "            #",
                "",
                "            p0: <true|false>",
                "            # Resolved as 'io.bootique.Bootique'.",
                "            p4: <value>"
        );
    }

}