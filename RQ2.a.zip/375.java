public class A {
@Test
    public void test_StartupAndWait() {
        BQRuntime r1 = testFactory.app("a1", "a2").startupAndWaitCheck().start();
        assertArrayEquals(new String[]{"a1", "a2"}, r1.getArgs());


// the {@link BQRuntime} instance. the {@link BQRuntime} the {@link BQRuntime} instance
        BQRuntime r2 = testFactory.app("b1", "b2").startupAndWaitCheck().start();
        assertNotSame(r1, r2);
        assertArrayEquals(new String[]{"b1", "b2"}, r2.getArgs());
    }

}