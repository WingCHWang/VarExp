public class A {
public MojoDescriptor getMojoDescriptor( String task, MavenSession session, MavenProject project )
        throws PluginNotFoundException, PluginResolutionException, PluginDescriptorParsingException,
        MojoNotFoundException, NoPluginFoundForPrefixException, InvalidPluginDescriptorException,
        PluginVersionResolutionException
    {
        String goal = null;

        Plugin plugin = null;


// The token string for the task. The token string for the plugin. The token to parse the task.
        StringTokenizer tok = new StringTokenizer( task, ":" );

        int numTokens = tok.countTokens();

        if ( numTokens >= 4 )
        {
            // We have everything that we need
            //
            // org.apache.maven.plugins:maven-remote-resources-plugin:1.0:process
            //
            // groupId
            // artifactId
            // version
            // goal
            //
            plugin = new Plugin();
            plugin.setGroupId( tok.nextToken() );
            plugin.setArtifactId( tok.nextToken() );
            plugin.setVersion( tok.nextToken() );
            goal = tok.nextToken();

            // This won't be valid, but it constructs something easy to read in the error message
            while ( tok.hasMoreTokens() )
            {
                goal += ":" + tok.nextToken();
            }
        }
        else if ( numTokens == 3 )
        {
            // We have everything that we need except the version
            //
            // org.apache.maven.plugins:maven-remote-resources-plugin:???:process
            //
            // groupId
            // artifactId
            // ???
            // goal
            //
            plugin = new Plugin();
            plugin.setGroupId( tok.nextToken() );
            plugin.setArtifactId( tok.nextToken() );
            goal = tok.nextToken();
        }
        else if ( numTokens <= 2 )
        {
            // We have a prefix and goal
            //
            // idea:idea
            //
            String prefix = tok.nextToken();

            if ( numTokens == 2 )
            {
                goal = tok.nextToken();
            }
            else
            {
                // goal was missing - pass through to MojoNotFoundException
                goal = "";
            }

            // This is the case where someone has executed a single goal from the command line
            // of the form:
            //
            // mvn remote-resources:process
            //
            // From the metadata stored on the server which has been created as part of a standard
            // Maven plugin deployment we will find the right PluginDescriptor from the remote
            // repository.

            plugin = findPluginForPrefix( prefix, session );
        }

        int executionIdx = goal.indexOf( '@' );
        if ( executionIdx > 0 )
        {
            goal = goal.substring( 0, executionIdx );
        }

        injectPluginDeclarationFromProject( plugin, project );

        // If there is no version to be found then we need to look in the repository metadata for
        // this plugin and see what's specified as the latest release.
        //
        if ( plugin.getVersion() == null )
        {
            resolvePluginVersion( plugin, session, project );
        }

        return pluginManager.getMojoDescriptor( plugin, goal, project.getRemotePluginRepositories(),
                                                session.getRepositorySession() );
    }

}