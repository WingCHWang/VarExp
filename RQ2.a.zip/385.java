public class A {
@Test
    public void testHashCode() {
        Bytes b1 = new Bytes("5kb");

// the bytes to compare. the bytes to test. a byte array.
        Bytes b2 = new Bytes("5368709120b");
        Bytes b3 = new Bytes("5gb");
        Bytes b4 = new Bytes("5120 b");

        assertEquals(b1.hashCode(), b4.hashCode());
        assertEquals(b2.hashCode(), b3.hashCode());
        assertNotEquals(b1.hashCode(), b3.hashCode());
    }

}