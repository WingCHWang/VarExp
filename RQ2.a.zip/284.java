public class A {
public void paint(Graphics g) {
		List<Model> models = diagram.getModels();

		for (Model model : models) {
			Point definingLoc1 = model.getStartingPoint();

// the location to paint to. the starting and release point. the location to paint to
			Point definingLoc2 = model.getReleasePoint();
			model.paint(definingLoc1, definingLoc2);
		}
	}

}