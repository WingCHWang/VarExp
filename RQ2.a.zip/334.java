public class A {
@Test
    public void testCustomNamedModule() {
        BQRuntime runtime = runtimeFactory.app().module(new BQModuleProvider() {
            @Override
            public Module module() {
                return b -> {
                };
            }

            @Override
            public BQModule.Builder moduleBuilder() {
                return BQModuleProvider.super
                        .moduleBuilder()
                        .name("mymodule");
            }
        }).createRuntime();

        ModulesMetadata md = runtime.getInstance(ModulesMetadata.class);
        assertEquals("Expected BQCoreModule + 2 test modules + custom module", 4, md.getModules().size());


// the metadata of the module the metadata of the module. the modules metadata
        Optional<ModuleMetadata> myMd = md.getModules()
                .stream()
                .filter(m -> "mymodule".equals(m.getName()))
                .findFirst();
        assertTrue(myMd.isPresent());
    }

}