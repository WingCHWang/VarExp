public class A {
private void initDragAndDrop(boolean canMove) {
        setOnDragOver(e -> dragConsume(e, this.onDragOverConsumer()));
        setOnDragEntered(e -> dragConsume(e, this.onDragEnteredConsumer()));
        setOnDragExited(this::onDragExited);
        setOnDragDropped(e -> dragConsume(e, this.onDragDropped()));
        if (canMove) {
            setRowFactory(tv -> {
                TableRow<SelectionTableRowData> row = new TableRow<>();
                row.setOnDragDetected(e -> {
                    ArrayList<Integer> selection = new ArrayList<>(getSelectionModel().getSelectedIndices());
                    if (!row.isEmpty() && !selection.isEmpty()) {
                        Dragboard db = row.startDragAndDrop(TransferMode.MOVE);
                        db.setDragView(row.snapshot(null, null));

// the {@link ClipboardContent} to use for the drag and the {@link ClipboardContent} to be used for the drag the {@link ClipboardContent} to set the content to.
                        ClipboardContent cc = new ClipboardContent();
                        cc.put(DND_TABLE_SELECTION_MIME_TYPE, selection);
                        db.setContent(cc);
                        e.consume();

                    }
                });

                row.setOnDragOver(e -> {
                    if (e.getGestureSource() != row && e.getDragboard().hasContent(DND_TABLE_SELECTION_MIME_TYPE)) {
                        if (!((List<Integer>) e.getDragboard().getContent(DND_TABLE_SELECTION_MIME_TYPE))
                                .contains(row.getIndex())) {
                            e.acceptTransferModes(TransferMode.MOVE);
                            e.consume();
                        }
                    }
                });
                row.setOnDragEntered(e -> {
                    if (!row.isEmpty() && e.getDragboard().hasContent(DND_TABLE_SELECTION_MIME_TYPE)) {
                        if (!((List<Integer>) e.getDragboard().getContent(DND_TABLE_SELECTION_MIME_TYPE))
                                .contains(row.getIndex())) {
                            row.setOpacity(0.6);
                        }
                    }
                });
                row.setOnDragExited(e -> {
                    if (!row.isEmpty() && e.getDragboard().hasContent(DND_TABLE_SELECTION_MIME_TYPE)) {
                        if (!((List<Integer>) e.getDragboard().getContent(DND_TABLE_SELECTION_MIME_TYPE))
                                .contains(row.getIndex())) {
                            row.setOpacity(1);
                        }
                    }
                });

                row.setOnDragDropped(e -> {
                    Dragboard db = e.getDragboard();
                    if (db.hasContent(DND_TABLE_SELECTION_MIME_TYPE)) {
                        Optional<SelectionTableRowData> focus = ofNullable(getFocusModel().getFocusedItem());
                        Optional<SelectionTableRowData> toDrop = of(row).filter(r -> !r.isEmpty())
                                .map(TableRow::getIndex).map(getItems()::get);

                        List<Integer> dragged = (List<Integer>) e.getDragboard()
                                .getContent(DND_TABLE_SELECTION_MIME_TYPE);
                        List<SelectionTableRowData> toMove = dragged.stream().map(getItems()::get)
                                .filter(Objects::nonNull).collect(Collectors.toList());
                        getItems().removeAll(toMove);

                        int dropIndex = getItems().size();
                        if (toDrop.isPresent()) {
                            int toDropNewIndex = toDrop.map(getItems()::indexOf).get();
                            if (toDropNewIndex == row.getIndex()) {
                                // we dropped up
                                dropIndex = toDropNewIndex;
                            } else {
                                // we dropped down
                                dropIndex = toDropNewIndex + 1;
                            }
                        }

                        getItems().addAll(dropIndex, toMove);
                        e.setDropCompleted(true);
                        getSelectionModel().clearSelection();
                        getSelectionModel().selectRange(dropIndex, dropIndex + toMove.size());
                        focus.map(getItems()::indexOf).ifPresent(getFocusModel()::focus);
                        e.consume();
                    }
                });

                return row;
            });
        }
    }

}