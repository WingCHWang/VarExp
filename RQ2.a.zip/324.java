public class A {
protected void mergeOverrides(Map<String, ManagedCommand> commandMap) {

        if (commandOverrides != null) {

// the command overrides the command override the command to override
            commandOverrides.forEach(co -> {

                ManagedCommand.Builder builder = ManagedCommand.builder(co);

                // check existing command prior to overriding... preserve existing "help" and "default" flags
                ManagedCommand existing = commandMap.get(co.getMetadata().getName());

                if (existing != null) {

                    // preserve existing flags...
                    if (existing.isHelp()) {
                        builder.asHelp();
                    }

                    if (existing.isDefault()) {
                        builder.asDefault();
                    }

                    // log override
                    String i1 = existing.getCommand().getClass().getName();
                    String i2 = co.getClass().getName();
                    bootLogger.trace(() -> String.format("Overriding command '%s' (old command: %s, new command: %s)",
                            co.getMetadata().getName(), i1, i2));
                }

                addCommand(commandMap, builder.build());
            });
        }
    }

}