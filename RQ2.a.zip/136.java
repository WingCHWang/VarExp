public class A {
@Test
    public void testQuerySelf() throws Exception {
        final String objectXpath = "//CLASS_DEF[./IDENT[@text='InputXpathMapperAst']]//OBJBLOCK";
        final RootNode rootNode = getRootNode("InputXpathMapperAst.java");
        final List<NodeInfo> objectNodes = getXpathItems(objectXpath, rootNode);
        assertWithMessage("Invalid number of nodes")
                .that(objectNodes)
                .hasSize(1);

// The object to query. the object to query. the object to query
        final AbstractNode objNode = (AbstractNode) objectNodes.get(0);
        final String methodsXpath = "self::OBJBLOCK";
        final DetailAST[] actual = convertToArray(getXpathItems(methodsXpath, objNode));
        final DetailAST expectedObjBlockNode = getSiblingByType(rootNode.getUnderlyingNode(),
                TokenTypes.COMPILATION_UNIT)
                .findFirstToken(TokenTypes.CLASS_DEF)
                .findFirstToken(TokenTypes.OBJBLOCK);
        final DetailAST[] expected = {expectedObjBlockNode};
        assertWithMessage("Result nodes differ from expected")
                .that(actual)
                .isEqualTo(expected);
    }

}