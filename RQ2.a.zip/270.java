public class A {
public static void requireNotBlank(String arg, String errorMessage) {

// the argument to check the value to check the argument to test
        require(StringUtils.isNotBlank(arg), errorMessage);
    }

}