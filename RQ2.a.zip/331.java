public class A {
@Test
    public void testNewObjectMapper_Inheritance() throws IOException {
        ObjectMapper mapper = new DefaultJacksonService(typesFactory.getTypes()).newObjectMapper();

        Sup1 su1 = readValue(Sup1.class, mapper, "{\"type\":\"sub1\",\"p1\":\"p1111\"}");
        assertTrue(su1 instanceof Sub1);
        assertEquals("p1111", ((Sub1) su1).getP1());

        Sup1 su2 = readValue(Sup1.class, mapper, "{\"type\":\"sub2\",\"p2\":15}");
        assertTrue(su2 instanceof Sub2);
        assertEquals(15, ((Sub2) su2).getP2());

        Sup1 su22 = readValue(Sup1.class, mapper, "{\"p2\":18}");
        assertTrue(su22 instanceof Sub2);
        assertEquals(18, ((Sub2) su22).getP2());



// a {@link com.google.gson.core.type. a {@link com.google.gwt.core.ext. a {@link com.google.gwt.core.client.
        Sup2 su3 = readValue(Sup2.class, mapper, "{\"type\":\"sub3\",\"p3\":\"pxxxx\"}");
        assertTrue(su3 instanceof Sub3);
        assertEquals("pxxxx", ((Sub3) su3).getP3());

        Sup2 su4 = readValue(Sup2.class, mapper, "{\"type\":\"sub4\",\"p4\":150}");
        assertTrue(su4 instanceof Sub4);
        assertEquals(150, ((Sub4) su4).getP4());
    }

}