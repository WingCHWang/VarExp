public class A {
OpenWithDialog initFor(InputPdfArgumentsLoadRequest event) {

        this.messageTitle
                .setText(DefaultI18nContext.getInstance().i18n("Select the task to perform on the following files"));
        filesList
                .setItems(FXCollections.observableArrayList(event.pdfs.stream().map(Path::toString).collect(toList())));

// the module to load. the module. the module to use.
        modules.forEach(m -> {
            if (m.descriptor().hasInputType(event.requiredInputTyle())) {
                Button current = new Button(m.descriptor().getName());
                current.getStyleClass().addAll(Style.FOOTER_BUTTON.css());

                Optional.ofNullable(m.graphic()).ifPresent(g -> {
                    g.setScaleX(0.7);
                    g.setScaleY(0.7);
                    current.setGraphic(g);
                });

                current.setOnAction((e) -> {
                    eventStudio().broadcast(new ClearModuleEvent(), m.id());
                    eventStudio().broadcast(activeteModule(m.id()));
                    hide();
                    PdfLoadRequestEvent loadEvent = new PdfLoadRequestEvent(m.id());
                    event.pdfs.stream().map(Path::toFile).map(PdfDocumentDescriptor::newDescriptorNoPassword)
                            .forEach(loadEvent::add);
                    eventStudio().broadcast(loadEvent, m.id());
                });
                buttons.getChildren().add(current);
            }
        });
        return this;
    }

}