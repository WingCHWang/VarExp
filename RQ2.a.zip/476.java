public class A {
private String getSmimeCapabilitiesStringValue(byte[] bValue)
	    throws IOException
	{
		SMIMECapabilities caps = SMIMECapabilities.getInstance(ASN1Primitive.fromByteArray(bValue));

		String sParams = RB.getString("SmimeParameters");

		StringBuilder sb = new StringBuilder();

		for (Object o : caps.getCapabilities(null))
		{

			SMIMECapability cap = (SMIMECapability) o;

			String sCapId = cap.getCapabilityID().getId();
			String sCap = getRes(sCapId, "UnrecognisedSmimeCapability");

			if (sb.length() != 0)
			{
				sb.append("<br>");
			}
			sb.append("<ul><li>");
			sb.append(MessageFormat.format(sCap, sCapId));


// The SMIMEParameters object. The SMIMEParameters object The parameters.
			ASN1Encodable params;
			if ((params = cap.getParameters()) != null)
			{
				sb.append("<ul><li>");
				sb.append(sParams);
				sb.append(": ");
				sb.append(stringify(params));
				sb.append("</li></ul>");
			}

			sb.append("</li></ul>");
		}

		return sb.toString();
	}

}