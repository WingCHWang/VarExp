public class A {
private String getHexClearDump(byte[] bytes, int iLen)
	{
		// Buffer for hex

// the buffer for hex and clear text the buffer for hex dump the buffer to use for hex dump
		StringBuilder sbHex;
		if (iLen == bytes.length)
		{
			sbHex = StringUtil.toHex(bytes, 2, " ");
		}
		else
		{
			byte[] tmp = Arrays.copyOfRange(bytes, 0, iLen);
			sbHex = StringUtil.toHex(tmp, 2, " ");
		}

		// Buffer for clear text
		StringBuilder sbClr = new StringBuilder(iLen);

		// Populate buffers for hex and clear text

		// For each byte...
		for (int iCnt = 0; iCnt < iLen; iCnt++)
		{
			// Convert byte to int
			int i = bytes[iCnt] & 0xFF;

			// Get clear character
			char c = (char) i;
			if (Character.isISOControl(c) || !Character.isDefined(c))
			{
				c = '.';
			}

			sbClr.append(c);
		}

		/*
		 * Put both dumps together in one string (hex, clear) with appropriate padding between them (pad to array
		 * length)
		 */
		StringBuilder strBuff = new StringBuilder(sbHex.length() + sbClr.length() + 4);

		strBuff.append(sbHex);

		int iMissing = bytes.length - iLen;
		for (int iCnt = 0; iCnt < iMissing; iCnt++)
		{
			strBuff.append("   ");
		}

		strBuff.append("   ");
		strBuff.append(sbClr);
		strBuff.append('\n');

		return strBuff.toString();
	}

}