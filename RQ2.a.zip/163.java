public class A {
@Override public void accept(Throwable throwable) throws Exception {

// the {@link Throwable} reference the {@link Throwable} reference. the reference to the {@link Throwable}
        if (!throwableRef.compareAndSet(null, throwable)) {
          throw Exceptions.propagate(throwable);
        }
      }

}