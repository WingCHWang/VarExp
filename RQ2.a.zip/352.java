public class A {
@Test
    public void testConfig_ResourceFactory() throws IOException {


// the resource factory holder resource factory holder the resource factory holder.
        ResourceFactoryHolder rfh = factory("resourceFactory: classpath:io/bootique/config/resourcefactory.txt")
                .config(ResourceFactoryHolder.class, "");
        assertNotNull(rfh);
        assertNotNull(rfh.resourceFactory);

        try (Scanner scanner = new Scanner(rfh.resourceFactory.getUrl().openStream(), "UTF-8")) {
            assertEquals("resource factory worked!", scanner.useDelimiter("\\Z").nextLine());
        }
    }

}