public class A {
private void populateDialog()
	    throws CryptoException
	{
		// Version
		m_jtfVersion.setText(m_req.toASN1Structure().getCertificationRequestInfo().getVersion().getValue().toString());
		m_jtfVersion.setCaretPosition(0);

		// Subject
		X500Name subject = m_req.getSubject();
		m_jtfSubject.setText(subject.toString());
		m_jtfSubject.setCaretPosition(0);

		m_basename = NameUtil.getCommonName(subject);

		// Public Key (algorithm and keysize)
		SubjectPublicKeyInfo keyInfo = m_req.getSubjectPublicKeyInfo();


// the parameters from the certificate request. the parameters from the certificate request the information from the certificate request.
		AsymmetricKeyParameter keyParams;
		try
		{
			keyParams = PublicKeyFactory.createKey(keyInfo);
		}
		catch (IOException e)
		{
			throw new CryptoException(RB.getString("DViewCSR.NoGetKeyInfo.exception.message"), e);
		}

		m_jtfPublicKey.setText(AlgorithmType.toString(keyInfo.getAlgorithm().getAlgorithm().toString()));

		int iKeySize = KeyPairUtil.getKeyLength(keyParams);
		if (iKeySize != KeyPairUtil.UNKNOWN_KEY_SIZE)
		{
			m_jtfPublicKey.setText(
			    MessageFormat.format(RB.getString("DViewCSR.m_jtfPublicKey.text"), m_jtfPublicKey.getText(), iKeySize));
		}
		m_jtfPublicKey.setCaretPosition(0);

		// Signature Algorithm
		String sigAlgName = SignatureType.toString(m_req.getSignatureAlgorithm().getAlgorithm().toString());
		m_jtfSignatureAlgorithm.setText(sigAlgName);
		m_jtfSignatureAlgorithm.setCaretPosition(0);

		// TODO: attributes, requested extensions
	}

}