public class A {
public static void browse(Component parentComponent, URI uri)
	{
		if (DESKTOP != null)
		{
			try
			{

// the URI to browse the URI to browse. the URI to open
				DESKTOP.browse(uri);
				return;
			}
			catch (Exception e)
			{
				// Ignored
			}
		}

		// Could not launch - tell the user the address
		JOptionPane.showMessageDialog(parentComponent,
		    MessageFormat.format(RB.getString("FPortecle.NoLaunchBrowser.message"), uri),
		    RB.getString("FPortecle.Title"), JOptionPane.INFORMATION_MESSAGE);
	}

}