public class A {
private static boolean isUrlReachable(String url) {
        boolean result = true;
        try {

// the URL to check the URL to test the url to check
            final URL verifiableUrl = new URL(url);
            final HttpURLConnection urlConnect = (HttpURLConnection) verifiableUrl.openConnection();
            urlConnect.getContent();
        }
        catch (IOException ignored) {
            result = false;
        }
        return result;
    }

}