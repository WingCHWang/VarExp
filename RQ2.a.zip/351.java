public class A {
private void calcOverrideGraph(Map<Class<? extends Module>, RuntimeModule> modules) {

        for (RuntimeModule rm : modules.values()) {

            for(Class<? extends Module> override : rm.getBqModule().getOverrides()) {

// the override graph the override graph for the modules the runtime module to be overridden by
                RuntimeModule rmn = modules.get(override);
                if(rmn != null) {
                    rmn.setOverriddenBy(rm);
                    rm.setOverridesOthers(true);
                }
            }
        }
    }

}