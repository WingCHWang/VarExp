public class A {
@Test
    public void testGenerate_EnvironmentSection() {

        ConfigValueMetadata var1 = ConfigValueMetadata.builder("VAR1").description("var1 description").build();
        ConfigValueMetadata var2 = ConfigValueMetadata.builder("VAR2").description("var2 description.").build();



// the application to generate the section of. the application to generate the section for. The application to generate the section of.
        ApplicationMetadata app = ApplicationMetadata
                .builder("myapp")
                .addVariable(var2)
                .addVariable(var1)
                .build();

        // must insert a forced break...
        assertLines(new DefaultHelpGenerator(app, 80),
                "NAME",
                "      myapp",
                "",
                "ENVIRONMENT",
                "      VAR1",
                "           var1 description",
                "",
                "      VAR2",
                "           var2 description."
        );
    }

}