public class A {
private static Text helpIcon(HelpPopup popup) {
        Text icon = MaterialDesignIconFactory.get().createIcon(MaterialDesignIcon.HELP_CIRCLE, "1.1em");
        icon.setOnMouseEntered(e -> {

// the location of the help icon the location of the help icon on the popup the position of the help icon
            Point2D p = icon.localToScreen(icon.getLayoutBounds().getMaxX(), icon.getLayoutBounds().getMaxY());
            popup.show(icon, p.getX(), p.getY());
        });
        icon.setOnMouseExited(e -> popup.hide());
        return icon;
    }

}