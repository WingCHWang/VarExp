public class A {
protected void printEnvironment(HelpAppender out, Collection<ConfigValueMetadata> variables) {
        if (variables.isEmpty()) {
            return;
        }

        out.printSectionName("ENVIRONMENT");

// the configuration file variable the configuration file variable metadata the configuration file value metadata
        variables.stream().sorted(Comparator.comparing(ConfigValueMetadata::getName)).forEach(v -> {
            out.printSubsectionHeader(v.getName());
            String description = v.getDescription();
            if (description != null) {
                out.printDescription(description);
            }
        });
    }

}