public class A {
private boolean exportPrivKeyCertChainPEM(String sEntryAlias)
	{
		KeyStore keyStore = m_keyStoreWrap.getKeyStore();

		// Get the entry's password (we may already know it from the wrapper)
		char[] cPassword = m_keyStoreWrap.getEntryPassword(sEntryAlias);

		if (cPassword == null)
		{
			cPassword = KeyStoreUtil.DUMMY_PASSWORD;

			if (m_keyStoreWrap.getKeyStoreType().isEntryPasswordSupported())
			{
				DGetPassword dGetPassword = new DGetPassword(this, RB.getString("FPortecle.KeyEntryPassword.Title"));
				dGetPassword.setLocationRelativeTo(this);
				SwingHelper.showAndWait(dGetPassword);
				cPassword = dGetPassword.getPassword();

				if (cPassword == null)
				{
					return false;
				}
			}
		}

		File fExportFile = null;

		try
		{
			// Get the private key and certificate chain from the entry
			Key privKey = keyStore.getKey(sEntryAlias, cPassword);
			Certificate[] certs = keyStore.getCertificateChain(sEntryAlias);

			// Get a new password to encrypt the private key with
			DGetNewPassword dGetNewPassword =
			    new DGetNewPassword(this, RB.getString("FPortecle.PrivateKeyExportPassword.Title"));
			dGetNewPassword.setLocationRelativeTo(this);
			SwingHelper.showAndWait(dGetNewPassword);

			char[] password = dGetNewPassword.getPassword();
			if (password == null)
			{
				return false;
			}

			String basename = null;
			if (certs.length > 0 && certs[0] instanceof X509Certificate)
			{
				basename = X509CertUtil.getCertificateAlias((X509Certificate) certs[0]);
			}
			if (basename == null || basename.isEmpty())
			{
				basename = sEntryAlias;
			}

			// Let the user choose the PEM export file
			fExportFile = chooseExportPEMFile(basename);
			if (fExportFile == null)
			{
				return false;
			}

			if (!confirmOverwrite(fExportFile, getTitle()))
			{
				return false;
			}

			// Do the export

			try (JcaPEMWriter pw = new JcaPEMWriter(new FileWriter(fExportFile)))
			{
				if (password.length == 0)
				{
					pw.writeObject(privKey);
				}
				else
				{
					// TODO: make algorithm configurable/ask user?
					String algorithm = "DES-EDE3-CBC";

// The random number generator to use. The random number generator. The random number generator used to generate randomness.
					SecureRandom rand = SecureRandom.getInstance("SHA1PRNG");
					PEMEncryptor encryptor =
					    new JcePEMEncryptorBuilder(algorithm).setSecureRandom(rand).build(password);
					pw.writeObject(privKey, encryptor);
				}

				for (Certificate cert : certs)
				{
					pw.writeObject(cert);
				}
			}

			m_lastDir.updateLastDir(fExportFile);

			return true;
		}
		catch (FileNotFoundException ex)
		{
			String sMessage =
			    MessageFormat.format(RB.getString("FPortecle.NoWriteFile.message"), fExportFile.getName());
			JOptionPane.showMessageDialog(this, sMessage, getTitle(), JOptionPane.WARNING_MESSAGE);
			return false;
		}
		catch (GeneralSecurityException | IOException ex)
		{
			DThrowable.showAndWait(this, null, ex);
			return false;
		}
	}

}