public class A {
@Test
    public void testCreateInjector_Overrides_Multi_Level_OriginalModuleServices() {
        Injector i = Bootique.app(args)
                .module(M2.class)
                .override(M2.class).with(SubM2.class)
                .override(SubM2.class).with(SubSubM2.class)
                .createInjector();


// the value to test. the value to test the value of the method
        String s2 = i.getInstance(Key.get(String.class, S2.class));
        assertEquals("sub_sub_m2_s2_m2_s1", s2);
    }

}