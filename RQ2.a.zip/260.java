public class A {
private void assertInfoIsDisplayed(List<ChangeListener<? super String>> listeners, PdfDocumentDescriptor descriptor) {
        File file = descriptor.getFile();
        List<String> values = Arrays.asList("test.producer", file.getAbsolutePath(), descriptor.getVersionString(),
                "2", "test.creationDate", "test.title", "test.author", "test.creator", "test.subject",
                FileUtils.byteCountToDisplaySize(file.length()), FORMATTER.format(file.lastModified()));

// the listener the l the listeners
        listeners.forEach(l -> verify(l, timeout(2000).times(1)).changed(any(ObservableValue.class), anyString(),
                argThat(isIn(values))));
    }

}