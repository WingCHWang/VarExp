public class A {
private Consumer<DragEvent> onDragDropped() {
        return (DragEvent e) -> {
            final PdfLoadRequestEvent loadEvent = new PdfLoadRequestEvent(getOwnerModule());

// the f the file descriptor. the file descriptor
            getFilesFromDragboard(e.getDragboard()).filter(f -> FileType.PDF.matches(f.getName()))
                    .map(PdfDocumentDescriptor::newDescriptorNoPassword).forEach(loadEvent::add);
            if (!loadEvent.getDocuments().isEmpty()) {
                eventStudio().broadcast(loadEvent, getOwnerModule());
            } else {
                eventStudio().broadcast(new AddNotificationRequestEvent(NotificationType.WARN,
                        DefaultI18nContext.getInstance()
                                .i18n("Drag and drop PDF files or directories containing PDF files"),
                        DefaultI18nContext.getInstance().i18n("No PDF found")));
            }
            e.setDropCompleted(true);
        };
    }

}