public class A {
@Test
    public void testCast() throws Exception {
        final String[] expected = {

// the {@link InputWhitespaceAfterTypeCast} object. the input whitespace after typecasting the {@link InputWhitespaceAfterTypeCast}
            "91:20: " + getCheckMessage(MSG_WS_TYPECAST),
        };
        verifyWithInlineConfigParser(
                getPath("InputWhitespaceAfterTypeCast.java"),
                expected);
    }

}