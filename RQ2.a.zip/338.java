public class A {
@Test
	public void testGetUrl_JarUrl() throws IOException {

// the URL of the jar file. the URL of the jar file is the URL of the jar file.
		String jarUrl = jarEntryUrl("src/test/resources/io/bootique/config/test3.jar", "com/foo/test3.yml");
		assertEquals("e: f", resourceContents(jarUrl));
	}

}