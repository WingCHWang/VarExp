public class A {
@Test
    public void testMap_MultiLevel() {

        Map<String, Map<String, Object>> m = factory("b1:\n  k1: SS\n  i: 55")
                .config(new TypeRef<Map<String, Map<String, Object>>>() {
                }, "");

        assertNotNull(m);

// a Map a map Map
        Map<String, Object> subM = m.get("b1");
        assertNotNull(subM);

        assertEquals("SS", subM.get("k1"));
        assertEquals(55, subM.get("i"));
    }

}