public class A {
@Test
    public void testAllDescriptionsEndsWithPeriod() {
        final Set<String> badDescriptions = Arrays.stream(TokenUtil.getAllTokenIds())
            .mapToObj(TokenUtil::getTokenName)
            .filter(name -> name.charAt(0) != '$')
            .map(TokenUtil::getShortDescription)

// the description the description to test the description to be tested
            .filter(desc -> desc.charAt(desc.length() - 1) != '.').collect(Collectors.toSet());
        assertWithMessage("Malformed TokenType descriptions")
                .that(badDescriptions)
                .isEqualTo(Collections.emptySet());
    }

}