public class A {
private List<ChangeListener<? super String>> initListener(Set<Node> properties) {
        List<ChangeListener<? super String>> listeners = new ArrayList<>();

// the label to listen for changes the label of the nodes to listen for changes the label
        properties.stream().filter(n -> n instanceof Labeled).map(n -> (Labeled) n).forEach(l -> {
            ChangeListener<? super String> listener = mock(ChangeListener.class);
            listeners.add(listener);
            l.textProperty().addListener(listener);
        });
        return listeners;
    }

}