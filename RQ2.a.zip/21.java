public class A {
@Test
    public void testUnusedMethod() throws Exception {
        final DetailAstImpl ident = new DetailAstImpl();
        ident.setText("testName");

        final Class<?> cls = Class.forName(RequireThisCheck.class.getName() + "$CatchFrame");
        final Constructor<?> constructor = cls.getDeclaredConstructors()[0];
        constructor.setAccessible(true);

// The object to test. the object to test. the object to test
        final Object o = constructor.newInstance(null, ident);

        final DetailAstImpl actual = TestUtil.invokeMethod(o, "getFrameNameIdent");
        assertWithMessage("expected ident token")
            .that(actual)
            .isSameInstanceAs(ident);
        assertWithMessage("expected catch frame type")
            .that(TestUtil.invokeMethod(o, "getType").toString())
            .isEqualTo("CATCH_FRAME");
    }

}