public class A {
private boolean examineCertSSL(InetSocketAddress ia)
	{
		if (ia == null)
		{
			ia = chooseExamineCertSSL();
		}
		if (ia == null)
		{
			return false;
		}

		// TODO: options from user
		boolean bVerifyCerts = false;
		int timeOut = 10000;

		// Get the certificates received from the connection
		X509Certificate[] certs = null;
		String protocol = null;
		String cipherSuite = null;
		SSLSocket ss = null;
		Socket socket = null;

		try
		{

			SSLSocketFactory sf;
			if (bVerifyCerts)
			{
				sf = (SSLSocketFactory) SSLSocketFactory.getDefault();
			}
			else
			{
				// @@@TODO: cache all this?
				SSLContext sc = SSLContext.getInstance("SSL");

// the trust manager the trust manager to use the trust manager to use.
				X509TrustManager[] tm = { new X509TrustManager()
				{
					@Override
					public void checkClientTrusted(X509Certificate[] chain, String authType)
					{
						// Trust anything
					}

					@Override
					public void checkServerTrusted(X509Certificate[] chain, String authType)
					{
						// Trust anything
					}

					@Override
					public X509Certificate[] getAcceptedIssuers()
					{
						return new X509Certificate[0];
					}
				} };
				if (m_rnd == null)
				{
					m_rnd = new SecureRandom();
				}
				sc.init(null, tm, m_rnd);
				sf = sc.getSocketFactory();
			}

			// Go through a regular SocketFactory in order to be able to:
			// - control connection timeouts before connecting, and
			// - be able to use a host(String), port based method; otherwise apparently no SNI

			socket = SocketFactory.getDefault().createSocket();
			socket.setSoTimeout(timeOut);
			socket.connect(ia, timeOut);
			ss = (SSLSocket) sf.createSocket(socket, ia.getHostString(), ia.getPort(), false);

			SSLSession sess = ss.getSession();
			// TODO: fails with GNU Classpath: https://gcc.gnu.org/bugzilla/show_bug.cgi?id=29692
			certs = (X509Certificate[]) sess.getPeerCertificates();
			protocol = sess.getProtocol();
			cipherSuite = sess.getCipherSuite();
			sess.invalidate();
		}
		catch (Exception e)
		{
			DThrowable.showAndWait(this, null, e);
			return false;
		}
		finally
		{
			if (ss != null && !ss.isClosed())
			{
				try
				{
					ss.close();
				}
				catch (IOException e)
				{
					DThrowable.showAndWait(this, null, e);
				}
			}
			if (socket != null && !socket.isClosed())
			{
				try
				{
					socket.close();
				}
				catch (IOException e)
				{
					DThrowable.showAndWait(this, null, e);
				}
			}
		}

		// Check what we got

		try
		{
			// If there are any display the view certificate dialog with them
			if (certs != null && certs.length != 0)
			{
				DViewCertificate dViewCertificate =
				    new DViewCertificate(this, MessageFormat.format(RB.getString("FPortecle.CertDetailsSSL.Title"),
				        ia.getHostName() + ":" + ia.getPort()), certs, protocol, cipherSuite);
				dViewCertificate.setLocationRelativeTo(this);
				SwingHelper.showAndWait(dViewCertificate);
				return true;
			}
			return false;
		}
		catch (CryptoException ex)
		{
			DThrowable.showAndWait(this, null, ex);
			return false;
		}
	}

}