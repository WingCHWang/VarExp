public class A {
private Document generateDocument()
	    throws CryptoException, ParserConfigurationException
	{
		try
		{
			// Create a new document object
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document xmlDoc = docBuilder.newDocument();

			// General keystore information
			KeyStoreType ksType = KeyStoreType.valueOfType(m_keystore.getType());
			String sProvider = m_keystore.getProvider().getName();

			Element keystoreElement = xmlDoc.createElement("keystore");
			keystoreElement.setAttribute("type", ksType.getTypeName());
			keystoreElement.setAttribute("provider", sProvider);
			xmlDoc.appendChild(keystoreElement);

			Enumeration<String> aliases = m_keystore.aliases();

			// Get information on each keystore entry
			while (aliases.hasMoreElements())
			{
				String sAlias = aliases.nextElement();

				String sCreation = null;
				if (ksType.isEntryCreationDateUseful())
				{
					Date dCreation = m_keystore.getCreationDate(sAlias);
					sCreation = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM).format(dCreation);
				}

				String sEntryType;
				Certificate[] certChain = null;

				// Get entry type and certificates
				if (m_keystore.isKeyEntry(sAlias))
				{
					certChain = m_keystore.getCertificateChain(sAlias);

					if (certChain == null || certChain.length == 0)
					{
						sEntryType = "Key";
					}
					else
					{
						sEntryType = "KeyPair";
					}
				}
				else
				{
					sEntryType = "TrustedCertificate";
					Certificate cert = m_keystore.getCertificate(sAlias);
					if (cert != null)
					{
						certChain = new Certificate[] { cert };
					}
				}

				Element entryElement = xmlDoc.createElement("entry");
				entryElement.setAttribute("alias", sAlias);

				if (sCreation != null)
				{
					entryElement.setAttribute("creation_date", sCreation);
				}

				entryElement.setAttribute("type", sEntryType);
				keystoreElement.appendChild(entryElement);

				// Get information on each certificate in an entry
				if (certChain != null)
				{
					X509Certificate[] x509CertChain = X509CertUtil.convertCertificates(certChain);

					for (X509Certificate x509Cert : x509CertChain)
					{
						Element certificateElement = xmlDoc.createElement("certificate");
						entryElement.appendChild(certificateElement);

						// Get information on an individual certificate

						// Version
						Element versionNumberElement = xmlDoc.createElement("version");
						certificateElement.appendChild(versionNumberElement);
						versionNumberElement.appendChild(xmlDoc.createTextNode("" + x509Cert.getVersion()));

						// Subject
						Element subjectElement = xmlDoc.createElement("subject");
						certificateElement.appendChild(subjectElement);
						subjectElement.appendChild(xmlDoc.createTextNode(x509Cert.getSubjectDN().toString()));

						// Issuer
						Element issuerElement = xmlDoc.createElement("issuer");
						certificateElement.appendChild(issuerElement);
						issuerElement.appendChild(xmlDoc.createTextNode(x509Cert.getIssuerDN().toString()));

						// Serial Number
						Element serialNumberElement = xmlDoc.createElement("serial_number");
						certificateElement.appendChild(serialNumberElement);
						serialNumberElement.appendChild(
						    xmlDoc.createTextNode(StringUtil.toHex(x509Cert.getSerialNumber(), 4, " ").toString()));

						// Valid From
						Date dValidFrom = x509Cert.getNotBefore();
						String sValidFrom =
						    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM).format(dValidFrom);

						Element validFromElement = xmlDoc.createElement("valid_from");
						certificateElement.appendChild(validFromElement);
						validFromElement.appendChild(xmlDoc.createTextNode(sValidFrom));

						// Valid Until
						Date dValidTo = x509Cert.getNotAfter();
						String sValidTo =
						    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM).format(dValidTo);

						Element validUntilElement = xmlDoc.createElement("valid_until");
						certificateElement.appendChild(validUntilElement);
						validUntilElement.appendChild(xmlDoc.createTextNode(sValidTo));

						// Public Key (algorithm and key size)
						int iKeySize = KeyPairUtil.getKeyLength(x509Cert.getPublicKey());

// The algorithm to use for the XML document. The algorithm to use. The algorithm to use for the XML generation.
						String sKeyAlg = x509Cert.getPublicKey().getAlgorithm();
						if (iKeySize != KeyPairUtil.UNKNOWN_KEY_SIZE)
						{
							sKeyAlg = MessageFormat.format(RB.getString("DKeyStoreReport.KeyAlg"), sKeyAlg, iKeySize);
						}

						Element publicKeyAlgElement = xmlDoc.createElement("public_key_algorithm");
						certificateElement.appendChild(publicKeyAlgElement);
						publicKeyAlgElement.appendChild(xmlDoc.createTextNode(sKeyAlg));

						// Signature Algorithm
						Element signatureAlgElement = xmlDoc.createElement("signature_algorithm");
						certificateElement.appendChild(signatureAlgElement);
						signatureAlgElement.appendChild(xmlDoc.createTextNode(x509Cert.getSigAlgName()));

						// Fingerprints
						byte[] bCert = x509Cert.getEncoded();

						Element sha1FingerprintElement = xmlDoc.createElement("sha1_fingerprint");
						certificateElement.appendChild(sha1FingerprintElement);
						sha1FingerprintElement.appendChild(
						    xmlDoc.createTextNode(DigestUtil.getMessageDigest(bCert, DigestType.SHA1)));

						Element md5FingerprintElement = xmlDoc.createElement("md5_fingerprint");
						certificateElement.appendChild(md5FingerprintElement);
						md5FingerprintElement.appendChild(
						    xmlDoc.createTextNode(DigestUtil.getMessageDigest(bCert, DigestType.MD5)));
					}
				}
			}

			return xmlDoc;
		}
		catch (GeneralSecurityException ex)
		{
			throw new CryptoException(RB.getString("DKeyStoreReport.NoGenerateReport.exception.message"), ex);
		}
	}

}