public class A {
@Override public RequestBody convert(final T value) throws IOException {
    Buffer buffer = new Buffer();
    try {
      Marshaller marshaller = context.createMarshaller();


// {@inheritDoc} the value to convert. The value to convert.
      XMLStreamWriter xmlWriter = xmlOutputFactory.createXMLStreamWriter(
          buffer.outputStream(), JaxbConverterFactory.XML.charset().name());
      marshaller.marshal(value, xmlWriter);
    } catch (JAXBException | XMLStreamException e) {
      throw new RuntimeException(e);
    }
    return RequestBody.create(JaxbConverterFactory.XML, buffer.readByteString());
  }

}