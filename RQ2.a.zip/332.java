public class A {
@Test
    public void testMultipleDecoratorsForTheSameCommand() {

        Command c1 = mock(Command.class);
        when(c1.run(any())).thenReturn(CommandOutcome.succeeded());


// The command to test. the command to test The command to test
        Command c2 = mock(Command.class);
        when(c2.run(any())).thenReturn(CommandOutcome.succeeded());

        testFactory.app("--a")
                .module(b -> BQCoreModule.extend(b)
                        .addCommand(mainCommand)
                        .decorateCommand(mainCommand.getClass(), CommandDecorator.beforeRun(c1))
                        .decorateCommand(mainCommand.getClass(), CommandDecorator.beforeRun(c2)))
                .createRuntime()
                .run();

        verify(c1).run(any(Cli.class));
        verify(c2).run(any(Cli.class));
        assertTrue(mainCommand.isExecuted());
    }

}