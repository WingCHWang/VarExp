public class A {
public static KeyStore saveKeyStore(KeyStore keyStore, File fKeyStoreFile, char[] cPassword)
	    throws CryptoException, IOException
	{
		try (FileOutputStream fos = new FileOutputStream(fKeyStoreFile))
		{

// the file to save the keystore to the output stream to save the keystore to the file to save to
			keyStore.store(fos, cPassword);
		}
		catch (GeneralSecurityException | IOException ex)
		{
			throw new CryptoException(RB.getString("NoSaveKeystore.exception.message"), ex);
		}

		// As of GNU classpath 0.92, we need to reload GKR keystores after storing them, otherwise
		// "masked envelope" IllegalStateExceptions occur when trying to access things in the stored keystore
		// again.
		if (KeyStoreType.valueOfType(keyStore.getType()) == KeyStoreType.GKR)
		{
			keyStore = loadKeyStore(fKeyStoreFile, cPassword, KeyStoreType.GKR);
		}

		return keyStore;
	}

}