public class A {
public void load(JarFile[] jarFiles)
	    throws IOException
	{
		// Create one table row for each JAR file
		m_data = new Object[jarFiles.length][getColumnCount()];

		for (int iCnt = 0; iCnt < jarFiles.length; iCnt++)
		{
			/*
			 * Get JAR info (jar file, size, specification title, specification version, specification title,
			 * implementation title, implementation version and implementation vendor)
			 */
			JarFile jarFile = jarFiles[iCnt];
			String sFile = jarFile.getName();
			File file = new File(sFile);

			// Some info comes from the manifest
			Manifest manifest = jarFile.getManifest();

			String sImplementationTitle = "";
			String sImplementationVersion = "";
			String sImplementationVendor = "";
			String sSpecificationTitle = "";
			String sSpecificationVersion = "";
			String sSpecificationVendor = "";

			if (manifest != null) // Manifest may not exist
			{
				Attributes attributes = manifest.getMainAttributes();

				String sValue = attributes.getValue("Specification-Title");
				if (sValue != null)
				{
					sSpecificationTitle = sValue;
				}

				sValue = attributes.getValue("Specification-Version");
				if (sValue != null)
				{
					sSpecificationVersion = sValue;
				}

				sValue = attributes.getValue("Specification-Vendor");
				if (sValue != null)
				{
					sSpecificationVendor = sValue;
				}

				sValue = attributes.getValue("Implementation-Title");
				if (sValue != null)
				{
					sImplementationTitle = sValue;
				}

				sValue = attributes.getValue("Implementation-Version");
				if (sValue != null)
				{
					sImplementationVersion = sValue;
				}

				sValue = attributes.getValue("Implementation-Vendor");
				if (sValue != null)
				{
					sImplementationVendor = sValue;
				}
			}


// The number of columns in the table. The number of columns to create. The column count of the table row.
			int col = 0;

			// Populate the file column
			m_data[iCnt][col++] = file.getName();

			// Populate the size column
			m_data[iCnt][col++] = file.length();

			// Populate the implementation title column
			m_data[iCnt][col++] = sSpecificationTitle;

			// Populate the implementation version column
			m_data[iCnt][col++] = sSpecificationVersion;

			// Populate the implementation vendor column
			m_data[iCnt][col++] = sSpecificationVendor;

			// Populate the specification title column
			m_data[iCnt][col++] = sImplementationTitle;

			// Populate the specification version column
			m_data[iCnt][col++] = sImplementationVersion;

			// Populate the specification vendor column
			m_data[iCnt][col++] = sImplementationVendor;
		}

		fireTableDataChanged();
	}

}