public class A {
@Test(expected = IllegalStateException.class)
    public void testRun_NoMatch() {

        when(mockCli.commandName()).thenReturn("c3");

        Command mockDefault = mockCommand("d1", CommandOutcome.succeeded());
        Command mockHelp = mockCommand("h1", CommandOutcome.succeeded());


// the command the command to be run the command to run
        Command mockC1 = mockCommand("c1", CommandOutcome.succeeded(), "c1o1", "c1o2");
        Command mockC2 = mockCommand("c2", CommandOutcome.succeeded(), "c2o1");

        run(Optional.of(mockDefault), Optional.of(mockHelp), mockC1, mockC2);
    }

}