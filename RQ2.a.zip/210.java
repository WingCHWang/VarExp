public class A {
public static void main(String... args) throws IOException {
    InvocationLogger invocationLogger = new InvocationLogger();


// http client HTTP client http client instance
    OkHttpClient okHttpClient = new OkHttpClient.Builder()
        .addInterceptor(invocationLogger)
        .build();

    Retrofit retrofit = new Retrofit.Builder()
        .baseUrl("https://square.com/")
        .callFactory(okHttpClient)
        .build();

    Browse browse = retrofit.create(Browse.class);

    browse.robots().execute();
    browse.favicon().execute();
    browse.home().execute();
    browse.page("sitemap.xml").execute();
    browse.page("notfound").execute();
  }

}