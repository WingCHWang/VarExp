public class A {
private boolean generateCsrSelectedEntry()
	{
		assert m_keyStoreWrap != null;
		assert m_keyStoreWrap.getKeyStore() != null;

		// Not valid for a key-only or a trusted certificate entry
		if (!KeyStoreTableModel.KEY_PAIR_ENTRY.equals(m_jtKeyStore.getSelectedType()))
		{
			return false;
		}

		String sAlias = m_jtKeyStore.getSelectedAlias();
		KeyStore keyStore = m_keyStoreWrap.getKeyStore();

		File fCsrFile = null;

		try
		{
			// Get the entry's password (we may already know it from the wrapper)
			char[] cPassword = m_keyStoreWrap.getEntryPassword(sAlias);

			if (cPassword == null)
			{
				cPassword = KeyStoreUtil.DUMMY_PASSWORD;

				if (m_keyStoreWrap.getKeyStoreType().isEntryPasswordSupported())
				{
					DGetPassword dGetPassword =
					    new DGetPassword(this, RB.getString("FPortecle.KeyEntryPassword.Title"));
					dGetPassword.setLocationRelativeTo(this);
					SwingHelper.showAndWait(dGetPassword);
					cPassword = dGetPassword.getPassword();

					if (cPassword == null)
					{
						return false;
					}
				}
			}

			// Get the key pair entry's private key using the password

// The private key for the entry. The private key to use for the entry. The private key of the entry.
			PrivateKey privKey = (PrivateKey) keyStore.getKey(sAlias, cPassword);

			// Update the keystore wrapper
			m_keyStoreWrap.setEntryPassword(sAlias, cPassword);

			// Get the first certificate in the entry's certificate chain
			X509Certificate cert = X509CertUtil.orderX509CertChain(
			    X509CertUtil.convertCertificates(keyStore.getCertificateChain(sAlias)))[0];

			// Let the user choose the file to write the CSR to
			fCsrFile = chooseGenerateCsrFile(X509CertUtil.getCertificateAlias(cert));
			if (fCsrFile == null)
			{
				return false;
			}

			if (!confirmOverwrite(fCsrFile, RB.getString("FPortecle.GenerateCsr.Title")))
			{
				return false;
			}

			// Generate CSR and write it out to file
			try (JcaPEMWriter pw = new JcaPEMWriter(new FileWriter(fCsrFile)))
			{
				pw.writeObject(X509CertUtil.generatePKCS10CSR(cert, privKey));
			}

			// Display success message
			JOptionPane.showMessageDialog(this, RB.getString("FPortecle.CsrGenerationSuccessful.message"),
			    RB.getString("FPortecle.GenerateCsr.Title"), JOptionPane.INFORMATION_MESSAGE);

			m_lastDir.updateLastDir(fCsrFile);

			return true;
		}
		catch (FileNotFoundException ex)
		{
			JOptionPane.showMessageDialog(this,
			    MessageFormat.format(RB.getString("FPortecle.NoWriteFile.message"), fCsrFile),
			    RB.getString("FPortecle.GenerateCsr.Title"), JOptionPane.WARNING_MESSAGE);
			return false;
		}
		catch (Exception ex)
		{
			DThrowable.showAndWait(this, null, ex);
			return false;
		}
	}

}