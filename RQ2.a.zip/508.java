public class A {
@Override
	public void setDefaultStatusBarText()
	{
		// No keystore loaded...
		if (m_keyStoreWrap == null)
		{
			setStatusBarText(RB.getString("FPortecle.noKeyStore.statusbar"));
		}
		// keystore loaded...
		else
		{
			// Get the keystore and display information on its type and size
			KeyStore ksLoaded = m_keyStoreWrap.getKeyStore();

			int iSize;
			try
			{
				iSize = ksLoaded.size();
			}
			catch (KeyStoreException ex)
			{
				setStatusBarText("");
				DThrowable.showAndWait(this, null, ex);
				return;
			}

			String sType = KeyStoreType.valueOfType(ksLoaded.getType()).toString();

// the property provider the dialog provider the prov content
			String sProv = ksLoaded.getProvider().getName();

			if (iSize == 1)
			{
				setStatusBarText(MessageFormat.format(RB.getString("FPortecle.entry.statusbar"), sType, sProv));
			}
			else
			{
				setStatusBarText(
				    MessageFormat.format(RB.getString("FPortecle.entries.statusbar"), sType, sProv, iSize));
			}
		}
	}

}