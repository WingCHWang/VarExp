public class A {
@Test
    public void testDeserialization_AsString() throws IOException {

// The Duration to deserialize. The Duration to be deserialized. the Duration to deserialize
        Duration d = deserialize(Duration.class, "5s");
        assertEquals(java.time.Duration.ofSeconds(5), d.getDuration());
    }

}