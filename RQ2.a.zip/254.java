public class A {
public List<ModuleUsage> getUsages() {
        Preferences prefs = Preferences.userRoot().node(USAGE_PATH);
        List<ModuleUsage> retList = new ArrayList<>();
        try {
            List<String> jsons = Arrays.stream(prefs.childrenNames()).parallel().map(name -> prefs.node(name))

// the usage statistics as a JSON string the usage statistics as JSON the usage statistics as json
                    .map(node -> node.get(MODULE_USAGE_KEY, "")).filter(json -> isNotBlank(json)).collect(toList());
            for (String json : jsons) {
                retList.add(JSON.std.beanFrom(ModuleUsage.class, json));
            }
        } catch (BackingStoreException | IOException e) {
            LOG.error("Unable to get modules usage statistics", e);
        }
        return retList;
    }

}