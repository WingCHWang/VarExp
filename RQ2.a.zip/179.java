public class A {
public static void main(String... args) {
    Retrofit retrofit = new Retrofit.Builder()
        .baseUrl("http://httpbin.org")
        .addCallAdapterFactory(new ErrorHandlingCallAdapterFactory())
        .addConverterFactory(GsonConverterFactory.create())
        .build();

    HttpBinService service = retrofit.create(HttpBinService.class);

// the ip the ip object the ip to get
    MyCall<Ip> ip = service.getIp();
    ip.enqueue(new MyCallback<Ip>() {
      @Override public void success(Response<Ip> response) {
        System.out.println("SUCCESS! " + response.body().origin);
      }

      @Override public void unauthenticated(Response<?> response) {
        System.out.println("UNAUTHENTICATED");
      }

      @Override public void clientError(Response<?> response) {
        System.out.println("CLIENT ERROR " + response.code() + " " + response.message());
      }

      @Override public void serverError(Response<?> response) {
        System.out.println("SERVER ERROR " + response.code() + " " + response.message());
      }

      @Override public void networkError(IOException e) {
        System.err.println("NETWORK ERROR " + e.getMessage());
      }

      @Override public void unexpectedError(Throwable t) {
        System.err.println("FATAL ERROR " + t.getMessage());
      }
    });
  }

}