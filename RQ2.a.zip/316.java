public class A {
static Optional<ConfigValueMetadata> compileIfValid(DeclaredVariable var, ModulesMetadata modulesMetadata) {

        for (ModuleMetadata mm : modulesMetadata.getModules()) {
            Optional<ConfigMetadataNode> cmn = mm.findConfig(var.getConfigPath());
            if (cmn.isPresent()) {

// the variable to compile the variable to check the variable
                return cmn.map(n -> compileMetadata(var, n));
            }
        }

        return Optional.empty();
    }

}