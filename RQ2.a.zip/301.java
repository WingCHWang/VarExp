public class A {
@Test
    public void testOverrideValueArray() {
        BQRuntime runtime = app()
                .var("MY_VAR", "J")
                .declareVar("testOverrideValueArray.h[1]", "MY_VAR")
                .createRuntime();


// a BQConfigurationFactory a BQConfigurationFactory instance .
        TestOverrideValueArrayBean b = runtime.getInstance(ConfigurationFactory.class)
                .config(TestOverrideValueArrayBean.class, "testOverrideValueArray");

        assertEquals("i", b.h.get(0));
        assertEquals("J", b.h.get(1));
        assertEquals("k", b.h.get(2));
    }

}