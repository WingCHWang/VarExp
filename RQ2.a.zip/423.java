public class A {
private String getKeyStoreReportXml()
	    throws CryptoException, ParserConfigurationException, TransformerException
	{

// the output stream the XML to write to the output stream to write to
		StringWriter xml = new StringWriter();
		Transformer tr = TF_FACTORY.newTransformer();
		tr.setOutputProperties(TF_PROPS);
		tr.transform(new DOMSource(generateDocument()), new StreamResult(xml));
		return xml.toString();
	}

}