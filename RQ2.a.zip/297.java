public class A {
public void actionPerformed(ActionEvent e) {

// the action command. the command name. the action command
		String ac = e.getActionCommand();
//		System.out.println("ac." + ac);
		if (ac.equals("Insert / Update data")) {
			(new DatabaseFrame()).retrieveTableDetails();
		} else {
			ConstraintDailog.setSelectedTableName(selectedTableName);
			ConstraintDailog dialog = new ConstraintDailog();

			dialog.setVisible(true);
		}

	}

}