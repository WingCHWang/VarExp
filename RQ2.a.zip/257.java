public class A {
@Before
    public void setUp() {
        eventStudio().broadcast(new SetLocaleEvent(Locale.UK.toLanguageTag()));

// the pdf the pdf. the PDF
        OpenButton button = new OpenButton(MODULE_ID, ModuleInputOutputType.SINGLE_PDF);
        victim = new Footer(new RunButton(), button, MODULE_ID);
    }

}