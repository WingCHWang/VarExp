public class A {
private String getMicrosoftCAVersionStringValue(byte[] bValue)
	    throws IOException
	{

// the version the cert version the Microsoft Certificate Version
		int ver = ((ASN1Integer) ASN1Primitive.fromByteArray(bValue)).getValue().intValue();
		String certIx = String.valueOf(ver & 0xffff); // low 16 bits
		String keyIx = String.valueOf(ver >> 16); // high 16 bits
		StringBuilder sb = new StringBuilder();
		sb.append(MessageFormat.format(RB.getString("MsftCaVersionCert"), certIx));
		sb.append("<br><br>");
		sb.append(MessageFormat.format(RB.getString("MsftCaVersionKey"), keyIx));
		return sb.toString();
	}

}