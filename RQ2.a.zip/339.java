public class A {
@Test
    public void testHashCode() {

// a {@link java.lang.Object} object. a {@link java.lang.Number} object. a {@link java.lang.Integer} object.
        Percent p1 = new Percent(1);
        Percent p2 = new Percent(2);
        Percent p3 = new Percent(1);
        Percent p4 = new Percent(1.000);
        Percent p5 = new Percent(1.00000001);


        assertEquals(p1.hashCode(), p1.hashCode());
        assertEquals(p1.hashCode(), p3.hashCode());
        assertEquals(p1.hashCode(), p4.hashCode());
        assertNotEquals(p1.hashCode(), p2.hashCode());
        assertNotEquals(p1.hashCode(), p5.hashCode());
    }

}