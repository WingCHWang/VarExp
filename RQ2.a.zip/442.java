public class A {
public static Collection<Provider> getPkcs11Providers()
	{

// the current security context. the current security context the provider to search for.
		TreeMap<String, Provider> p11s = new TreeMap<>();
		for (Provider prov : Security.getProviders())
		{
			String pName = prov.getName();
			// Is it a PKCS #11 provider?
			/*
			 * TODO: is there a better way to find out? Could try instanceof sun.security.pkcs11.SunPKCS11 but that
			 * would require the class to be available?
			 */
			if (pName.startsWith("SunPKCS11-"))
			{
				p11s.put(pName, prov);
			}
		}
		return p11s.values();
	}

}