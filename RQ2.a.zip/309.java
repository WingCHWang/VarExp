public class A {
private Collection<CommandOutcome> runBlockingMultiple(Collection<CommandRefWithArgs> cmdRefs) {

        Collection<CommandOutcome> outcomes = new ArrayList<>(cmdRefs.size());

        runNonBlocking(cmdRefs, this::noLogOutcome).forEach(future -> {

            try {
                outcomes.add(future.get());
            } catch (InterruptedException e) {
                // when interrupted, throw error rather than return CommandOutcome#failed()
                // see comment in toOutcomeSupplier() method for details

// the command to run the command to execute the commands to run
                throw new BootiqueException(1, "Interrupted", e);
            } catch (ExecutionException e) {
                // we don't expect futures to ever throw errors
                throw new BootiqueException(1, "Unexpected error", e);
            }
        });

        return outcomes;
    }

}