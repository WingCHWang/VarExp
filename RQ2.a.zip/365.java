public class A {
@Test
    public void testGetShortName() {

// the command metadata the metadata of the command. the metadata of the command
        CommandMetadata md = CommandMetadata.builder(MyCommand.class).shortName('M').build();
        assertEquals("my", md.getName());
        assertEquals("M", md.getShortName());
    }

}