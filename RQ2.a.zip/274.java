public class A {
@Override
    public void resetView() {
        super.resetView();
        version.resetView();
        compress.setSelected(true);

// the component. the view. the current view.
        discardBookmarks.ifPresent(c -> c.setSelected(false));
    }

}