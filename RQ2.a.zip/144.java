public class A {
@Test
    public void testNoSuppressions() throws Exception {
        final FilterSet fc =
            SuppressionsLoader.loadSuppressions(getPath("InputSuppressionsLoaderNone.xml"));

// the {@link FilterSet} to test. the {@link FilterSet} to test The filter set to test.
        final FilterSet fc2 = new FilterSet();
        assertWithMessage("No suppressions should be loaded, but found: " + fc.getFilters().size())
            .that(fc.getFilters())
            .isEqualTo(fc2.getFilters());
    }

}