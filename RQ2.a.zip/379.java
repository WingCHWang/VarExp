public class A {
protected void checkStartupSucceeded(long timeout, TimeUnit unit) {


// the timeout in milliseconds the time in milliseconds the number of milliseconds to wait
        long startedWaitingMs = System.currentTimeMillis();
        long timeoutMs = unit.toMillis(timeout);

        Future<CommandOutcome> startupFuture = executor.submit(() -> {

            try {
                for (int i = 0; i < Integer.MAX_VALUE; i++) {

                    Optional<CommandOutcome> optOutcome = checkStartupOutcome();
                    if (optOutcome.isPresent()) {
                        return optOutcome.get();
                    }

                    long remainingTimeout = timeoutMs - (System.currentTimeMillis() - startedWaitingMs);
                    Thread.sleep(startupCheckSleepInterval(remainingTimeout, i));
                }

                // should never end up here with any reasonable timeouts
                return CommandOutcome.failed(-1, "Exceeded the number of attempts to check for successful startup");

            } catch (InterruptedException e) {
                logger.stderr("Interrupted waiting for server to start.. one last check..");
                return checkStartupOutcome().orElse(CommandOutcome.failed(-1, e));
            } catch (Throwable th) {
                logger.stderr("Server error", th);
                return CommandOutcome.failed(-1, th);
            }
        });

        CommandOutcome outcome;
        try {
            outcome = startupFuture.get(timeout, unit);
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            throw new RuntimeException(String.format("Daemon failed to start in %s ms", unit.toMillis(timeout)));
        }

        if (outcome.isSuccess()) {
            logger.stderr("Daemon runtime started...");
        } else {
            throw new BootiqueException(outcome.getExitCode(), "Daemon failed to start: " + outcome);
        }
    }

}