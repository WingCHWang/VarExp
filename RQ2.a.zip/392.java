public class A {
private Cli createCli(String args) {
        String[] argsArray = args.split(" ");

        CommandManager commandManager = new DefaultCommandManager(commands);


// the application metadata the application the application to use
        ApplicationMetadata.Builder appBuilder = ApplicationMetadata.builder();
        commands.values().forEach(mc -> appBuilder.addCommand(mc.getCommand().getMetadata()));

        return new JoptCliFactory(() -> commandManager, appBuilder.build()).createCli(argsArray);
    }

}