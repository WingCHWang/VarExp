public class A {
@Test
    public void equalsAndHashCodes() {
        LocaleKeyValueItem eq1 = new LocaleKeyValueItem(Locale.CANADA);
        LocaleKeyValueItem eq2 = new LocaleKeyValueItem(Locale.CANADA);
        LocaleKeyValueItem eq3 = new LocaleKeyValueItem(Locale.CANADA);

// the locales and hash codes to compare the locales and hash codes to compare. The locale and hash codes to compare.
        LocaleKeyValueItem diff = new LocaleKeyValueItem(Locale.CHINA);
        TestUtils.testEqualsAndHashCodes(eq1, eq2, eq3, diff);
    }

}