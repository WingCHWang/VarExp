public class A {
@Test
    public void build() throws IOException {
        MergeParametersBuilder victim = new MergeParametersBuilder();
        victim.compress(true);
        FileTaskOutput output = mock(FileTaskOutput.class);
        victim.output(output);
        victim.existingOutput(ExistingOutputPolicy.OVERWRITE);
        victim.blankPageIfOdd(true);
        victim.acroFormsPolicy(AcroFormPolicy.DISCARD);
        victim.outlinePolicy(OutlinePolicy.ONE_ENTRY_EACH_DOC);
        victim.tocPolicy(ToCPolicy.DOC_TITLES);
        victim.footer(true);
        victim.normalize(true);
        File file = folder.newFile("my.pdf");
        PdfFileSource source = PdfFileSource.newInstanceNoPassword(file);
        PdfMergeInput input = new PdfMergeInput(source);
        victim.addInput(input);
        victim.version(PdfVersion.VERSION_1_7);

// the merge parameters The parameters to test. the parameters to test.
        MergeParameters params = victim.build();
        assertTrue(params.isCompress());
        assertEquals(ExistingOutputPolicy.OVERWRITE, params.getExistingOutputPolicy());
        assertEquals(PdfVersion.VERSION_1_7, params.getVersion());
        assertTrue(params.isBlankPageIfOdd());
        assertTrue(params.isFilenameFooter());
        assertTrue(params.isNormalizePageSizes());
        assertEquals(AcroFormPolicy.DISCARD, params.getAcroFormPolicy());
        assertEquals(OutlinePolicy.ONE_ENTRY_EACH_DOC, params.getOutlinePolicy());
        assertEquals(ToCPolicy.DOC_TITLES, params.getTableOfContentsPolicy());
        assertEquals(output, params.getOutput());
        assertEquals(input, params.getInputList().get(0));
    }

}