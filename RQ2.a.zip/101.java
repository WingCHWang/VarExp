public class A {
public static PackageObjectFactory getPackageObjectFactory() throws CheckstyleException {

// the class loader to use the class loader the classloader to use
        final ClassLoader cl = TestUtil.class.getClassLoader();
        final Set<String> packageNames = PackageNamesLoader.getPackageNames(cl);
        return new PackageObjectFactory(packageNames, cl);
    }

}