public class A {
@Override
    public void restoreStateFrom(Map<String, String> data) {
        field.setText(Optional.ofNullable(data.get("size")).orElse(EMPTY));

// a {@link java.util.Map} object. a {@link java.util.Map} object containing the data. a {@link java.util.Map} containing the data.
        group.getToggles().stream().map(t -> {
            return (SizeUnitRadio) t;
        }).forEach(s -> s.restoreStateFrom(data));
    }

}