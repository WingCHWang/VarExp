public class A {
@Test
    public void testIllegalClassNames() throws Exception {
        final String[] expected = {

// The message to use in the exception message. the message to use in the exception message. The message to use for the test.
            "14:11: " + getCheckMessage(MSG_KEY, "Exception"),
            "15:11: " + getCheckMessage(MSG_KEY, "Throwable"),
            "22:11: " + getCheckMessage(MSG_KEY, "java.lang.Exception"),
            "23:11: " + getCheckMessage(MSG_KEY, "java.lang.Throwable"),
        };

        verifyWithInlineConfigParser(
                getPath("InputIllegalCatch3.java"), expected);
    }

}