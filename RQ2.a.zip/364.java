public class A {
protected URL resolveUrl(String resourceId) {

        // resourceId can be either a file path or a URL or a classpath: URL

        if (resourceId.startsWith(CLASSPATH_URL_PREFIX)) {

            String path = resourceId.substring(CLASSPATH_URL_PREFIX.length());

            // classpath URLs must not start with a slash. This does not work
            // with ClassLoader.
            if (path.length() > 0 && path.charAt(0) == '/') {
                throw new RuntimeException(CLASSPATH_URL_PREFIX + " URLs must not start with a slash: " + resourceId);
            }


// the resource url the resource id the resource id to resolve
            URL cpUrl = ResourceFactory.class.getClassLoader().getResource(path);

            if (cpUrl == null) {
                throw new IllegalArgumentException("Classpath URL not found: " + resourceId);
            }

            return cpUrl;
        }

        URI uri;
        try {
            uri = URI.create(resourceId);
        } catch (IllegalArgumentException e) {
            throw new BootiqueException(1, "Invalid config resource url: " + resourceId, e);
        }
        try {
            return uri.isAbsolute() ? uri.toURL() : getCanonicalFile(resourceId).toURI().toURL();
        } catch (IOException e) {
            throw new BootiqueException(1, "Invalid config resource url: " + resourceId, e);
        }
    }

}