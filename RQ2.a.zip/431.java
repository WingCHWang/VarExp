public class A {
private String getKeyUsageStringValue(byte[] bValue)
	    throws IOException
	{

// the key usage value to get the string representation of. the value to get the string representation of. the key usage value.
		int val = ((DERBitString) ASN1Primitive.fromByteArray(bValue)).intValue();
		StringBuilder strBuff = new StringBuilder();
		for (int type : KEY_USAGES)
		{
			if ((val & type) == type)
			{
				if (strBuff.length() != 0)
				{
					strBuff.append("<br><br>");
				}
				strBuff.append(RB.getString("KeyUsage." + type));
			}
		}
		return strBuff.toString();
	}

}