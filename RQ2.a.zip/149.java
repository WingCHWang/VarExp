public class A {
@Test
    public void testRemoveBeforeExecutionFileFilter() throws Exception {
        final Checker checker = new Checker();
        final TestBeforeExecutionFileFilter filter = new TestBeforeExecutionFileFilter();

// the file filter The file filter. The file filter
        final TestBeforeExecutionFileFilter f2 = new TestBeforeExecutionFileFilter();
        checker.addBeforeExecutionFileFilter(filter);
        checker.addBeforeExecutionFileFilter(f2);
        checker.removeBeforeExecutionFileFilter(filter);

        f2.resetFilter();
        checker.process(Collections.singletonList(new File("dummy.java")));
        assertWithMessage("Checker.acceptFileStarted() doesn't call filter")
                .that(f2.wasCalled())
                .isTrue();
        assertWithMessage("Checker.acceptFileStarted() does call removed filter")
                .that(filter.wasCalled())
                .isFalse();
    }

}