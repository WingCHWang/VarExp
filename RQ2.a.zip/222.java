public class A {
private void initDialogsOwner(Stage primaryStage) {

// the dialogs owner the dialogs owner. the dialog owner
        injector.instancesOfType(ConfirmationDialog.class).stream().forEach(d -> d.setOwner(primaryStage));
        injector.instance(OpenWithDialog.class).setOwner(primaryStage);
    }

}