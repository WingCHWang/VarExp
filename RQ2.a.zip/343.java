public class A {
protected Collection<HelpOption> collectOptions() {

        HelpOptions helpOptions = new HelpOptions();

        application.getCommands().forEach(c -> {

            // for now expose commands as simply options (commands are options in a default CLI parser)
            helpOptions.add(c.asOption());

// the help option the option the option to add
            c.getOptions().forEach(o -> helpOptions.add(o));
        });

        application.getOptions().forEach(o -> helpOptions.add(o));
        return helpOptions.getOptions();
    }

}