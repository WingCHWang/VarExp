public class A {
@Test
    public void testConfig_Nested() {

// a {@link org.springframework.beans.factory. a {@link org.springframework.beans.config. the Bean2 to be nested
        Bean2 b2 = factory("b1:\n  s: SS\n  i: 55").config(Bean2.class, "");
        assertNotNull(b2);
        assertNotNull(b2.getB1());
        assertEquals("SS", b2.getB1().getS());
        assertEquals(55, b2.getB1().getI());
    }

}