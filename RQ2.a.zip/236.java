public class A {
@Test
    public void getTextValue() {

// a {@link com.google.gwt.user.client. a {@link PdfDescriptorLoadingStatus} object. a {@link PdfDescriptorLoadingStatus} object
        Arrays.stream(PdfDescriptorLoadingStatus.values()).forEach(s -> {
            if (s.getIcon() != null) {
                assertEquals(s.getIcon().toString(), victim.getTextValue(s));
            } else {
                assertEquals("", victim.getTextValue(s));
            }
        });

    }

}