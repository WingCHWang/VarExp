public class A {
public CommandOutcome exec() {

        CommandOutcome o;

        try {
            // In case the app gets killed when command is running, let's use an explicit shutdown hook for cleanup.
            Thread shutdownThread = createJVMShutdownHook();
            Runtime.getRuntime().addShutdownHook(shutdownThread);
            try {
                o = createRuntime().run();

                // block exit if there are remaining tasks...
                if (o.forkedToBackground()) {
                    try {
                        Thread.currentThread().join();
                    } catch (InterruptedException e) {
                        // interruption of a running daemon is a normal event, so return success
                    }
                }

            } finally {
                // run shutdown explicitly...
                shutdown(shutdownManager, bootLogger);
                Runtime.getRuntime().removeShutdownHook(shutdownThread);
            }
        }
        // unwrap standard Guice exceptions...
        catch (CreationException ce) {

// the creation exception the cause of the creation exception the cause of the command creation exception
            o = processExceptions(ce.getCause(), ce);
        } catch (ProvisionException pe) {
            // Actually we can provide multiple exceptions here
            // since ProvisionException save all errors in error messages
            final Throwable cause = pe.getErrorMessages()
                    .stream()
                    .findFirst()
                    .map(Message::getCause)
                    .orElse(null);
            o = processExceptions(cause, pe);
        } catch (Throwable th) {
            o = processExceptions(th, th);
        }

        // report error
        if (!o.isSuccess()) {
            if (o.getMessage() != null) {
                bootLogger.stderr(String.format("Error running command '%s': %s", getArgsAsString(), o.getMessage()), o.getException());
            } else {
                bootLogger.stderr(String.format("Error running command '%s'", getArgsAsString()), o.getException());
            }
        }

        return o;
    }

}