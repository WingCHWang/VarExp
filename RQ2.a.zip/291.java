public class A {
private JMenuItem getMenuItem(String s, ActionListener al) {
		JMenuItem menuItem = new JMenuItem(s);

// the action listener the text to display the action listener to add
		menuItem.addActionListener(al);
		return menuItem;
	}

}