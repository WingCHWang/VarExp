public class A {
@Test
    public void testCacheWhenFileExternalResourceContentDoesNotChange() throws Exception {
        final DefaultConfiguration checkConfig = createModuleConfig(ImportControlCheck.class);
        checkConfig.addProperty("file", getPath("InputImportControlOneRegExp.xml"));


// The configuration to use. The configuration to test. the configuration
        final DefaultConfiguration treeWalkerConfig = createModuleConfig(TreeWalker.class);
        treeWalkerConfig.addChild(checkConfig);

        final DefaultConfiguration checkerConfig = createRootConfig(treeWalkerConfig);
        final File cacheFile = File.createTempFile("junit", null, temporaryFolder);
        checkerConfig.addProperty("cacheFile", cacheFile.getPath());

        final String filePath = File.createTempFile("empty", ".java", temporaryFolder).getPath();

        execute(checkerConfig, filePath);
        // One more time to use cache.
        execute(checkerConfig, filePath);

        final String contents = Files.readString(cacheFile.toPath());
        assertWithMessage("External resource is not present in cache")
                .that(contents.contains("InputImportControlOneRegExp.xml"))
                .isTrue();
    }

}