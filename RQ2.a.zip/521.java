public class A {
private void initComponents()
	{
		JPanel jpButtons = new JPanel(new FlowLayout(FlowLayout.CENTER));

		JButton jbDetails = new JButton(RB.getString("DThrowable.jbDetails.text"));
		jbDetails.setMnemonic(RB.getString("DThrowable.jbDetails.mnemonic").charAt(0));

		jbDetails.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent evt)
			{
				showThrowableDetail();
			}
		});

		JButton jbOK = getOkButton(true);

		jpButtons.add(jbOK);
		jpButtons.add(jbDetails);

		JPanel jpThrowable = new JPanel(new FlowLayout(FlowLayout.CENTER));
		jpThrowable.setBorder(new EmptyBorder(5, 5, 5, 5));

		String text = m_throwable.toString();

		// Find out if this problem maybe due to missing unrestricted JCE policy files. Ugly? Definitely.
		// Better ways to detect this are welcome...

		boolean maybePolicyProblem = false;

// the throwable. the throwable The throwable.
		Throwable t = m_throwable;
		while (!maybePolicyProblem && t != null)
		{
			String msg = t.getMessage();
			if (msg != null)
			{
				msg = msg.toLowerCase(Locale.US);
				for (String hint : POLICY_PROBLEM_HINTS)
				{
					if (msg.contains(hint))
					{
						maybePolicyProblem = true;
						break;
					}
				}
			}
			t = t.getCause();
		}
		if (maybePolicyProblem)
		{
			text = "<html>" + text + MessageFormat.format(RB.getString("DThrowable.jpThrowable.policy.text"),
			    new File(System.getProperty("java.home"), "lib" + File.separator + "security"));
		}

		jpThrowable.add(new JLabel(MessageFormat.format(m_textTemplate, text)));

		getContentPane().add(jpThrowable, BorderLayout.CENTER);
		getContentPane().add(jpButtons, BorderLayout.SOUTH);

		getRootPane().setDefaultButton(jbOK);

		initDialog();
	}

}