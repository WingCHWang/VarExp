public class A {
public boolean canMoveTo(PdfDescriptorLoadingStatus dest) {

// the destination descriptor the destination the destination descriptor.
        return validNext.contains(dest);
    }

}