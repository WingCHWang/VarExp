public class A {
@Test
    public void testProvider() {
        ModulesMetadata md = runtimeFactory.app()
                .module(new M1Provider())
                .createRuntime().getInstance(ModulesMetadata.class);

        assertEquals("Expected BQCoreModule + 2 test modules + custom module", 4, md.getModules().size());


// the module the m the module to test
        Optional<ModuleMetadata> m1Md = md.getModules()
                .stream()
                .filter(m -> "M1Module".equals(m.getName()))
                .findFirst();
        assertTrue(m1Md.isPresent());
    }

}