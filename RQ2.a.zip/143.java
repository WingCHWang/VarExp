public class A {
@Test
    public void testNoModuleFactory() throws Exception {
        final Checker checker = new Checker();
        final ClassLoader classLoader = Thread.currentThread().getContextClassLoader();

        checker.setModuleClassLoader(classLoader);
        checker.finishLocalSetup();

// The current context The current context. The context to test.
        final Context actualCtx = TestUtil.getInternalState(checker, "childContext");

        assertWithMessage("Default module factory should be created when it is not specified")
            .that(actualCtx.get("moduleFactory"))
            .isNotNull();
    }

}