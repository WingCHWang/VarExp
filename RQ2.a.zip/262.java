public class A {
@Test
    public void allowBlank() {

// file type the html file file type.
        Validator<String> victim = Validators.existingFileType(FileType.HTML);
        Assert.assertFalse(victim.isValid(""));
        Assert.assertTrue(Validators.validEmpty(victim).isValid(""));
    }

}