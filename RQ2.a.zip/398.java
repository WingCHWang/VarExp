public class A {
@Test
    public void testVisitListOfObjects() {


// the list of objects to be visited. the list of objects to visit. the list of objects to be visited
        ConfigObjectMetadata listMd2 = ConfigObjectMetadata.builder()
                .type(ConfigRoot2.class)
                .addProperty(ConfigValueMetadata.builder("p4").type(String.class).build())
                .addProperty(ConfigValueMetadata.builder("p3").type(Boolean.TYPE).build())
                .build();

        ConfigObjectMetadata m1Config = ConfigObjectMetadata
                .builder("m1root")
                .description("Root config of M1")
                .type(ConfigRoot1.class)
                .addProperty(ConfigListMetadata.builder("p2").elementType(listMd2).description("I am a list").build())
                .build();

        assertLines(m1Config,
                "m1root:",
                "      #",
                "      # Root config of M1",
                "      # Resolved as 'io.bootique.help.config.ConfigSectionGeneratorTest$ConfigRoot1'.",
                "      #",
                "",
                "      p2:",
                "            #",
                "            # I am a list",
                "            # Resolved as 'List'.",
                "            #",
                "            -",
                "                  #",
                "                  # Resolved as 'io.bootique.help.config.ConfigSectionGeneratorTest$ConfigRoot2'.",
                "                  #",
                "",
                "                  p3: <true|false>",
                "                  p4: <string>"
        );
    }

}