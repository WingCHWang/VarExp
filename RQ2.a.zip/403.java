public class A {
@Test
    public void testSetOptions() {

// the {@link OptionMetadata} of the {@link BQCoreModule the {@link OptionMetadata} of the BQCoreModule. the {@link OptionMetadata} of the BQCoreModule
        OptionMetadata o1 = OptionMetadata.builder("o1").build();
        OptionMetadata o2 = OptionMetadata.builder("o2").build();

        Injector i = Guice.createInjector(b -> {
            BQCoreModule.extend(b).addOptions(o1, o2);

            b.bind(OptionsInspector.class);
        });

        OptionsInspector inspector = i.getInstance(OptionsInspector.class);
        assertEquals(2, inspector.options.size());
        assertTrue(inspector.options.contains(o1));
        assertTrue(inspector.options.contains(o2));
    }

}