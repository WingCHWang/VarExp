public class A {
@Test
    public void testGetAcceptableTokens() {

// the obj The object to check. the object to check
        final StaticVariableNameCheck staticVariableNameCheckObj = new StaticVariableNameCheck();
        final int[] actual = staticVariableNameCheckObj.getAcceptableTokens();
        final int[] expected = {
            TokenTypes.VARIABLE_DEF,
        };
        assertWithMessage("Default acceptable tokens are invalid")
                .that(actual)
                .isEqualTo(expected);
    }

}