public class A {
@Test
    public void disableMenuOnSwitchToInvalid() throws Exception {
        typePathAndValidate();
        typePathAndValidate("/this/doesnt/exists");
        ValidableTextField victim = lookup(".validable-container-field").queryAs(ValidableTextField.class);

// a {@link ValidableTextField} object. a {@link ValidableTextField} instance. a {@link ValidableTextField}
        victim.getContextMenu().getItems().parallelStream().filter(i -> !(i instanceof SeparatorMenuItem))
                .filter(i -> !i.getText().equals(DefaultI18nContext.getInstance().i18n("Remove")))
                .forEach(i -> assertTrue(i.isDisable()));
    }

}