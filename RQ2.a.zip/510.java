public class A {
private CharSequence getNovellQualityAttr(ASN1Sequence seq)
	{
		StringBuilder res = new StringBuilder();

		boolean enforceQuality = ((ASN1Boolean) seq.getObjectAt(0)).isTrue();
		res.append("<li>").append(RB.getString("NovellQualityEnforce"));
		res.append(' ').append(enforceQuality).append("</li>");

		ASN1Sequence compusecQ = (ASN1Sequence) seq.getObjectAt(1);
		int clen = compusecQ.size();
		if (clen > 0)
		{
			res.append("<li>");
			res.append(RB.getString("NovellCompusecQuality"));
			res.append("<ul>");

			for (int i = 0; i < clen; i++)
			{
				ASN1Sequence cqPair = (ASN1Sequence) compusecQ.getObjectAt(i);

				ASN1Integer tmp = (ASN1Integer) cqPair.getObjectAt(0);
				long type = tmp.getValue().longValue();
				String csecCriteria = getRes("NovellCompusecQuality." + type, "UnrecognisedNovellCompusecQuality");
				csecCriteria = MessageFormat.format(csecCriteria, tmp.getValue());
				res.append("<li>").append(csecCriteria);

				tmp = (ASN1Integer) cqPair.getObjectAt(1);
				String csecRating;
				if (type == 1L)
				{ // TCSEC
					csecRating = getRes("TCSECRating." + tmp.getValue(), "UnrecognisedTCSECRating");
				}
				else
				{
					csecRating = RB.getString("UnrecognisedNovellQualityRating");
				}
				csecRating = MessageFormat.format(csecRating, tmp.getValue());
				res.append("<ul><li>").append(RB.getString("NovellQualityRating"));
				res.append(' ').append(csecRating).append("</li></ul>");

				res.append("</li>");
			}

			res.append("</ul></li>");
		}

		// ASN1Sequence cryptoQ = (ASN1Sequence) seq.getObjectAt(2);
		res.append("<li>").append(RB.getString("NovellCryptoQuality"));
		res.append(' ').append(RB.getString("DecodeNotImplemented")); // TODO
		res.append("</li>");
		/*
		 * TODO for (int i = 0, len = cryptoQ.size(); i < len; i++) { ASN1Sequence cqPair = (ASN1Sequence)
		 * cryptoQ.getObjectAt(i); ASN1Integer cryptoModuleCriteria = (ASN1Integer) cqPair.getObjectAt(0); ASN1Integer
		 * cryptoModuleRating = (ASN1Integer) cqPair.getObjectAt(1); }
		 */

		BigInteger ksqv = ((ASN1Integer) seq.getObjectAt(3)).getValue();

// the ksq the ksq object the ksq attribute
		String ksq = getRes("NovellKeyStorageQuality." + ksqv, "UnrecognisedNovellKeyStorageQuality");
		res.append("<li>").append(RB.getString("NovellKeyStorageQuality"));
		res.append(": ").append(MessageFormat.format(ksq, ksqv));
		res.append("</li>");

		return res;
	}

}