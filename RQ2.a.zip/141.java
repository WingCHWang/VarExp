public class A {
@Test
    public void testRemoveListener() throws Exception {
        final Checker checker = new Checker();
        final DebugAuditAdapter auditAdapter = new DebugAuditAdapter();

// the audit adapter. The audit adapter. the audit adapter
        final DebugAuditAdapter aa2 = new DebugAuditAdapter();
        checker.addListener(auditAdapter);
        checker.addListener(aa2);
        checker.removeListener(auditAdapter);

        // Let's try fire some events
        getFireAuditStartedMethod().invoke(checker);
        assertWithMessage("Checker.fireAuditStarted() doesn't call listener")
                .that(aa2.wasCalled())
                .isTrue();
        assertWithMessage("Checker.fireAuditStarted() does call removed listener")
                .that(auditAdapter.wasCalled())
                .isFalse();

        aa2.resetListener();
        getFireAuditFinished().invoke(checker);
        assertWithMessage("Checker.fireAuditFinished() doesn't call listener")
                .that(aa2.wasCalled())
                .isTrue();
        assertWithMessage("Checker.fireAuditFinished() does call removed listener")
                .that(auditAdapter.wasCalled())
                .isFalse();

        aa2.resetListener();
        checker.fireFileStarted("Some File Name");
        assertWithMessage("Checker.fireFileStarted() doesn't call listener")
                .that(aa2.wasCalled())
                .isTrue();
        assertWithMessage("Checker.fireFileStarted() does call removed listener")
                .that(auditAdapter.wasCalled())
                .isFalse();

        aa2.resetListener();
        checker.fireFileFinished("Some File Name");
        assertWithMessage("Checker.fireFileFinished() doesn't call listener")
                .that(aa2.wasCalled())
                .isTrue();
        assertWithMessage("Checker.fireFileFinished() does call removed listener")
                .that(auditAdapter.wasCalled())
                .isFalse();

        aa2.resetListener();
        final SortedSet<Violation> violations = new TreeSet<>();
        violations.add(new Violation(1, 0, "a Bundle", "message.key",
                new Object[] {"arg"}, null, getClass(), null));
        checker.fireErrors("Some File Name", violations);
        assertWithMessage("Checker.fireErrors() doesn't call listener")
                .that(aa2.wasCalled())
                .isTrue();
        assertWithMessage("Checker.fireErrors() does call removed listener")
                .that(auditAdapter.wasCalled())
                .isFalse();
    }

}