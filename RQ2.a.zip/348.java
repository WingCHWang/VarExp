public class A {
protected void testAutoLoadable() {


// the number of providers that are expected to be auto-loaded. the number of providers to test. the number of providers that are expected to be auto-loaded
        Long c = matchingProviders().collect(counting());

        switch (c.intValue()) {
            case 0:
                fail("Expected provider '" + provider.getName() + "' is not found");
                break;
            case 1:
                break;
            default:
                fail("Expected provider '" + provider.getName() + "' is found more then once: " + c);
                break;
        }
    }

}