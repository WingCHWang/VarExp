public class A {
@Test
    public void focusedField() {
        RadioButton radio = lookup("RADIO").queryAs(RadioButton.class);
        TextField field = lookup(".FIELD").queryAs(TextField.class);
        clickOn(radio).write("Chuck");

// the field the field to be checked the field to be checked.
        verifyThat(field, (f) -> "Chuck".equals(f.getText()));
    }

}