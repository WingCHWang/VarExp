public class A {
public static void main(String[] args)
	{
		// Make Metal theme use non-bold fonts (see javax.swing.plaf.metal.MetalLookAndFeel javadoc)
		UIManager.put("swing.boldMetal", Boolean.FALSE);

		try
		{

// the provider the prov the PROV
			Provider bcProv = Security.getProvider("BC");

			if (bcProv == null)
			{
				// Instantiate the Bouncy Castle provider
				Class<?> bcProvClass = Class.forName("org.bouncycastle.jce.provider.BouncyCastleProvider");
				bcProv = (Provider) bcProvClass.newInstance();

				// Add BC as a security provider
				Security.addProvider(bcProv);
			}

			// Check BC version
			Double bcVer = bcProv.getVersion();
			if (REQ_BC_VERSION.compareTo(bcVer) > 0)
			{
				JOptionPane.showMessageDialog(new JFrame(),
				    MessageFormat.format(RB.getString("FPortecle.NoBcVersion.message"), REQ_BC_VERSION, bcVer),
				    RB.getString("FPortecle.Title"), JOptionPane.WARNING_MESSAGE);
			}
		}
		catch (Throwable thw)
		{
			// No sign of the provider - warn the user and exit
			LOG.log(Level.SEVERE, "FPortecle.NoLoadBc.message", thw);
			JOptionPane.showMessageDialog(new JFrame(), RB.getString("FPortecle.NoLoadBc.message"),
			    RB.getString("FPortecle.Title"), JOptionPane.ERROR_MESSAGE);
			System.exit(1);
		}

		// Install additional providers
		String[] additionalProviders = RB.getString("FPortecle.AdditionalProviders").split("[\\s,]+");
		for (String addProv : additionalProviders)
		{
			String[] prov = addProv.split(":+", 2);
			if (Security.getProvider(prov[0]) == null)
			{
				try
				{
					Class<?> provClass = Class.forName(prov[1]);
					Security.addProvider((Provider) provClass.newInstance());
				}
				catch (Throwable t)
				{
					// TODO: should maybe notify in some cases?
					// E.g. Throwable, but not Exception?
				}
			}
		}

		// If arguments have been supplied, treat the first one that's not "-open" (web start passes that when
		// opening associated files) as a keystore/certificate etc file
		Object toOpen = null;
		for (String arg : args)
		{
			if (!arg.equals("-open"))
			{
				if (arg.matches("^[\\w.]+:\\d+$"))
				{
					String host = arg.substring(0, arg.indexOf(":"));
					int port = Integer.parseInt(arg.substring(arg.indexOf(":") + 1));
					toOpen = new InetSocketAddress(host, port);
				}
				else
				{
					toOpen = new File(arg);
				}
				break;
			}
		}

		// Create and show GUI on the event handler thread
		SwingUtilities.invokeLater(new CreateAndShowGui(toOpen));
	}

}