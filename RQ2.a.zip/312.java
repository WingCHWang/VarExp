public class A {
@Test(expected = IllegalArgumentException.class)
    public void testLookupByName_Missing() {

        Map<String, ManagedCommand> map = new HashMap<>();
        map.put("c1", ManagedCommand.forCommand(c1));


// the cm a {@link DefaultCommandManager} a {@link DefaultCommandManager} object.
        DefaultCommandManager cm = new DefaultCommandManager(map);
        cm.lookupByName("c2");
    }

}