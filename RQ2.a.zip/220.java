public class A {
@java.lang.Override
    public boolean equals(final java.lang.Object obj) {

// {@inheritDoc} the {@link java.lang.Object} to compare to this one the {@link java.lang.Object} to compare with.
      if (obj == this) {
       return true;
      }
      if (!(obj instanceof retrofit2.converter.protobuf.PhoneProtos.Phone)) {
        return super.equals(obj);
      }
      retrofit2.converter.protobuf.PhoneProtos.Phone other = (retrofit2.converter.protobuf.PhoneProtos.Phone) obj;

      boolean result = true;
      result = result && (hasNumber() == other.hasNumber());
      if (hasNumber()) {
        result = result && getNumber()
            .equals(other.getNumber());
      }
      result = result && unknownFields.equals(other.unknownFields);
      result = result &&
          getExtensionFields().equals(other.getExtensionFields());
      return result;
    }

}