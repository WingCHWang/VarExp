public class A {
private String getMicrosoftPreviousCACertificateHashStringValue(byte[] bValue)
	    throws IOException
	{

// the string value of the Microsoft Certificate Authority Certificate hash value. the string value of the Microsoft Certificate Authority Certificate hash value the string value of the Microsoft Certificate Authority certificate hash value.
		DEROctetString derOctetStr = (DEROctetString) ASN1Primitive.fromByteArray(bValue);
		byte[] bKeyIdent = derOctetStr.getOctets();

		return convertToHexString(bKeyIdent);
	}

}