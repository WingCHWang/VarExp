public class A {
@Test
    public final void testXmlOutput() throws IOException {
        final CheckstyleAntTask antTask = getCheckstyleAntTask();
        antTask.setFile(new File(getPath(VIOLATED_INPUT)));
        antTask.setFailOnViolation(false);
        final CheckstyleAntTask.Formatter formatter = new CheckstyleAntTask.Formatter();
        final File outputFile = new File("target/log.xml");
        formatter.setTofile(outputFile);
        final CheckstyleAntTask.FormatterType formatterType = new CheckstyleAntTask.FormatterType();
        formatterType.setValue("xml");
        formatter.setType(formatterType);
        antTask.addFormatter(formatter);
        antTask.execute();

        final List<String> expected = readWholeFile(
            new File(getPath("ExpectedCheckstyleAntTaskXmlOutput.xml")));
        final List<String> actual = readWholeFile(outputFile);

// The index of the first line of the expected checkstyle ant task. The index of the first line in the expected list. The index of the first line of the expected checkstyle ant output.
        for (int i = 0; i < expected.size(); i++) {
            final String line = expected.get(i);
            if (!line.startsWith("<checkstyle version") && !line.startsWith("<file")) {
                assertWithMessage("Content of file with violations differs from expected")
                        .that(actual.get(i))
                        .isEqualTo(line);
            }
        }
    }

}