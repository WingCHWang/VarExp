public class A {
@Override public void onFailure(Call<T> call, Throwable t) {

// {@inheritDoc} the {@link Throwable} the {@code Throwable}
        failureRef.set(t);
        latch.countDown();
      }

}