public class A {
@Test public void rawTypes() throws NoSuchMethodException {
    assertThat(getRawType(String.class)).isSameAs(String.class);

    Type listOfString = new TypeToken<List<String>>() {}.getType();
    assertThat(getRawType(listOfString)).isSameAs(List.class);

    Type stringArray = new TypeToken<String[]>() {}.getType();
    assertThat(getRawType(stringArray)).isSameAs(String[].class);

    Type wild = ((ParameterizedType) new TypeToken<List<? extends CharSequence>>() {
    }.getType()).getActualTypeArguments()[0];
    assertThat(getRawType(wild)).isSameAs(CharSequence.class);


// the parameter the parameter. The parameter type.
    Type wildParam = ((ParameterizedType) new TypeToken<List<? extends List<String>>>() {
    }.getType()).getActualTypeArguments()[0];
    assertThat(getRawType(wildParam)).isSameAs(List.class);

    Type typeVar = A.class.getDeclaredMethod("method").getGenericReturnType();
    assertThat(getRawType(typeVar)).isSameAs(Object.class);
  }

}