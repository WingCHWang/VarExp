public class A {
@Test
    public void testVisitObjectWithMapOfObjects() {


// The metadata to test. the metadata to test. the object to test.
        ConfigObjectMetadata mapMd = ConfigObjectMetadata.builder()
                .type(ConfigRoot2.class)
                .addProperty(ConfigValueMetadata.builder("p4").type(String.class).build())
                .addProperty(ConfigValueMetadata.builder("p3").type(Boolean.TYPE).build())
                .build();

        ConfigObjectMetadata rootMd = ConfigObjectMetadata
                .builder("m1root")
                .description("Root config of M1")
                .type(ConfigRoot1.class)
                .addProperty(ConfigMapMetadata.builder("p1").keysType(String.class).valuesType(mapMd).build())
                .build();

        assertLines(rootMd,
                "m1root:",
                "      #",
                "      # Root config of M1",
                "      # Resolved as 'io.bootique.help.config.ConfigSectionGeneratorTest$ConfigRoot1'.",
                "      #",
                "",
                "      p1:",
                "            #",
                "            # Resolved as 'Map'.",
                "            #",
                "            <string>:",
                "                  #",
                "                  # Resolved as 'io.bootique.help.config.ConfigSectionGeneratorTest$ConfigRoot2'.",
                "                  #",
                "",
                "                  p3: <true|false>",
                "                  p4: <string>"
        );
    }

}