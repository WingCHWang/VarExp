public class A {
@Override
    public void apply(RotateParametersBuilder builder, Consumer<String> onError) {
        try {

// {@inheritDoc} the {@link RotateParametersBuilder} the {@link RotateParametersBuilder} to apply.
            table().getItems().stream().filter(s -> !Objects.equals("0", trim(s.pageSelection.get())))
                    .forEach(i -> builder.addInput(i.descriptor().toPdfFileSource(), i.toPageRangeSet()));
            if (!builder.hasInput()) {
                onError.accept(DefaultI18nContext.getInstance().i18n("No PDF document has been selected"));
            }
        } catch (ConversionException e) {
            LOG.error(e.getMessage());
            onError.accept(e.getMessage());
        }
    }

}