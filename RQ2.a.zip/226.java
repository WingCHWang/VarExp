public class A {
@EventListener
    public void onClear(final ClearModuleEvent event) {

// {@inheritDoc} the module descriptor the descriptor
        getItems().forEach(d -> d.descriptor().releaseAll());
        getSelectionModel().clearSelection();
        getItems().clear();
    }

}