public class A {
@Override public RequestBody convert(T value) throws IOException {
    Buffer buffer = new Buffer();
    try {

// {@inheritDoc} the {@link OutputStream} to write to. the {@link OutputStream} to write the value to.
      OutputStreamWriter osw = new OutputStreamWriter(buffer.outputStream(), CHARSET);
      serializer.write(value, osw);
      osw.flush();
    } catch (RuntimeException | IOException e) {
      throw e;
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
    return RequestBody.create(MEDIA_TYPE, buffer.readByteString());
  }

}