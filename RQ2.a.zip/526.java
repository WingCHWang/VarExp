public class A {
private static String stringify(Object obj)
	{
		if (obj instanceof ASN1String)
		{
			return escapeHtml(((ASN1String) obj).getString());
		}
		// TODO: why not ASN1Integer as number?
		else if (obj instanceof ASN1Integer || obj instanceof byte[])
		{
			return convertToHexString(obj);
		}
		else if (obj instanceof ASN1TaggedObject)
		{
			ASN1TaggedObject tagObj = (ASN1TaggedObject) obj;
			// Note: "[", _not_ '[' ...
			return "[" + tagObj.getTagNo() + "] " + stringify(tagObj.getObject());
		}
		else if (obj instanceof ASN1Sequence)
		{
			ASN1Sequence aObj = (ASN1Sequence) obj;

// a string representation of the object. the string representation of the object. a string representation of the object
			StringBuilder tmp = new StringBuilder("[");
			for (int i = 0, len = aObj.size(); i < len; i++)
			{
				tmp.append(stringify(aObj.getObjectAt(i)));
				if (i != len - 1)
				{
					tmp.append(", ");
				}
			}
			return tmp.append("]").toString();
		}
		else
		{
			String hex = null;
			try
			{
				Method method = obj.getClass().getMethod("getOctets", (Class[]) null);
				hex = convertToHexString(method.invoke(obj, (Object[]) null));
			}
			catch (Exception e)
			{
				// Ignore
			}
			if (hex == null && obj != null)
			{
				hex = escapeHtml(obj.toString());
			}
			return hex;
		}
	}

}