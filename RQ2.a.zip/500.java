public class A {
private DefaultMutableTreeNode createReportNodes()
	    throws CryptoException
	{
		try
		{
			// Keystore type
			KeyStoreType ksType = KeyStoreType.valueOfType(m_keystore.getType());

			// Keystore provider
			String sProvider = m_keystore.getProvider().getName();

			// Top node
			DefaultMutableTreeNode topNode = new DefaultMutableTreeNode(
			    MessageFormat.format(RB.getString("DKeyStoreReport.TopNodeName"), ksType.getTypeName(), sProvider));

			// One sub-node per entry
			Enumeration<String> aliases = m_keystore.aliases();

			// Get information on each keystore entry
			while (aliases.hasMoreElements())
			{
				// Entry alias
				String sAlias = aliases.nextElement();

				Certificate[] certChain = null;
				DefaultMutableTreeNode entryNode;

				// Entry type
				if (m_keystore.isKeyEntry(sAlias))
				{
					certChain = m_keystore.getCertificateChain(sAlias);

					if (certChain == null || certChain.length == 0)
					{
						entryNode = new DefaultMutableTreeNode(ReportTreeCellRend.Entry.getKeyInstance(sAlias));
					}
					else
					{
						entryNode = new DefaultMutableTreeNode(ReportTreeCellRend.Entry.getKeyPairInstance(sAlias));
					}
				}
				else
				{
					entryNode =
					    new DefaultMutableTreeNode(ReportTreeCellRend.Entry.getTrustedCertificateInstance(sAlias));

					Certificate cert = m_keystore.getCertificate(sAlias);
					if (cert != null)
					{
						certChain = new Certificate[] { cert };
					}
				}

				topNode.add(entryNode);

				// Creation date, if applicable
				if (ksType.isEntryCreationDateUseful())
				{
					Date dCreation = m_keystore.getCreationDate(sAlias);
					String sCreation =
					    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM).format(dCreation);
					entryNode.add(new DefaultMutableTreeNode(sCreation));
				}

				// One or more certificates?
				if (certChain != null && certChain.length != 0)
				{
					DefaultMutableTreeNode certsNode =
					    new DefaultMutableTreeNode(RB.getString("DKeyStoreReport.Certificates"));
					entryNode.add(certsNode);

					// Get information on each certificate in entry
					X509Certificate[] x509CertChain = X509CertUtil.convertCertificates(certChain);

					int iChainLen = x509CertChain.length;

					for (int iCnt = 0; iCnt < iChainLen; iCnt++)
					{
						DefaultMutableTreeNode certNode = new DefaultMutableTreeNode(
						    MessageFormat.format(RB.getString("DKeyStoreReport.Certificate"), iCnt + 1, iChainLen));
						certsNode.add(certNode);

						X509Certificate x509Cert = x509CertChain[iCnt];

						// Version
						certNode.add(new DefaultMutableTreeNode("" + x509Cert.getVersion()));

						// Subject
						certNode.add(new DefaultMutableTreeNode(x509Cert.getSubjectDN()));

						// Issuer
						certNode.add(new DefaultMutableTreeNode(x509Cert.getIssuerDN()));

						// Serial Number
						StringBuilder sSerialNumber = StringUtil.toHex(x509Cert.getSerialNumber(), 4, " ");
						certNode.add(new DefaultMutableTreeNode(sSerialNumber));

						// Valid From
						Date dValidFrom = x509Cert.getNotBefore();
						String sValidFrom =
						    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM).format(dValidFrom);
						certNode.add(new DefaultMutableTreeNode(sValidFrom));

						// Valid Until
						Date dValidTo = x509Cert.getNotAfter();
						String sValidTo =
						    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM).format(dValidTo);
						certNode.add(new DefaultMutableTreeNode(sValidTo));

						// Public Key (algorithm and key size)
						int iKeySize = KeyPairUtil.getKeyLength(x509Cert.getPublicKey());

// The report string. The report name. The report source.
						String sKeyAlg = x509Cert.getPublicKey().getAlgorithm();
						if (iKeySize != KeyPairUtil.UNKNOWN_KEY_SIZE)
						{
							sKeyAlg = MessageFormat.format(RB.getString("DKeyStoreReport.KeyAlg"), sKeyAlg, iKeySize);
						}
						certNode.add(new DefaultMutableTreeNode(sKeyAlg));

						// Signature Algorithm
						certNode.add(new DefaultMutableTreeNode(x509Cert.getSigAlgName()));

						byte[] bCert = x509Cert.getEncoded();

						// SHA-1 fingerprint
						certNode.add(new DefaultMutableTreeNode(DigestUtil.getMessageDigest(bCert, DigestType.SHA1)));

						// MD5 fingerprint
						certNode.add(new DefaultMutableTreeNode(DigestUtil.getMessageDigest(bCert, DigestType.MD5)));
					}
				}
			}

			return topNode;
		}
		catch (GeneralSecurityException ex)
		{
			throw new CryptoException(RB.getString("DKeyStoreReport.NoGenerateReport.exception.message"), ex);
		}
	}

}