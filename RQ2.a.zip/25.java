public class A {
@Test
    public void testMissingPropertyNameInMethodWithBooleanParameter() throws Exception {
        try {

// a {@link java.lang.File} object. a {@link java.lang.File} object a {@link java.lang.String} object.
            final String fName = getPath("InputConfigurationLoaderMissingPropertyName.xml");
            ConfigurationLoader.loadConfiguration(fName, new PropertiesExpander(new Properties()),
                    IgnoredModulesOptions.EXECUTE);

            assertWithMessage("missing property name").fail();
        }
        catch (CheckstyleException ex) {
            assertWithMessage("Invalid exception message: " + ex.getMessage())
                    .that(ex.getMessage().contains("\"name\""))
                    .isTrue();
            assertWithMessage("Invalid exception message: " + ex.getMessage())
                    .that(ex.getMessage().contains("\"property\""))
                    .isTrue();
            assertWithMessage("Invalid exception message: " + ex.getMessage())
                    .that(ex.getMessage().endsWith(":8:41"))
                    .isTrue();
        }
    }

}