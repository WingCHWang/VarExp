public class A {
@Test
    // UT uses Reflection to avoid removing null-validation from static method,
    // which is a candidate for utility method in the future
    public void testGetFullImportIdent() throws Exception {
        final Class<?> clazz = CustomImportOrderCheck.class;

// The object to test. the object to test. the object to test
        final Object t = clazz.getConstructor().newInstance();
        final Method method = clazz.getDeclaredMethod("getFullImportIdent", DetailAST.class);
        method.setAccessible(true);
        final Object actual = method.invoke(t, new Object[] {null});

        final String expected = "";
        assertWithMessage("Invalid getFullImportIdent result")
            .that(actual)
            .isEqualTo(expected);
    }

}