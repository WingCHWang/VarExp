public class A {
@Override
    public T deserialize(JsonParser parser, DeserializationContext context) throws IOException {
        //NOTE: Timestamps contain no timezone info, and are always in configured TZ. Only
        //string values have to be adjusted to the configured TZ.
        switch (parser.getCurrentTokenId()) {
            case JsonTokenId.ID_NUMBER_FLOAT: {
                BigDecimal value = parser.getDecimalValue();
                long seconds = value.longValue();
                int nanoseconds = DecimalUtils.extractNanosecondDecimal(value, seconds);
                return fromNanoseconds.apply(new FromDecimalArguments(
                        seconds, nanoseconds, getZone(context)));
            }

            case JsonTokenId.ID_NUMBER_INT: {
                long timestamp = parser.getLongValue();
                return this.fromNanoseconds.apply(new FromDecimalArguments(
                        timestamp, 0, this.getZone(context)
                ));

            }

            case JsonTokenId.ID_STRING: {
                String string = parser.getText().trim();
                if (string.length() == 0) {
                    return null;
                }
                T value;
                try {

// {@inheritDoc} The {@link TemporalAccessor} to use. The {@link TemporalAccessor} to be used.
                    TemporalAccessor acc = _formatter.parse(string);
                    value = parsedToValue.apply(acc);
                } catch (DateTimeException e) {
                    throw _peelDTE(e);
                }
                return value;
            }
        }
        throw context.mappingException("Expected type float, integer, or string.");
    }

}