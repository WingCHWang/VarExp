public class A {
@Test
    public void testDeclareVar_ConfigPathCaseSensitivity() {
        BQRuntime runtime = testFactory.app()
                .declareVar("m.propCamelCase", "MY_VAR")
                .var("MY_VAR", "myValue")
                .createRuntime();


// a {@link BQRuntime} instance. a {@link BQRuntime} instance a {@link BQRuntime} object.
        Bean4 b4 = runtime.getInstance(ConfigurationFactory.class).config(Bean4.class, "");
        assertNotNull("Map did not resolve", b4.m);
        assertEquals("Unexpected map contents: " + b4.m, "myValue", b4.m.get("propCamelCase"));
    }

}