public class A {
private boolean changeKeyStoreType(KeyStoreType keyStoreType)
	{
		assert m_keyStoreWrap.getKeyStore() != null;
		// Cannot change type to current type
		assert !m_keyStoreWrap.getKeyStore().getType().equals(keyStoreType.name());

		try
		{
			// Get current keystore and type
			KeyStore currentKeyStore = m_keyStoreWrap.getKeyStore();
			KeyStoreType currentType = m_keyStoreWrap.getKeyStoreType();

			// Create empty keystore of new type
			KeyStore newKeyStore = KeyStoreUtil.createKeyStore(keyStoreType);

			// Flag used to tell if we have warned the user about default key pair entry passwords for
			// keystores changed to types that don't support entry passwords
			boolean bWarnPasswordUnsupported = false;

			// Flag used to tell if we have warned the user about key entries not being carried over by the
			// change
			boolean bWarnNoChangeKey = false;

			// For every entry in the current keystore transfer it to the new one - get key/key pair entry
			// passwords from the wrapper and if not present there from the user
			for (Enumeration<String> aliases = currentKeyStore.aliases(); aliases.hasMoreElements();)
			{
				// Entry alias
				String sAlias = aliases.nextElement();

				// Trusted certificate entry
				if (currentKeyStore.isCertificateEntry(sAlias))
				{
					// Check and ask about alias overwriting issues
					if (newKeyStore.containsAlias(sAlias))
					{
						int iSelected =
						    JOptionPane.showConfirmDialog(this, RB.getString("FPortecle.WarnOverwriteAlias.message"),
						        RB.getString("FPortecle.ChangeKeyStoreType.Title"), JOptionPane.YES_NO_OPTION);
						if (iSelected != JOptionPane.YES_OPTION)
						{
							continue;
						}
					}

					// Get trusted certificate and place it in the new keystore
					Certificate trustedCertificate = currentKeyStore.getCertificate(sAlias);
					newKeyStore.setCertificateEntry(sAlias, trustedCertificate);
				}
				// Key or Key pair entry
				else if (currentKeyStore.isKeyEntry(sAlias))
				{
					// Get certificate chain - will be null if entry is key
					Certificate[] certificateChain = currentKeyStore.getCertificateChain(sAlias);

					if (certificateChain == null || certificateChain.length == 0)
					{
						// Key entries are not transferred - warn the user if we haven't done so already
						if (!bWarnNoChangeKey)
						{
							bWarnNoChangeKey = true;
							int iSelected =
							    JOptionPane.showConfirmDialog(this, RB.getString("FPortecle.WarnNoChangeKey.message"),
							        RB.getString("FPortecle.ChangeKeyStoreType.Title"), JOptionPane.YES_NO_OPTION);
							if (iSelected != JOptionPane.YES_OPTION)
							{
								return false;
							}
						}

						continue;
					}

					// Get the entry's password (we may already know it from the wrapper)
					char[] cPassword = m_keyStoreWrap.getEntryPassword(sAlias);

					if (cPassword == null)
					{
						cPassword = KeyStoreUtil.DUMMY_PASSWORD;

						if (currentType.isEntryPasswordSupported())
						{
							String sTitle = MessageFormat.format(
							    RB.getString("FPortecle.ChangeKeyStoreTypeKeyPairEntryPassword.Title"), sAlias);
							DGetPassword dGetPassword = new DGetPassword(this, sTitle);
							dGetPassword.setLocationRelativeTo(this);
							SwingHelper.showAndWait(dGetPassword);
							cPassword = dGetPassword.getPassword();

							if (cPassword == null)
							{
								return false;
							}
						}
					}

					// Use password to get key pair
					Key key = currentKeyStore.getKey(sAlias, cPassword);

					// The current keystore type does not support entry passwords so the password will be set
					// to the "dummy value" password
					if (!currentType.isEntryPasswordSupported())
					{
						// Warn the user about this
						if (!bWarnPasswordUnsupported)
						{
							bWarnPasswordUnsupported = true;
							JOptionPane.showMessageDialog(this,
							    MessageFormat.format(RB.getString("FPortecle.ChangeFromPasswordUnsupported.message"),
							        new String(KeyStoreUtil.DUMMY_PASSWORD)),
							    RB.getString("FPortecle.ChangeKeyStoreType.Title"), JOptionPane.INFORMATION_MESSAGE);
						}
					}
					// The new keystore type does not support entry passwords so use dummy password for entry
					else if (!keyStoreType.isEntryPasswordSupported())
					{
						cPassword = KeyStoreUtil.DUMMY_PASSWORD;
					}

					// Check and ask about alias overwriting issues
					if (newKeyStore.containsAlias(sAlias))
					{
						int iSelected =
						    JOptionPane.showConfirmDialog(this, RB.getString("FPortecle.WarnOverwriteAlias.message"),
						        RB.getString("FPortecle.ChangeKeyStoreType.Title"), JOptionPane.YES_NO_OPTION);
						if (iSelected != JOptionPane.YES_OPTION)
						{
							continue;
						}
					}

					// Put key and (possibly null) certificate chain in new keystore
					newKeyStore.setKeyEntry(sAlias, key, cPassword, certificateChain);

					// Update wrapper with password
					m_keyStoreWrap.setEntryPassword(sAlias, cPassword);
				}
			}

			// Successful change of type - put new keystore into wrapper
			m_keyStoreWrap.setKeyStore(newKeyStore);
			File oldFile = m_keyStoreWrap.getKeyStoreFile();
			if (oldFile != null)
			{

// The extensions to use for the keystore. The extensions to use for the new keystore type. The extensions to use for the new keystore.
				Set<String> oldExts = m_keyStoreWrap.getKeyStoreType().getFilenameExtensions();
				Set<String> newExts = keyStoreType.getFilenameExtensions();
				if (oldExts.isEmpty() || newExts.isEmpty())
				{
					m_keyStoreWrap.setKeyStoreFile(null);
				}
				else
				{
					String newExt = newExts.iterator().next();
					for (String oldExt : oldExts)
					{
						String path = oldFile.getPath().toLowerCase();
						if (path.endsWith("." + oldExt))
						{
							m_keyStoreWrap.setKeyStoreFile(
							    new File(path.substring(0, path.length() - oldExt.length()) + newExt));
						}
					}
					if (oldFile.equals(m_keyStoreWrap.getKeyStoreFile()))
					{
						m_keyStoreWrap.setKeyStoreFile(null);
					}
				}
			}
			m_keyStoreWrap.setChanged(true);

			// Update the frame's components and title
			updateControls();
			updateTitle();

			// Display success message
			JOptionPane.showMessageDialog(this, RB.getString("FPortecle.ChangeKeyStoreTypeSuccessful.message"),
			    RB.getString("FPortecle.ChangeKeyStoreType.Title"), JOptionPane.INFORMATION_MESSAGE);
			return true;
		}
		catch (Exception ex)
		{
			DThrowable.showAndWait(this, null, ex);
			return false;
		}
	}

}