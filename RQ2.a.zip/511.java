public class A {
private void initComponents()
	{
		JLabel jlKeyAlg = new JLabel(RB.getString("DGenerateKeyPair.jlKeyAlg.text"));
		m_jrbDSA = new JRadioButton(RB.getString("DGenerateKeyPair.m_jrbDSA.text"), false);
		m_jrbDSA.setToolTipText(RB.getString("DGenerateKeyPair.m_jrbDSA.tooltip"));
		JRadioButton jrbRSA = new JRadioButton(RB.getString("DGenerateKeyPair.m_jrbRSA.text"), false);
		jrbRSA.setToolTipText(RB.getString("DGenerateKeyPair.m_jrbRSA.tooltip"));
		ButtonGroup buttonGroup = new ButtonGroup();
		buttonGroup.add(m_jrbDSA);
		buttonGroup.add(jrbRSA);

		JPanel jpKeyAlg = new JPanel(new FlowLayout(FlowLayout.LEFT));
		jpKeyAlg.add(m_jrbDSA);
		jpKeyAlg.add(jrbRSA);

		JLabel jlKeySize = new JLabel(RB.getString("DGenerateKeyPair.jlKeySize.text"));
		m_jcbKeySize = new JComboBox<>();
		m_jcbKeySize.setToolTipText(RB.getString("DGenerateKeyPair.m_jcbKeySize.tooltip"));
		m_jcbKeySize.setEditable(true);
		Component editor = m_jcbKeySize.getEditor().getEditorComponent();
		if (editor instanceof JTextComponent)
		{
			Document doc = ((JTextComponent) editor).getDocument();
			if (doc instanceof AbstractDocument)
			{
				((AbstractDocument) doc).setDocumentFilter(new IntegerDocumentFilter(5));
			}
		}
		jlKeySize.setLabelFor(m_jcbKeySize);

		ChangeListener keyAlgListener = new ChangeListener()
		{
			@Override
			public void stateChanged(ChangeEvent evt)
			{
				String keySizesKey = "DGenerateKeyPair.RsaKeySizes";
				String defaultSizeKey = "DGenerateKeyPair.DefaultRsaKeySize";
				if (m_jrbDSA.isSelected())
				{
					keySizesKey = "DGenerateKeyPair.DsaKeySizes";
					defaultSizeKey = "DGenerateKeyPair.DefaultDsaKeySize";
				}
				Object oldItem = m_jcbKeySize.getSelectedItem();
				boolean selectionKept = false;
				m_jcbKeySize.removeAllItems();
				for (String item : RB.getString(keySizesKey).split(",+"))
				{
					m_jcbKeySize.addItem(item);
					if (item.equals(oldItem))
					{
						m_jcbKeySize.setSelectedItem(item);
						selectionKept = true;
					}
				}
				if (!selectionKept)
				{
					m_jcbKeySize.setSelectedItem(RB.getString(defaultSizeKey));
				}
			}
		};
		m_jrbDSA.addChangeListener(keyAlgListener);
		jrbRSA.addChangeListener(keyAlgListener);
		jrbRSA.setSelected(true);

		JPanel jpOptions = new JPanel(new GridBagLayout());
		jpOptions.setBorder(new CompoundBorder(new EmptyBorder(5, 5, 5, 5), new EtchedBorder()));
		int gridy = 0;

		GridBagConstraints gbcLabel = new GridBagConstraints();
		gbcLabel.gridx = 0;
		gbcLabel.gridwidth = 1;
		gbcLabel.gridheight = 1;
		gbcLabel.insets = new Insets(5, 5, 5, 5);
		gbcLabel.anchor = GridBagConstraints.EAST;

		GridBagConstraints gbcField = new GridBagConstraints();
		gbcField.gridx = 1;
		gbcField.gridwidth = 1;
		gbcField.gridheight = 1;
		gbcField.insets = new Insets(5, 5, 5, 5);
		gbcField.anchor = GridBagConstraints.WEST;


// The GWT component builder. The GWT context. The GWT component bundle.
		GridBagConstraints gbc = (GridBagConstraints) gbcLabel.clone();
		gbc.gridy = gridy;
		jpOptions.add(jlKeyAlg, gbc);

		gbc = (GridBagConstraints) gbcField.clone();
		gbc.gridy = gridy++;
		jpOptions.add(jpKeyAlg, gbc);

		gbc = (GridBagConstraints) gbcLabel.clone();
		gbc.gridy = gridy;
		jpOptions.add(jlKeySize, gbc);

		gbc = (GridBagConstraints) gbcField.clone();
		gbc.gridy = gridy++;
		jpOptions.add(m_jcbKeySize, gbc);

		JButton jbOK = getOkButton(false);
		JButton jbCancel = getCancelButton();

		JPanel jpButtons = new JPanel(new FlowLayout(FlowLayout.CENTER));
		jpButtons.add(jbOK);
		jpButtons.add(jbCancel);

		getContentPane().add(jpOptions, BorderLayout.CENTER);
		getContentPane().add(jpButtons, BorderLayout.SOUTH);

		setTitle(RB.getString("DGenerateKeyPair.Title"));

		getRootPane().setDefaultButton(jbOK);

		initDialog();

		SwingHelper.selectAndFocus(m_jcbKeySize);
	}

}