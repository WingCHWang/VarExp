public class A {
@Test
    public void testConfigWithIgnoreUsingInputSource() throws Exception {

// The configuration to test. the configuration to test the configuration to test.
        final DefaultConfiguration config =
                (DefaultConfiguration) ConfigurationLoader.loadConfiguration(new InputSource(
                        new File(getPath("InputConfigurationLoaderModuleIgnoreSeverity.xml"))
                            .toURI().toString()),
                        new PropertiesExpander(new Properties()), IgnoredModulesOptions.OMIT);

        final Configuration[] children = config.getChildren();
        final int length = children[0].getChildren().length;
        assertWithMessage("Invalid children count")
            .that(length)
            .isEqualTo(0);
    }

}