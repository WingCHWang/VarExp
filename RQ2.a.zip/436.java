public class A {
private String getExtendedKeyUsageStringValue(byte[] bValue)
	{
		StringBuilder strBuff = new StringBuilder();


// the extended key usage. the extended key usage to be converted to a string. the extended key usage
		ExtendedKeyUsage eku = ExtendedKeyUsage.getInstance(bValue);
		KeyPurposeId[] usages = eku.getUsages();

		for (KeyPurposeId usage : usages)
		{
			if (strBuff.length() != 0)
			{
				strBuff.append("<br><br>");
			}
			String sOid = usage.getId();
			String sEku = getRes(sOid, "UnrecognisedExtKeyUsageString");
			strBuff.append(MessageFormat.format(sEku, sOid));
		}

		return strBuff.toString();
	}

}