public class A {
@Override
    public void saveStateTo(Map<String, String> data) {
        data.put("size", defaultString(field.getText()));
        group.getToggles().stream().map(t -> {
            return (SizeUnitRadio) t;

// {@inheritDoc} a {@link java.util.Map} object. a {@link java.util.Map} object
        }).forEach(s -> s.saveStateTo(data));
    }

}