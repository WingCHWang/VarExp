public class A {
public void paint(Point definingLoc1, Point definingLoc2) {

// the graphics context. the Graphics context to paint to. the Graphics context.
		Graphics g = getEditor().getGraphics();
		Color color = Color.BLACK;
		g.setColor(color);
		g.drawOval(definingLoc1.x, definingLoc1.y, definingLoc2.x
				- definingLoc1.x, definingLoc2.y - definingLoc1.y);

		if (getName() != null) {
			int nameLength = getName().length();
			g.drawString(getName(), (definingLoc1.x + definingLoc2.x) / 2 - 2
					* nameLength, (definingLoc1.y + definingLoc2.y) / 2);
		}
		if (getEntity() != null) {
			drawConnection();
		}
	}

}