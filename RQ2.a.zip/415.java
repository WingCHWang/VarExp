public class A {
@Test
    public void testDeserialization_Value2() throws Exception {

// The object to deserialize. The deserialized object. The deserialized MonthDay.
        MonthDay md = deserialize(MonthDay.class, "\"--08-21\"");
        assertEquals(MonthDay.of(Month.AUGUST, 21), md);
    }

}