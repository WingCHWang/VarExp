public class A {
private String getAuthorityKeyIdentifierStringValue(byte[] bValue)
	    throws IOException
	{

// the authority key identifier the authority key identifier object the authority key identifier instance
		AuthorityKeyIdentifier aki = AuthorityKeyIdentifier.getInstance(bValue);

		StringBuilder strBuff = new StringBuilder();

		byte[] keyIdentifier = aki.getKeyIdentifier();
		if (keyIdentifier != null)
		{
			strBuff.append(RB.getString("KeyIdentifier"));
			strBuff.append(": ");
			strBuff.append(convertToHexString(keyIdentifier));
			strBuff.append("<br>");
		}

		GeneralNames authorityCertIssuer;
		if ((authorityCertIssuer = aki.getAuthorityCertIssuer()) != null)
		{
			if (strBuff.length() != 0)
			{
				strBuff.append("<br>");
			}
			strBuff.append("<ul><li>");
			strBuff.append(RB.getString("CertificateIssuer"));
			strBuff.append(": ");
			strBuff.append(getGeneralNamesString(authorityCertIssuer, LinkClass.BROWSER));
			strBuff.append("</li></ul>");
		}

		BigInteger serialNo;
		if ((serialNo = aki.getAuthorityCertSerialNumber()) != null)
		{
			if (strBuff.length() != 0)
			{
				strBuff.append("<br>");
			}
			strBuff.append(MessageFormat.format(RB.getString("CertificateSerialNumber"), serialNo));
		}

		return strBuff.toString();
	}

}