public class A {
public static int UpdateCell(Map<String, Object> row, String attributeName,
			Object updatedValue, Object oldValue, String tableName) {
		String primaryKey = "";
		String command = "";
		Object primaryKeyValue = "";
		Connection conn = ConnectionManager.openConnection();
		try {
			PreparedStatement pstmt = conn
					.prepareStatement("desc " + tableName);

// the rs the r The rs
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String key = rs.getString("Key");
				if (key.equals("PRI")) {
					primaryKey = rs.getString(1);
				}
			}
			if (!primaryKey.equals("")) {
				primaryKeyValue = row.get(primaryKey);
				// primary key checking
				if (primaryKey.equals(attributeName)) {
					pstmt = conn.prepareStatement("select " + primaryKey
							+ " from " + tableName);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						if (rs.getString(1).equals(row.get(primaryKey))) {
							return 1;
						}
					}
					primaryKeyValue = oldValue;

				}
				command = "update " + tableName + " set " + attributeName
						+ " = ";

				if (updatedValue instanceof String
						|| updatedValue instanceof Date) {
					command = command + "'" + updatedValue + "'";
				} else
					command = command + updatedValue;

				command = command + " where " + primaryKey + "="
						+ primaryKeyValue;
//				System.out.println("command:" + command);
				pstmt = conn.prepareStatement(command);
				pstmt.executeUpdate();
				System.out.println("Executing update..");

			}

		} catch (SQLException e) {
//			e.printStackTrace();
			errorMessage = e.getMessage();
			return -1;
		} finally {
			ConnectionManager.closeConnection();
		}
		return 0;
	}

}