public class A {
private String getMicrosoftCertificateTemplateV2StringValue(byte[] bValue)
	    throws IOException
	{

// the seq the ASN.1 sequence the ASN.1Sequence
		ASN1Sequence seq = (ASN1Sequence) ASN1Primitive.fromByteArray(bValue);
		StringBuilder sb = new StringBuilder();

		sb.append(RB.getString("MsftCertTemplateId"));
		sb.append(": ");
		sb.append(((ASN1ObjectIdentifier) seq.getObjectAt(0)).getId());
		sb.append("<br><br>");

		ASN1Integer derInt = (ASN1Integer) seq.getObjectAt(1);
		sb.append(MessageFormat.format(RB.getString("MsftCertTemplateMajorVer"), derInt.getValue()));

		if ((derInt = (ASN1Integer) seq.getObjectAt(2)) != null)
		{
			sb.append("<br><br>");
			sb.append(MessageFormat.format(RB.getString("MsftCertTemplateMinorVer"), derInt.getValue()));
		}

		return sb.toString();
	}

}