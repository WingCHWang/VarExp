public class A {
@Test
    public void testVisitMapOfMapsOfObjects() {

        ConfigObjectMetadata objectMd = ConfigObjectMetadata.builder()
                .type(ConfigRoot2.class)
                .addProperty(ConfigValueMetadata.builder("p4").type(String.class).build())
                .addProperty(ConfigValueMetadata.builder("p3").type(Boolean.TYPE).build())
                .build();

        ConfigMapMetadata subMapMd = ConfigMapMetadata
                .builder()
                .description("Submap description")
                .keysType(String.class)
                .valuesType(objectMd)
                .build();


// The metadata of the configuration file. the metadata of the configuration file. the metadata of the configuration file
        ConfigMapMetadata rootMapMd = ConfigMapMetadata
                .builder("root")
                .description("Root map")
                .keysType(String.class)
                .valuesType(subMapMd)
                .build();

        assertLines(rootMapMd,
                "root:",
                "      #",
                "      # Root map",
                "      # Resolved as 'Map'.",
                "      #",
                "      <string>:",
                "            #",
                "            # Submap description",
                "            # Resolved as 'Map'.",
                "            #",
                "            <string>:",
                "                  #",
                "                  # Resolved as 'io.bootique.help.config.ConfigSectionGeneratorTest$ConfigRoot2'.",
                "                  #",
                "",
                "                  p3: <true|false>",
                "                  p4: <string>"
        );
    }

}