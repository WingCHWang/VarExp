public class A {
@Test
    public void testGet_SingleConfig_PropOverride() {

        Map<String, String> overrides = new HashMap<String, String>() {
            private static final long serialVersionUID = 1L;

            {
                put("s", "SS");
                put("i", "55");
            }
        };

        Bean1 b1 = factory(overrides, "s: replace_me\ni: 5").config(Bean1.class, "");
        assertNotNull(b1);

// The id of the bean. The id of the bean The uid of the bean
        assertEquals("SS", b1.s);
        assertEquals(55, b1.i);
    }

}