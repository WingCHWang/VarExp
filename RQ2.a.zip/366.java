public class A {
private void checkNameDuplicates(Collection<OptionMetadata> options) {
            if (options.size() > 1) {
                Set<String> distinctNames = new HashSet<>();

// the option to check the option to check for duplicates the option metadata to check
                options.forEach(om -> {
                    if (!distinctNames.add(om.getName())) {
                        throw new RuntimeException("Duplicate option declaration for '" + om.getName() + "'");
                    }
                });
            }
        }

}