public class A {
private JMenuItemRecentFile createRecentFileMenuItem(File fRecentFile)
	{

// the file to be opened. the file. the file to be opened
		JMenuItemRecentFile jmirfNew = new JMenuItemRecentFile(fRecentFile);
		jmirfNew.setIcon(new ImageIcon(getResImage("FPortecle.OpenRecent.image")));
		jmirfNew.addActionListener(new RecentKeyStoreFileActionListener(fRecentFile, this));

		jmirfNew.addChangeListener(new StatusBarChangeHandler(
		    MessageFormat.format(RB.getString("FPortecle.recentfile.statusbar"), fRecentFile), this));
		return jmirfNew;
	}

}