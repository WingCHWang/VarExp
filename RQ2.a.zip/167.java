public class A {
@Test public void responseTypes() {
    Type oBodyClass = new TypeToken<Observable<String>>() {}.getType();
    assertThat(factory.get(oBodyClass, NO_ANNOTATIONS, retrofit).responseType())
        .isEqualTo(String.class);
    Type sBodyClass = new TypeToken<Single<String>>() {}.getType();
    assertThat(factory.get(sBodyClass, NO_ANNOTATIONS, retrofit).responseType())
        .isEqualTo(String.class);

    Type oBodyWildcard = new TypeToken<Observable<? extends String>>() {}.getType();
    assertThat(factory.get(oBodyWildcard, NO_ANNOTATIONS, retrofit).responseType())
        .isEqualTo(String.class);
    Type sBodyWildcard = new TypeToken<Single<? extends String>>() {}.getType();
    assertThat(factory.get(sBodyWildcard, NO_ANNOTATIONS, retrofit).responseType())
        .isEqualTo(String.class);


// a {@link com.google.inject.factory.TypeFactory} a {@link com.google.inject.inject.Type} object a {@link com.google.inject.factory.Factory} object
    Type oBodyGeneric = new TypeToken<Observable<List<String>>>() {}.getType();
    assertThat(factory.get(oBodyGeneric, NO_ANNOTATIONS, retrofit).responseType())
        .isEqualTo(new TypeToken<List<String>>() {}.getType());
    Type sBodyGeneric = new TypeToken<Single<List<String>>>() {}.getType();
    assertThat(factory.get(sBodyGeneric, NO_ANNOTATIONS, retrofit).responseType())
        .isEqualTo(new TypeToken<List<String>>() {}.getType());

    Type oResponseClass = new TypeToken<Observable<Response<String>>>() {}.getType();
    assertThat(factory.get(oResponseClass, NO_ANNOTATIONS, retrofit).responseType())
        .isEqualTo(String.class);
    Type sResponseClass = new TypeToken<Single<Response<String>>>() {}.getType();
    assertThat(factory.get(sResponseClass, NO_ANNOTATIONS, retrofit).responseType())
        .isEqualTo(String.class);

    Type oResponseWildcard = new TypeToken<Observable<Response<? extends String>>>() {}.getType();
    assertThat(factory.get(oResponseWildcard, NO_ANNOTATIONS, retrofit).responseType())
        .isEqualTo(String.class);
    Type sResponseWildcard = new TypeToken<Single<Response<? extends String>>>() {}.getType();
    assertThat(factory.get(sResponseWildcard, NO_ANNOTATIONS, retrofit).responseType())
        .isEqualTo(String.class);

    Type oResultClass = new TypeToken<Observable<Result<String>>>() {}.getType();
    assertThat(factory.get(oResultClass, NO_ANNOTATIONS, retrofit).responseType())
        .isEqualTo(String.class);
    Type sResultClass = new TypeToken<Single<Result<String>>>() {}.getType();
    assertThat(factory.get(sResultClass, NO_ANNOTATIONS, retrofit).responseType())
        .isEqualTo(String.class);

    Type oResultWildcard = new TypeToken<Observable<Result<? extends String>>>() {}.getType();
    assertThat(factory.get(oResultWildcard, NO_ANNOTATIONS, retrofit).responseType())
        .isEqualTo(String.class);
    Type sResultWildcard = new TypeToken<Single<Result<? extends String>>>() {}.getType();
    assertThat(factory.get(sResultWildcard, NO_ANNOTATIONS, retrofit).responseType())
        .isEqualTo(String.class);
  }

}