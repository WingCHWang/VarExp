public class A {
@Test
    public void openDirectoryClick() throws Exception {

// The directory to open. the directory to open. the directory to open
        File dir = temp.newFolder();
        DirectoryTaskOutput output = new DirectoryTaskOutput(dir);
        TestListener listener = new TestListener(dir);
        eventStudio().add(listener);
        WaitForAsyncUtils.waitForAsyncFx(2000, () -> victim.dispatch(output));
        clickOn(victim);
        assertTrue(listener.isHit());
        assertTrue(listener.equal);
    }

}