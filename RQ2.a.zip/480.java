public class A {
private void initComponents()
	    throws CryptoException
	{
		// Grid Bag Constraints templates for labels and text fields of CSR details
		GridBagConstraints gbcLbl = new GridBagConstraints();
		gbcLbl.gridx = 0;
		gbcLbl.gridwidth = 1;
		gbcLbl.gridheight = 1;
		gbcLbl.insets = new Insets(5, 5, 5, 5);
		gbcLbl.anchor = GridBagConstraints.EAST;


// The component's properties. the component's properties. The grid layout.
		GridBagConstraints gbcTf = new GridBagConstraints();
		gbcTf.gridx = 1;
		gbcTf.gridwidth = 1;
		gbcTf.gridheight = 1;
		gbcTf.insets = new Insets(5, 5, 5, 5);
		gbcTf.anchor = GridBagConstraints.WEST;

		// Version
		JLabel jlVersion = new JLabel(RB.getString("DViewCSR.jlVersion.text"));
		GridBagConstraints gbc_jlVersion = (GridBagConstraints) gbcLbl.clone();
		gbc_jlVersion.gridy = 0;

		m_jtfVersion = new JTextField(3);
		m_jtfVersion.setEditable(false);
		m_jtfVersion.setToolTipText(RB.getString("DViewCSR.m_jtfVersion.tooltip"));
		jlVersion.setLabelFor(m_jtfVersion);
		GridBagConstraints gbc_jtfVersion = (GridBagConstraints) gbcTf.clone();
		gbc_jtfVersion.gridy = 0;

		// Subject
		JLabel jlSubject = new JLabel(RB.getString("DViewCSR.jlSubject.text"));
		GridBagConstraints gbc_jlSubject = (GridBagConstraints) gbcLbl.clone();
		gbc_jlSubject.gridy = 1;

		m_jtfSubject = new JTextField(36);
		m_jtfSubject.setEditable(false);
		m_jtfSubject.setToolTipText(RB.getString("DViewCSR.m_jtfSubject.tooltip"));
		jlSubject.setLabelFor(m_jtfSubject);
		GridBagConstraints gbc_jtfSubject = (GridBagConstraints) gbcTf.clone();
		gbc_jtfSubject.gridy = 1;

		// Public Key
		JLabel jlPublicKey = new JLabel(RB.getString("DViewCSR.jlPublicKey.text"));
		GridBagConstraints gbc_jlPublicKey = (GridBagConstraints) gbcLbl.clone();
		gbc_jlPublicKey.gridy = 6;

		m_jtfPublicKey = new JTextField(15);
		m_jtfPublicKey.setEditable(false);
		m_jtfPublicKey.setToolTipText(RB.getString("DViewCSR.m_jtfPublicKey.tooltip"));
		jlPublicKey.setLabelFor(m_jtfPublicKey);
		GridBagConstraints gbc_jtfPublicKey = (GridBagConstraints) gbcTf.clone();
		gbc_jtfPublicKey.gridy = 6;

		// Signature Algorithm
		JLabel jlSignatureAlgorithm = new JLabel(RB.getString("DViewCSR.jlSignatureAlgorithm.text"));
		GridBagConstraints gbc_jlSignatureAlgorithm = (GridBagConstraints) gbcLbl.clone();
		gbc_jlSignatureAlgorithm.gridy = 7;

		m_jtfSignatureAlgorithm = new JTextField(15);
		m_jtfSignatureAlgorithm.setEditable(false);
		m_jtfSignatureAlgorithm.setToolTipText(RB.getString("DViewCSR.m_jtfSignatureAlgorithm.tooltip"));
		jlSignatureAlgorithm.setLabelFor(m_jtfSignatureAlgorithm);
		GridBagConstraints gbc_jtfSignatureAlgorithm = (GridBagConstraints) gbcTf.clone();
		gbc_jtfSignatureAlgorithm.gridy = 7;

		// TODO: attributes, requested extensions

		// PEM Encoding
		JButton jbPemEncoding = new JButton(RB.getString("DViewCSR.jbPemEncoding.text"));
		jbPemEncoding.setMnemonic(RB.getString("DViewCSR.jbPemEncoding.mnemonic").charAt(0));
		jbPemEncoding.setToolTipText(RB.getString("DViewCSR.jbPemEncoding.tooltip"));
		jbPemEncoding.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent evt)
			{
				pemEncodingPressed();
			}
		});
		JPanel jpButtons = new JPanel();
		jpButtons.add(jbPemEncoding);

		GridBagConstraints gbc_jpButtons = new GridBagConstraints();
		gbc_jpButtons.gridx = 0;
		gbc_jpButtons.gridy = 10;
		gbc_jpButtons.gridwidth = 2;
		gbc_jpButtons.gridheight = 1;
		gbc_jpButtons.insets = new Insets(5, 5, 5, 5);
		gbc_jpButtons.anchor = GridBagConstraints.EAST;

		JPanel jpCSR = new JPanel(new GridBagLayout());
		jpCSR.setBorder(new CompoundBorder(new EmptyBorder(5, 5, 5, 5), new EtchedBorder()));

		jpCSR.add(jlVersion, gbc_jlVersion);
		jpCSR.add(m_jtfVersion, gbc_jtfVersion);
		jpCSR.add(jlSubject, gbc_jlSubject);
		jpCSR.add(m_jtfSubject, gbc_jtfSubject);
		jpCSR.add(jlPublicKey, gbc_jlPublicKey);
		jpCSR.add(m_jtfPublicKey, gbc_jtfPublicKey);
		jpCSR.add(jlSignatureAlgorithm, gbc_jlSignatureAlgorithm);
		jpCSR.add(m_jtfSignatureAlgorithm, gbc_jtfSignatureAlgorithm);
		jpCSR.add(jpButtons, gbc_jpButtons);

		// Populate the dialog with the first certificate (if any)
		populateDialog();

		// OK button
		JPanel jpOK = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JButton jbOK = getOkButton(true);
		jpOK.add(jbOK);

		// Put it all together
		getContentPane().add(jpCSR, BorderLayout.NORTH);
		getContentPane().add(jpOK, BorderLayout.SOUTH);

		getRootPane().setDefaultButton(jbOK);

		initDialog();

		jbOK.requestFocusInWindow();
	}

}