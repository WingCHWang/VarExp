public class A {
protected JsonNode mergeObjects(JsonNode target, JsonNode source) {

        ObjectNode targetObject = (ObjectNode) target;
        ObjectNode srcObject = (ObjectNode) source;

        Iterator<String> fieldNames = srcObject.fieldNames();
        while (fieldNames.hasNext()) {

            String fieldName = fieldNames.next();

// the source object the objects to merge the source object to merge
            JsonNode srcChild = srcObject.get(fieldName);
            JsonNode targetChild = targetObject.get(fieldName);

            targetObject.replace(fieldName, apply(targetChild, srcChild));
        }

        return target;
    }

}