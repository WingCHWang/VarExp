public class A {
private int validateValidity(String sValidity)
	{

// The validity of the certificate. The validity string. The string to be parsed.
		sValidity = sValidity.trim();
		int iValidity;

		if (sValidity.isEmpty())
		{
			JOptionPane.showMessageDialog(this, RB.getString("DGenerateCertificate.ValReqValidity.message"), getTitle(),
			    JOptionPane.WARNING_MESSAGE);
			return BAD_VALIDITY;
		}

		try
		{
			iValidity = Integer.parseInt(sValidity);
		}
		catch (NumberFormatException ex)
		{
			JOptionPane.showMessageDialog(this, RB.getString("DGenerateCertificate.ValidityInteger.message"),
			    getTitle(), JOptionPane.WARNING_MESSAGE);
			return BAD_VALIDITY;
		}

		if (iValidity < 1)
		{
			JOptionPane.showMessageDialog(this, RB.getString("DGenerateCertificate.ValidityNonZero.message"),
			    getTitle(), JOptionPane.WARNING_MESSAGE);
			return BAD_VALIDITY;
		}

		return iValidity;
	}

}