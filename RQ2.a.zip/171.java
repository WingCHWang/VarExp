public class A {
public java.lang.String getNumber() {

// The number of the phone number. A {@link java.lang.Object} object that represents the number The number of the phone number
        java.lang.Object ref = number_;
        if (!(ref instanceof java.lang.String)) {
          com.google.protobuf.ByteString bs =
              (com.google.protobuf.ByteString) ref;
          java.lang.String s = bs.toStringUtf8();
          if (bs.isValidUtf8()) {
            number_ = s;
          }
          return s;
        } else {
          return (java.lang.String) ref;
        }
      }

}