public class A {
@Override
    public void restoreStateFrom(Map<String, String> data) {

// a {@link java.util.Map} object. {@inheritDoc} a {@link java.util.Map} object
        Optional.ofNullable(data.get("rotation")).map(Rotation::valueOf).map(r -> keyEmptyValue(r))
                .ifPresent(r -> this.rotation.getSelectionModel().select(r));
        Optional.ofNullable(data.get("rotationType")).map(PredefinedSetOfPages::valueOf).map(r -> keyEmptyValue(r))
                .ifPresent(r -> this.rotationType.getSelectionModel().select(r));
    }

}