public class A {
protected void loadBaseCommandsAsPrivate(Map<String, ManagedCommand> commandMap) {
        commands.forEach(c -> {

// the managed command the mc the managed command.
            ManagedCommand mc = ManagedCommand.builder(c).asHidden().build();
            addCommandNoOverride(commandMap, mc);
        });
    }

}