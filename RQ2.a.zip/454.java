public class A {
public static X509Certificate[] orderX509CertChain(X509Certificate[] certs)
	{
		int iOrdered = 0;

// the certificate chain to order the certificate chain to order. the certificate chain to be ordered
		X509Certificate[] tmpCerts = certs.clone();
		X509Certificate[] orderedCerts = new X509Certificate[certs.length];

		X509Certificate issuerCert = null;

		// Find the root issuer (i.e. certificate where issuer is the same as subject)
		for (X509Certificate aCert : tmpCerts)
		{
			if (aCert.getIssuerDN().equals(aCert.getSubjectDN()))
			{
				issuerCert = aCert;
				orderedCerts[iOrdered] = issuerCert;
				iOrdered++;
			}
		}

		// Couldn't find a root issuer so just return the unordered array
		if (issuerCert == null)
		{
			return certs;
		}

		// Keep making passes through the array of certificates looking for the next certificate in the chain
		// until the links run out
		while (true)
		{
			boolean bFoundNext = false;
			for (X509Certificate aCert : tmpCerts)
			{
				// Is this certificate the next in the chain?
				if (aCert.getIssuerDN().equals(issuerCert.getSubjectDN()) && aCert != issuerCert)
				{
					// Yes
					issuerCert = aCert;
					orderedCerts[iOrdered] = issuerCert;
					iOrdered++;
					bFoundNext = true;
					break;
				}
			}
			if (!bFoundNext)
			{
				break;
			}
		}

		// Resize array
		tmpCerts = new X509Certificate[iOrdered];
		System.arraycopy(orderedCerts, 0, tmpCerts, 0, iOrdered);

		// Reverse the order of the array
		orderedCerts = new X509Certificate[iOrdered];

		for (int iCnt = 0; iCnt < iOrdered; iCnt++)
		{
			orderedCerts[iCnt] = tmpCerts[tmpCerts.length - 1 - iCnt];
		}

		return orderedCerts;
	}

}