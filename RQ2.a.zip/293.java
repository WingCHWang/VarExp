public class A {
public void actionPerformed(ActionEvent e) {

// the table cell listener. the table cell listener the TableCellListener.
			TableCellListener tcl = (TableCellListener) e.getSource();
			boolean toBeUpdated = false;
//			System.out.println("Row   : " + tcl.getRow());
//			System.out.println("Column: " + tcl.getColumn());
//			System.out.println("Old   : " + tcl.getOldValue());
//			System.out.println("New   : " + tcl.getNewValue());
//			System.out.println("oldRowCount:"+oldRowCount);
			// Insertion Part
			if (tcl.getRow() == databaseTable.getRowCount() - 1) {
//				System.out.println("IN INSERT PART");
				databaseTable.setValueAt(tcl.getNewValue(), tcl.getRow(),
						tcl.getColumn());
				insertMode = true;
				model.addRow(new Object[] {});
				databaseTable.setModel(model);
			} // Updation Part
			else if (!insertMode) {
				if ((tcl.getOldValue() == null)
						&& (!tcl.getNewValue().equals(null))) {
//					System.out.println("if part.." + tcl.getOldValue());
					toBeUpdated = true;
				} else if (!tcl.getOldValue().equals(tcl.getNewValue())) {
//					System.out.println("else if part....");
					toBeUpdated = true;
				}
				if (toBeUpdated) {
					Map<String, Object> data = new HashMap<String, Object>();
					for (int column = 0; column < databaseTable
							.getColumnCount(); column++) {
						data.put(databaseTable.getColumnName(column),
								databaseTable.getValueAt(tcl.getRow(), column));
					}

					int act = TableDetails
							.UpdateCell(data, databaseTable.getColumnName(tcl
									.getColumn()), tcl.getNewValue(), tcl
									.getOldValue(), selectedTable);
					if (act == -1) {
						JOptionPane
								.showMessageDialog(null,
										TableDetails.errorMessage,
										"Error in Update", 3);
						databaseTable.setValueAt(tcl.getOldValue(),
								tcl.getRow(), tcl.getColumn());
					}
//					if (act == 1) {
//						JOptionPane.showMessageDialog(null,
//								"Duplicate Entry for Primary Key",
//								"Error in Update", 3);
//						databaseTable.setValueAt(tcl.getOldValue(),
//								tcl.getRow(), tcl.getColumn());
//					}
				}
			}else if(insertMode && (oldRowCount-tcl.getRow()>=1)){
				JOptionPane.showMessageDialog(null,
						"Value cannot be changed",
						"Error in Update", 3);
				databaseTable.setValueAt(tcl.getOldValue(),tcl.getRow(), tcl.getColumn());
			}
		}

}