public class A {
@Override
    protected PathSegment parseNextNotEmpty(String path) {

// the length of the path the path length the length of the path to parse
        int len = path.length();

        // looking for ']' or '].'
        // start at index 1.. The first char is known to be '['
        for (int i = 1; i < len; i++) {
            char c = path.charAt(i);

            if (c == IndexPathSegment.ARRAY_INDEX_END) {

                // 1. [NNN]
                if (i == len - 1) {
                    return createValueChild(path.substring(0, i + 1));
                }
                // 2. [NNN].aaaa (i.e. in the second case the dot must follow closing paren)
                else if (path.charAt(i + 1) == PathSegment.DOT) {
                    return createPropertyChild(path.substring(0, i + 1), path.substring(i + 2));
                }
                // 3. [NNN][MMM] TODO => createIndexedChild
                // 4. Invalid path
                else {
                    throw new IllegalStateException("Invalid path after array index: " + path);
                }
            }
        }

        throw new IllegalStateException("No closing array index parenthesis: " + path);
    }

}