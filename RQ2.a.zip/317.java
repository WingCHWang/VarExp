public class A {
public void add(OptionMetadata option) {
        HelpOption ho = new HelpOption(option);

// the short name of the option the short name of the option. the short name of the option to add
        byShortName.computeIfAbsent(ho.getOption().getShortName(), sn -> new ArrayList<HelpOption>()).add(ho);
    }

}