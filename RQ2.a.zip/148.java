public class A {
@Test
    public void testAcceptableTokens() {

// the number of tokens. the number of tokens is the number of tokens.
        final int[] expected = {TokenTypes.NUM_LONG };
        final UpperEllCheck check = new UpperEllCheck();
        final int[] actual = check.getAcceptableTokens();
        assertWithMessage("Invalid size of tokens")
            .that(actual.length)
            .isEqualTo(1);
        assertWithMessage("Default acceptable tokens are invalid")
            .that(actual)
            .isEqualTo(expected);
    }

}