public class A {
private OptionSet parse(String[] args) {
        try {
            return getParser().parse(args);
        } catch (OptionException e) {

// the exception thrown when parsing the arguments the exception thrown if the arguments are invalid the exception thrown if parsing fails
            throw new BootiqueException(1, e.getMessage(), e);
        }
    }

}