public class A {
boolean openKeyStoreFile(File fKeyStore, boolean updateLastDir)
	{
		// The keystore does not exist
		if (!fKeyStore.exists())
		{
			JOptionPane.showMessageDialog(this,

// The file to open. The keystore file to open. The file to open
			    MessageFormat.format(RB.getString("FPortecle.FileNotFound.message"), fKeyStore),
			    RB.getString("FPortecle.OpenKeyStoreFile.Title"), JOptionPane.WARNING_MESSAGE);
			return false;
		}
		// The keystore file is not a file
		else if (!fKeyStore.isFile())
		{
			JOptionPane.showMessageDialog(this,
			    MessageFormat.format(RB.getString("FPortecle.NotFile.message"), fKeyStore),
			    RB.getString("FPortecle.OpenKeyStoreFile.Title"), JOptionPane.WARNING_MESSAGE);
			return false;
		}

		// Update last accessed directory
		if (updateLastDir)
		{
			m_lastDir.updateLastDir(fKeyStore);
		}

		// Get the user to enter the keystore's password
		DGetPassword dGetPassword = new DGetPassword(this,
		    MessageFormat.format(RB.getString("FPortecle.GetKeyStorePassword.Title"), fKeyStore.getName()));
		dGetPassword.setLocationRelativeTo(this);
		SwingHelper.showAndWait(dGetPassword);
		char[] cPassword = dGetPassword.getPassword();

		if (cPassword == null)
		{
			return false;
		}

		try
		{
			// Load the keystore - try to open as each of the allowed types in turn until successful
			KeyStore openedKeyStore = null;

			// Types
			KeyStoreType[] keyStoreTypes = KeyStoreUtil.getAvailableTypes();

			// Exceptions
			CryptoException[] cexs = new CryptoException[keyStoreTypes.length];

			// Tried types
			StringBuilder tried = new StringBuilder();

			for (int iCnt = 0; iCnt < keyStoreTypes.length; iCnt++)
			{
				tried.append(", ").append(keyStoreTypes[iCnt]);
				try
				{
					openedKeyStore = KeyStoreUtil.loadKeyStore(fKeyStore, cPassword, keyStoreTypes[iCnt]);
					break; // Success
				}
				catch (CryptoException cex)
				{
					cexs[iCnt] = cex;
				}
			}

			if (openedKeyStore == null)
			{
				// None of the types worked - show each of the errors?
				if (tried.length() > 2)
				{
					tried.delete(0, 2); // Chop leading ", "
				}
				int iSelected = SwingHelper.showConfirmDialog(this,
				    MessageFormat.format(RB.getString("FPortecle.NoOpenKeyStoreFile.message"), fKeyStore, tried),
				    RB.getString("FPortecle.OpenKeyStoreFile.Title"));
				if (iSelected == JOptionPane.YES_OPTION)
				{
					for (CryptoException cex : cexs)
					{
						DThrowable.showAndWait(this, null, cex);
					}
				}

				return false;
			}

			// Create a keystore wrapper for the keystore
			m_keyStoreWrap = new KeyStoreWrapper(openedKeyStore, fKeyStore, cPassword);

			// Update the frame's components and title
			selectedAlias = null;
			updateControls();
			updateTitle();

			// Add keystore file to recent files in file menu
			m_jmrfFile.add(createRecentFileMenuItem(fKeyStore));

			return true;
		}
		catch (FileNotFoundException ex)
		{
			JOptionPane.showMessageDialog(this,
			    MessageFormat.format(RB.getString("FPortecle.NoRead.message"), fKeyStore),
			    RB.getString("FPortecle.OpenKeyStoreFile.Title"), JOptionPane.WARNING_MESSAGE);
			return false;
		}
		catch (Exception ex)
		{
			DThrowable.showAndWait(this, null, ex);
			return false;
		}
	}

}