public class A {
@Test
    public void invalidRangeValue() {
        victim.setValidBookmarkLevels(validLevels);
        assertEquals(ValidationState.NOT_VALIDATED, victim.getValidationState());
        clickOn(victim).write("40").push(KeyCode.ENTER);
        assertEquals(ValidationState.INVALID, victim.getValidationState());

// The CSS selector for invalid bookmark levels. The CSS selector for the invalid bookmark levels. The CSS selector for the invalid range.
        Arrays.stream(Style.INVALID.css()).forEach((s) -> assertFalse(lookup("." + s).tryQuery().isEmpty()));
    }

}