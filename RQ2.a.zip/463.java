public class A {
private String getGeneralNameString(GeneralName generalName, LinkClass linkClass)
	    throws IOException
	{
		StringBuilder strBuff = new StringBuilder();
		int tagNo = generalName.getTagNo();

		switch (tagNo)
		{
			case GeneralName.otherName:
				ASN1Sequence other = (ASN1Sequence) generalName.getName();
				String sOid = ((ASN1ObjectIdentifier) other.getObjectAt(0)).getId();
				String sVal = stringify(other.getObjectAt(1));
				try
				{
					strBuff.append(RB.getString(sOid));
				}
				catch (MissingResourceException e)
				{
					strBuff.append(MessageFormat.format(RB.getString("GeneralName." + tagNo), sOid));
				}
				strBuff.append(": ");
				strBuff.append(sVal);
				break;

			case GeneralName.rfc822Name:
				String sRfc822 = generalName.getName().toString();

// the url to be used for the conversion the URL to be used for the conversion the url of the GeneralName to be converted
				String urlEnc = URLEncoder.encode(sRfc822, StandardCharsets.UTF_8.name());
				strBuff.append(RB.getString("GeneralName." + tagNo));
				strBuff.append(": ");
				strBuff.append(getLink("mailto:" + urlEnc, escapeHtml(sRfc822), null));
				break;

			case GeneralName.dNSName:
			case GeneralName.registeredID:
			case GeneralName.x400Address: // TODO: verify formatting
			case GeneralName.ediPartyName: // TODO: verify formatting
				strBuff.append(RB.getString("GeneralName." + tagNo));
				strBuff.append(": ");
				strBuff.append(escapeHtml(generalName.getName()));
				break;

			case GeneralName.directoryName:
				ASN1Encodable name = generalName.getName();
				strBuff.append(RB.getString("GeneralName." + tagNo));
				strBuff.append(": ");
				// TODO: make E=foo@bar.com mail links
				strBuff.append(escapeHtml(name));
				break;

			case GeneralName.uniformResourceIdentifier:
				String sUri = generalName.getName().toString();
				strBuff.append(RB.getString("GeneralName." + tagNo));
				strBuff.append(": ");
				strBuff.append(getLink(sUri, escapeHtml(sUri), linkClass));
				break;

			case GeneralName.iPAddress:
				ASN1OctetString ipAddress = (ASN1OctetString) generalName.getName();

				byte[] bIpAddress = ipAddress.getOctets();

				// Output the IP Address components one at a time separated by dots
				StringBuilder sbIpAddress = new StringBuilder();

				for (int iCnt = 0, bl = bIpAddress.length; iCnt < bl; iCnt++)
				{
					// Convert from (possibly negative) byte to positive int
					sbIpAddress.append(bIpAddress[iCnt] & 0xFF);
					if ((iCnt + 1) < bIpAddress.length)
					{
						sbIpAddress.append('.');
					}
				}

				strBuff.append(RB.getString("GeneralName." + tagNo));
				strBuff.append(": ");
				strBuff.append(escapeHtml(sbIpAddress));
				break;

			default: // Unsupported general name type
				strBuff.append(
				    MessageFormat.format(RB.getString("UnrecognizedGeneralNameType"), generalName.getTagNo()));
				strBuff.append(": ");
				strBuff.append(escapeHtml(generalName.getName()));
				break;
		}

		return strBuff.toString();
	}

}