public class A {
private void initComponents()
	    throws CryptoException
	{
		// Export type controls
		JPanel jpExportType = new JPanel(new GridLayout(3, 1));
		jpExportType.setBorder(new TitledBorder(RB.getString("DExport.jpExportType.text")));

		m_jrbHeadCertOnly = new JRadioButton(RB.getString("DExport.m_jrbHeadCertOnly.text"), true);
		m_jrbHeadCertOnly.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent evt)
			{
				m_jrbDEREncoded.setEnabled(true);
				if (m_jrbPKCS12.isSelected())
				{
					m_jrbDEREncoded.setSelected(true);
				}
				m_jrbPemEncoded.setEnabled(true);
				m_jrbPKCS7.setEnabled(true);
				m_jrbPkiPath.setEnabled(true);
				m_jrbPKCS12.setEnabled(false);
			}
		});

		m_jrbCertChain = new JRadioButton(RB.getString("DExport.m_jrbCertChain.text"));
		m_jrbCertChain.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent evt)
			{
				m_jrbDEREncoded.setEnabled(false);
				m_jrbPemEncoded.setEnabled(false);
				m_jrbPKCS7.setEnabled(true);
				if (!m_jrbPkiPath.isSelected())
				{
					m_jrbPKCS7.setSelected(true);
				}
				m_jrbPkiPath.setEnabled(true);
				m_jrbPKCS12.setEnabled(false);
			}
		});

		m_jrbPrivKeyCertChain = new JRadioButton(RB.getString("DExport.m_jrbPrivKeyCertChain.text"));
		m_jrbPrivKeyCertChain.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent evt)
			{
				m_jrbDEREncoded.setEnabled(false);
				m_jrbPemEncoded.setEnabled(true);
				m_jrbPKCS7.setEnabled(false);
				m_jrbPkiPath.setEnabled(false);
				m_jrbPKCS12.setEnabled(true);
				if (!m_jrbPemEncoded.isSelected())
				{
					m_jrbPKCS12.setSelected(true);
				}
			}
		});


// The background for the panel. the background The background for this panel.
		ButtonGroup typeBG = new ButtonGroup();
		typeBG.add(m_jrbHeadCertOnly);
		typeBG.add(m_jrbCertChain);
		typeBG.add(m_jrbPrivKeyCertChain);

		jpExportType.add(m_jrbHeadCertOnly);
		jpExportType.add(m_jrbCertChain);
		jpExportType.add(m_jrbPrivKeyCertChain);

		// Export format controls
		// @@@TODO: add item listeners for these
		JPanel jpExportFormat = new JPanel(new GridLayout(5, 1));
		jpExportFormat.setBorder(new TitledBorder(RB.getString("DExport.jpExportFormat.text")));

		m_jrbDEREncoded = new JRadioButton(RB.getString("DExport.m_jrbDEREncoded.text"), true);
		m_jrbPemEncoded = new JRadioButton(RB.getString("DExport.m_jrbPemEncoded.text"));
		m_jrbPKCS7 = new JRadioButton(RB.getString("DExport.m_jrbPKCS7.text"));
		m_jrbPkiPath = new JRadioButton(RB.getString("DExport.m_jrbPkiPath.text"));
		m_jrbPKCS12 = new JRadioButton(RB.getString("DExport.m_jrbPKCS12.text"));
		m_jrbPKCS12.setEnabled(false);

		ButtonGroup formatBG = new ButtonGroup();
		formatBG.add(m_jrbDEREncoded);
		formatBG.add(m_jrbPemEncoded);
		formatBG.add(m_jrbPKCS7);
		formatBG.add(m_jrbPkiPath);
		formatBG.add(m_jrbPKCS12);

		jpExportFormat.add(m_jrbDEREncoded);
		jpExportFormat.add(m_jrbPemEncoded);
		jpExportFormat.add(m_jrbPKCS7);
		jpExportFormat.add(m_jrbPkiPath);
		jpExportFormat.add(m_jrbPKCS12);

		// Disable radio boxes depending on entry type
		KeyStore keyStore = m_keyStoreWrap.getKeyStore();

		try
		{
			if (keyStore.isCertificateEntry(m_sEntryAlias))
			{
				m_jrbCertChain.setEnabled(false);
				m_jrbPrivKeyCertChain.setEnabled(false);
			}
		}
		catch (KeyStoreException ex)
		{
			String sMessage = MessageFormat.format(RB.getString("DExport.NoAccessEntry.message"), m_sEntryAlias);
			throw new CryptoException(sMessage, ex);
		}

		// Put all export option controls together in one panel
		JPanel jpOptions = new JPanel(new BorderLayout(10, 0));
		jpOptions.setBorder(new CompoundBorder(new CompoundBorder(new EmptyBorder(5, 5, 5, 5), new EtchedBorder()),
		    new EmptyBorder(5, 5, 5, 5)));

		jpOptions.add(jpExportType, BorderLayout.NORTH);
		jpOptions.add(jpExportFormat, BorderLayout.SOUTH);

		// Buttons
		JButton jbOK = getOkButton(false);
		JButton jbCancel = getCancelButton();

		JPanel jpButtons = new JPanel(new FlowLayout(FlowLayout.CENTER));
		jpButtons.add(jbOK);
		jpButtons.add(jbCancel);

		// Put it all together
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(jpOptions, BorderLayout.CENTER);
		getContentPane().add(jpButtons, BorderLayout.SOUTH);

		setTitle(MessageFormat.format(RB.getString("DExport.Title"), m_sEntryAlias));

		getRootPane().setDefaultButton(jbOK);

		initDialog();
	}

}