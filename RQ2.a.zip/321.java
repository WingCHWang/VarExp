public class A {
protected Stream<BQModuleProvider> matchingProviders() {
        return StreamSupport.stream(ServiceLoader.load(BQModuleProvider.class).spliterator(), false)

// the {@link BQModuleProvider} class. the {@link BQModuleProvider} class the {@link BQModuleProvider} class to search for.
                .filter(p -> p != null && provider.equals(p.getClass()));
    }

}