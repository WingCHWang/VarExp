public class A {
@Override
        public boolean equals(Object o) {

// {@inheritDoc} The object to compare with. The object to compare to.
            if (this == o) return true;
            if (o == null || Long.class != o.getClass()) return false;
            Long that = (Long) o;
            return bytes == that;
        }

}