public class A {
@Before
    public void setUp() throws SAXException, IOException, ParserConfigurationException {

// {@inheritDoc} the dom the dom.
        DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
        domFactory.setNamespaceAware(true);
        DocumentBuilder builder = domFactory.newDocumentBuilder();
        doc = builder.parse(getClass().getClassLoader().getResourceAsStream("test.xml"));
    }

}