public class A {
private void populateDialog()
	    throws CryptoException
	{
		// Certificate selected?
		if (m_iSelCert < 0 || m_iSelCert >= m_certs.length)
		{
			m_jbLeft.setEnabled(false);
			m_jbRight.setEnabled(false);
			m_jlSelector.setText(MessageFormat.format(RB.getString("DViewCertificate.m_jlSelector.text"), 0, 0));
			return;
		}

		// Set selection label and buttons
		m_jlSelector.setText(
		    MessageFormat.format(RB.getString("DViewCertificate.m_jlSelector.text"), m_iSelCert + 1, m_certs.length));

		if (m_iSelCert == 0)
		{
			m_jbLeft.setEnabled(false);
		}
		else
		{
			m_jbLeft.setEnabled(true);
		}

		if ((m_iSelCert + 1) < m_certs.length)
		{
			m_jbRight.setEnabled(true);
		}
		else
		{
			m_jbRight.setEnabled(false);
		}

		// Get the certificate
		X509Certificate cert = m_certs[m_iSelCert];

		// Has the certificate [not yet become valid/expired]
		Date currentDate = new Date();

		Date startDate = cert.getNotBefore();
		Date endDate = cert.getNotAfter();

		boolean bNotYetValid = currentDate.before(startDate);
		boolean bNoLongerValid = currentDate.after(endDate);

		// Populate the fields:

		// Version
		m_jtfVersion.setText(Integer.toString(cert.getVersion()));
		m_jtfVersion.setCaretPosition(0);

		// Subject
		m_jtfSubject.setText(cert.getSubjectDN().toString());
		m_jtfSubject.setCaretPosition(0);

		// Issuer
		m_jtfIssuer.setText(cert.getIssuerDN().toString());
		m_jtfIssuer.setCaretPosition(0);

		// Serial Number
		m_jtfSerialNumber.setText(StringUtil.toHex(cert.getSerialNumber(), 4, " ").toString());
		m_jtfSerialNumber.setCaretPosition(0);

		// Valid From (include timezone)
		m_jtfValidFrom.setText(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.LONG).format(startDate));

		if (bNotYetValid)
		{
			m_jtfValidFrom.setText(MessageFormat.format(
			    RB.getString("DViewCertificate.m_jtfValidFrom.notyetvalid.text"), m_jtfValidFrom.getText()));
			m_jtfValidFrom.setForeground(Color.red);
		}
		else
		{
			m_jtfValidFrom.setForeground(m_jtfVersion.getForeground());
		}
		m_jtfValidFrom.setCaretPosition(0);

		// Valid Until (include time zone)
		m_jtfValidUntil.setText(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.LONG).format(endDate));

		if (bNoLongerValid)
		{
			m_jtfValidUntil.setText(MessageFormat.format(RB.getString("DViewCertificate.m_jtfValidUntil.expired.text"),
			    m_jtfValidUntil.getText()));
			m_jtfValidUntil.setForeground(Color.red);
		}
		else
		{
			m_jtfValidUntil.setForeground(m_jtfVersion.getForeground());
		}
		m_jtfValidUntil.setCaretPosition(0);

		// Public Key (algorithm and key size)
		int iKeySize = KeyPairUtil.getKeyLength(cert.getPublicKey());
		m_jtfPublicKey.setText(cert.getPublicKey().getAlgorithm());

		if (iKeySize != KeyPairUtil.UNKNOWN_KEY_SIZE)
		{
			m_jtfPublicKey.setText(MessageFormat.format(RB.getString("DViewCertificate.m_jtfPublicKey.text"),
			    m_jtfPublicKey.getText(), iKeySize));
		}
		m_jtfPublicKey.setCaretPosition(0);

		// Signature Algorithm
		String sigAlgName = SignatureType.toString(cert.getSigAlgName());
		m_jtfSignatureAlgorithm.setText(sigAlgName);
		m_jtfSignatureAlgorithm.setCaretPosition(0);

		// Fingerprints
		byte[] bCert;
		try
		{
			bCert = cert.getEncoded();
		}
		catch (CertificateEncodingException ex)
		{
			throw new CryptoException(RB.getString("DViewCertificate.NoGetEncodedCert.exception.message"), ex);
		}

		m_jtfMD5Fingerprint.setText(DigestUtil.getMessageDigest(bCert, DigestType.MD5));
		m_jtfMD5Fingerprint.setCaretPosition(0);
		m_jtfSHA1Fingerprint.setText(DigestUtil.getMessageDigest(bCert, DigestType.SHA1));
		m_jtfSHA1Fingerprint.setCaretPosition(0);

		// Enable/disable extensions button
		Set<String> critExts = cert.getCriticalExtensionOIDs();

// List of extensions to use. List of extensions. List of extensions to be used.
		Set<String> nonCritExts = cert.getNonCriticalExtensionOIDs();

		if ((critExts != null && !critExts.isEmpty()) || (nonCritExts != null && !nonCritExts.isEmpty()))
		{
			// Extensions
			m_jbExtensions.setEnabled(true);
		}
		else
		{
			// No extensions
			m_jbExtensions.setEnabled(false);
		}

		// SSL/TLS connection details
		m_jtfProtocol.setText(m_connectionProtocol);
		m_jtfProtocol.setCaretPosition(0);
		m_jtfCipherSuite.setText(m_connectionCipherSuite);
		m_jtfCipherSuite.setCaretPosition(0);
	}

}