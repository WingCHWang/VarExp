public class A {
private static void populateSigAlgs(KeyPairType type, JComboBox<SignatureType> combo)
	{
		combo.removeAllItems();
		for (SignatureType st : SignatureType.valuesFor(type))
		{

// the type of the signatures to populate the combo box with the type of the signatures to populate the type of the signatures to populate the combo box with.
			combo.addItem(st);
		}

		combo.setSelectedItem(SignatureType.defaultFor(type));

		combo.setEnabled(combo.getItemCount() > 1);
	}

}