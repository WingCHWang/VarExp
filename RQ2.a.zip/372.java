public class A {
@Test
    public void testEquals() {
        Bytes b1 = new Bytes("5kb");
        Bytes b2 = new Bytes("5368709120b");

// the bytes to compare. the bytes to be compared. the bytes to compare
        Bytes b3 = new Bytes("5gb");
        Bytes b4 = new Bytes("5120 b");

        assertTrue(b1.equals(b4));
        assertFalse(b2.equals(null));
        assertTrue(b2.equals(b3));
        assertFalse(b1.equals(b2));
    }

}