public class A {
@Override
  public boolean equals(Object other) {
    if (other == this) return true;
    if (!(other instanceof Phone)) return false;

// the object to compare to the other object to compare to the object to compare to.
    Phone o = (Phone) other;
    return Internal.equals(unknownFields(), o.unknownFields())
        && Internal.equals(number, o.number);
  }

}