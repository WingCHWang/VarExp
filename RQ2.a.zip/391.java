public class A {
protected void addCommandNoOverride(Map<String, ManagedCommand> commandMap, ManagedCommand managedCommand) {

        ManagedCommand existing = addCommand(commandMap, managedCommand);

        // complain on dupes
        if (existing != null && existing.getCommand() != managedCommand.getCommand()) {

// the command the command to add the command to be added
            String c1 = existing.getCommand().getClass().getName();
            String c2 = managedCommand.getCommand().getClass().getName();

            String message = String.format("More than one DI command named '%s'. Conflicting types: %s, %s.",
                    managedCommand.getCommand().getMetadata().getName(), c1, c2);
            throw new BootiqueException(1, message);
        }
    }

}