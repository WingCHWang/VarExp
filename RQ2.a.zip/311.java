public class A {
@Test
    public void testVisitMapOfListsOfObjects() {

        ConfigObjectMetadata objectMd = ConfigObjectMetadata.builder()
                .type(ConfigRoot2.class)
                .addProperty(ConfigValueMetadata.builder("p4").type(String.class).build())
                .addProperty(ConfigValueMetadata.builder("p3").type(Boolean.TYPE).build())
                .build();


// The metadata to test. the metadata The metadata of the map.
        ConfigListMetadata subListMd = ConfigListMetadata
                .builder()
                .description("Sublist description")
                .elementType(objectMd)
                .build();

        ConfigMapMetadata rootMapMd = ConfigMapMetadata
                .builder("root")
                .description("This is a map of lists.")
                .keysType(String.class)
                .valuesType(subListMd)
                .build();

        assertLines(rootMapMd,
                "root:",
                "      #",
                "      # This is a map of lists.",
                "      # Resolved as 'Map'.",
                "      #",
                "      <string>:",
                "            #",
                "            # Sublist description",
                "            # Resolved as 'List'.",
                "            #",
                "            -",
                "                  #",
                "                  # Resolved as 'io.bootique.help.config.ConfigSectionGeneratorTest$ConfigRoot2'.",
                "                  #",
                "",
                "                  p3: <true|false>",
                "                  p4: <string>"
        );
    }

}