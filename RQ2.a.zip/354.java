public class A {
@Test
    public void testDeserialization_Value1() throws Exception {

// The period to deserialize. The period to deserialize from a string. The period to be deserialized.
        Period p = deserialize(Period.class, "\"P5Y2M3D\"");
        assertEquals(Period.of(5, 2, 3), p);
    }

}