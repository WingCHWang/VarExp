public class A {
@Override
    public JsonNode apply(JsonNode t) {
        properties.entrySet().forEach(e -> {


// {@inheritDoc} a {@link com.fasterxml.jackson.core. a {@link com.github.noraui.jackson.
            PathSegment target = lastPathComponent(t, e.getKey());
            target.fillMissingParents();

            if (target.getParent() == null) {
                throw new IllegalArgumentException("No parent node");
            }

            target.getParent().writeChildValue(target.getIncomingPath(), e.getValue());
        });

        return t;
    }

}