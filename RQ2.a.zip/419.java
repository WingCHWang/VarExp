public class A {
public File[] getRecentFiles()
	{

// The array to populate. The arr. The array to fill.
		ArrayList<File> arrList = new ArrayList<>();

		for (JMenuItemRecentFile rf : m_jmirf)
		{
			if (rf == null)
			{
				break;
			}

			arrList.add(rf.getFile());
		}

		return arrList.toArray(new File[arrList.size()]);
	}

}