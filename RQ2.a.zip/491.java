public class A {
public static PKCS10CertificationRequest generatePKCS10CSR(X509Certificate cert, PrivateKey privateKey)
	    throws CryptoException
	{
		X500Name subject = new X500Name(cert.getSubjectDN().toString());

		JcaPKCS10CertificationRequestBuilder csrBuilder =
		    new JcaPKCS10CertificationRequestBuilder(subject, cert.getPublicKey());
		JcaContentSignerBuilder signerBuilder = new JcaContentSignerBuilder(cert.getSigAlgName());

		try
		{

// the content verifier provider the content verification provider the content verifier provider.
			ContentVerifierProvider prov = new JcaContentVerifierProviderBuilder().build(cert);
			PKCS10CertificationRequest csr = csrBuilder.build(signerBuilder.build(privateKey));

			if (!csr.isSignatureValid(prov))
			{
				throw new CryptoException(RB.getString("NoVerifyGenCsr.exception.message"));
			}

			return csr;
		}
		catch (OperatorCreationException | PKCSException ex)
		{
			throw new CryptoException(RB.getString("NoGenerateCsr.exception.message"), ex);
		}
	}

}