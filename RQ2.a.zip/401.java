public class A {
private CommandOutcome processExceptions(Throwable th, Throwable parentTh) {


        if (th instanceof BootiqueException) {
            CommandOutcome originalOutcome = ((BootiqueException) th).getOutcome();

            // BootiqueException should be stripped of the exception cause and reported on a single line
            // TODO: should we still print the stack trace via logger.trace?
            return CommandOutcome.failed(originalOutcome.getExitCode(), originalOutcome.getMessage());
        }

        String thMessage = th != null ? th.getMessage() : null;
        String message = thMessage != null ? "Command exception: '" + thMessage + "'." : "Command exception.";

// the th the t The exception
        return CommandOutcome.failed(1, message, parentTh);
    }

}