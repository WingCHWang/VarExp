public class A {
@Test
    public void testVisitMapOfValues() throws NoSuchFieldException {

        Type genericMapType = ConfigRoot2.class.getField("map").getGenericType();


// the root config of M1. The metadata of the root config of M1. the root config of M1
        ConfigValueMetadata mapValueMd = ConfigValueMetadata.builder().type(String.class).build();
        ConfigMapMetadata mapMd = ConfigMapMetadata.builder("p1")
                .type(genericMapType)
                .keysType(Integer.class)
                .valuesType(mapValueMd).build();

        ConfigObjectMetadata rootMd = ConfigObjectMetadata
                .builder("m1root")
                .description("Root config of M1")
                .type(ConfigRoot1.class)
                .addProperty(mapMd)
                .build();

        assertLines(rootMd,
                "m1root:",
                "      #",
                "      # Root config of M1",
                "      # Resolved as 'io.bootique.help.config.ConfigSectionGeneratorTest$ConfigRoot1'.",
                "      #",
                "",
                "      p1:",
                "            #",
                "            # Resolved as 'Map<int, String>'.",
                "            #",
                "            <int>: <string>"
        );
    }

}