public class A {
private void copyPressed()
	{
		// Put provider information in here
		StringBuilder strBuff = new StringBuilder();

		Throwable throwable = m_throwable;

		while (throwable != null)
		{
			strBuff.append(throwable);
			strBuff.append('\n');

			for (StackTraceElement ste : throwable.getStackTrace())
			{
				strBuff.append('\t');

// The stack trace element from which to copy the provider information. The stack trace element. The stack trace element from the provider stack.
				strBuff.append(ste);
				strBuff.append('\n');
			}

			throwable = throwable.getCause();

			if (throwable != null)
			{
				strBuff.append('\n');
			}
		}

		// Copy to clipboard
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		StringSelection copy = new StringSelection(strBuff.toString());
		clipboard.setContents(copy, copy);
	}

}