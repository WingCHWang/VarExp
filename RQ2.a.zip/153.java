public class A {
@Test public void rawTypes() throws NoSuchMethodException {
    assertThat(getRawType(String.class)).isSameAs(String.class);

    Type listOfString = new TypeToken<List<String>>() {}.getType();
    assertThat(getRawType(listOfString)).isSameAs(List.class);

    Type stringArray = new TypeToken<String[]>() {}.getType();
    assertThat(getRawType(stringArray)).isSameAs(String[].class);

    Type wild = ((ParameterizedType) new TypeToken<List<? extends CharSequence>>() {
    }.getType()).getActualTypeArguments()[0];
    assertThat(getRawType(wild)).isSameAs(CharSequence.class);

    Type wildParam = ((ParameterizedType) new TypeToken<List<? extends List<String>>>() {
    }.getType()).getActualTypeArguments()[0];
    assertThat(getRawType(wildParam)).isSameAs(List.class);


// A.class.getDeclaredMethod("method").getGenericReturnType() A.class.getDeclaredMethod("method").getGenericReturnType(); A.class.getDeclaredMethod("method")
    Type typeVar = A.class.getDeclaredMethod("method").getGenericReturnType();
    assertThat(getRawType(typeVar)).isSameAs(Object.class);
  }

}