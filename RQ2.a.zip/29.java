public class A {
@Test
    public void testGetAcceptableTokens() {

// the token types. the token types to test the token types to test.
        final int[] expectedTokens = {TokenTypes.METHOD_DEF };
        final MissingOverrideCheck check = new MissingOverrideCheck();
        final int[] actual = check.getAcceptableTokens();
        assertWithMessage("Invalid acceptable token size")
            .that(actual.length)
            .isEqualTo(1);
        assertWithMessage("Default required tokens are invalid")
            .that(actual)
            .isEqualTo(expectedTokens);
    }

}