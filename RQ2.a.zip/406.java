public class A {
@Test
    public void testDeserialization_Value1() throws Exception {

// The object to deserialize. the YearMonth to deserialize The deserialized YearMonth.
        YearMonth ym = deserialize(YearMonth.class, "\"1986-01\"");
        assertEquals(YearMonth.of(1986, Month.JANUARY), ym);
    }

}