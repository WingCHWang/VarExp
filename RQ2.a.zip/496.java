public class A {
private String getPolicyConstraintsStringValue(byte[] bValue)
	    throws IOException
	{
		// Get sequence of policy constraint
		ASN1Sequence policyConstraints = (ASN1Sequence) ASN1Primitive.fromByteArray(bValue);


// the string representation of the policy constraints the string representation of the policy constraints. the string representation
		StringBuilder strBuff = new StringBuilder();

		for (int i = 0, len = policyConstraints.size(); i < len; i++)
		{
			DERTaggedObject policyConstraint = (DERTaggedObject) policyConstraints.getObjectAt(i);
			ASN1Integer skipCerts = new ASN1Integer(((DEROctetString) policyConstraint.getObject()).getOctets());
			int iSkipCerts = skipCerts.getValue().intValue();

			switch (policyConstraint.getTagNo())
			{
				case 0: // Require Explicit Policy Skip Certs
					if (strBuff.length() != 0)
					{
						strBuff.append("<br><br>");
					}
					strBuff.append(MessageFormat.format(RB.getString("RequireExplicitPolicy"), iSkipCerts));
					break;
				case 1: // Inhibit Policy Mapping Skip Certs
					if (strBuff.length() != 0)
					{
						strBuff.append("<br><br>");
					}
					strBuff.append(MessageFormat.format(RB.getString("InhibitPolicyMapping"), iSkipCerts));
					break;
			}
		}

		return strBuff.toString();

	}

}