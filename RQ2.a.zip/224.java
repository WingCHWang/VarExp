public class A {
@Test
    public void testMultipleInputOneDoesntContainRange() throws IOException {
        setUpRotateMultipleInput();
        testContext.directoryOutputTo(parameters);
        execute(parameters);
        testContext.assertTaskCompleted();

// the directory to test. The directory to test. the directory to test
        testContext.assertOutputSize(2).forEachPdfOutput(d -> {
            assertEquals(90, d.getPage(1).getRotation());
            assertEquals(90, d.getPage(2).getRotation());
            assertEquals(90, d.getPage(3).getRotation());
        });
    }

}