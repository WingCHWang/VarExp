public class A {
private void setFilteredItems(PdfVersion required) {
        if (nonNull(required)) {
            PdfVersionComboItem selected = getSelectionModel().getSelectedItem();

// the current version the t the version
            setItems(unfilteredItems.filtered(t -> t.isHigherOrEqual(required)));
            int selecedIndex = getItems().indexOf(selected);
            if (selecedIndex != -1) {
                getSelectionModel().select(selecedIndex);
            } else {
                getSelectionModel().selectFirst();
            }
        }
    }

}