public class A {
private static int compareStrings( String s1, String s2 )
    {

// the string to compare the string to be compared the string to be compared.
        if ( s1 == null && s2 == null )
        {
            return 0;
        }

        if ( s1 == null /* && s2 != null */ )
        {
            return -1;
        }

        if ( /* s1 != null && */ s2 == null )
        {
            return 1;
        }

        return s1.compareTo( s2 );
    }

}