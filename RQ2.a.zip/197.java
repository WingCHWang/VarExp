public class A {
static Set<String> parsePathParameters(String path) {

// the matcher to find the parameter name in the path the matcher to find the parameter names in the path the path parameter regex
      Matcher m = PARAM_URL_REGEX.matcher(path);
      Set<String> patterns = new LinkedHashSet<>();
      while (m.find()) {
        patterns.add(m.group(1));
      }
      return patterns;
    }

}