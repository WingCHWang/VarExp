public class A {
@Test
    public void testGetAcceptableTokens() {

// a {@link ClassTypeParameterNameCheck} object. a {@link ClassTypeParameterNameCheck} object a {@link ClassTypeParameterNameCheck} instance.
        final ClassTypeParameterNameCheck typeParameterNameCheckObj =
            new ClassTypeParameterNameCheck();
        final int[] actual = typeParameterNameCheckObj.getAcceptableTokens();
        final int[] expected = {
            TokenTypes.TYPE_PARAMETER,
        };
        assertWithMessage("Default acceptable tokens are invalid")
            .that(actual)
            .isEqualTo(expected);
    }

}