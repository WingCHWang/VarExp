public class A {
@Override public void onError(Throwable e) {

// {@inheritDoc} the {@link Throwable} the exception
    events.add(Notification.<T>createOnError(e));
  }

}