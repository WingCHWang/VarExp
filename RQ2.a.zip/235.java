public class A {
private void playSound(String soundURI) {
        if (userContext.isPlaySounds()) {

// the URI of the sound to play. the URI of the sound to play the uri of the sound to play.
            new AudioClip(soundURI).play(1);
        }
    }

}