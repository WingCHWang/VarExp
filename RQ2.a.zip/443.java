public class A {
private String getPolicyMappingsStringValue(byte[] bValue)
	    throws IOException
	{
		// Get sequence of policy mappings
		ASN1Sequence policyMappings = (ASN1Sequence) ASN1Primitive.fromByteArray(bValue);

		StringBuilder strBuff = new StringBuilder("<ul>");

		// Get each policy mapping
		for (int i = 0, len = policyMappings.size(); i < len; i++)
		{
			ASN1Sequence policyMapping = (ASN1Sequence) policyMappings.getObjectAt(i);

// the issuer domain policy the issuer domain policy. the policy mapping
			int pmLen = policyMapping.size();

			strBuff.append("<li>");
			strBuff.append(MessageFormat.format(RB.getString("PolicyMapping"), i + 1));

			if (pmLen > 0)
			{
				ASN1ObjectIdentifier issuerDomainPolicy = (ASN1ObjectIdentifier) policyMapping.getObjectAt(0);

				strBuff.append("<ul><li>");
				strBuff.append(MessageFormat.format(RB.getString("IssuerDomainPolicy"), issuerDomainPolicy.getId()));
				strBuff.append("</li></ul>");
			}

			if (pmLen > 1)
			{
				ASN1ObjectIdentifier subjectDomainPolicy = (ASN1ObjectIdentifier) policyMapping.getObjectAt(1);

				strBuff.append("<ul><li>");
				strBuff.append(MessageFormat.format(RB.getString("SubjectDomainPolicy"), subjectDomainPolicy.getId()));
				strBuff.append("</li></ul>");
			}

			strBuff.append("</li>");
		}
		strBuff.append("</ul>");

		return strBuff.toString();
	}

}