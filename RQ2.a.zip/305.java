public class A {
@Override
        public int compareTo(BytesObject o) {

// the result of the comparison the value to compare the result
            long cmp = Long.compare(bytes, o.getBytes());
            if (cmp != 0) {
                return (int) cmp;
            }
            return (int) (bytes - o.getBytes());
        }

}