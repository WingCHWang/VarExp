public class A {
@Test public void syncFailureThrownAfterDelay() {
    behavior.setDelay(100, MILLISECONDS);
    behavior.setVariancePercent(0);
    behavior.setFailurePercent(0);

    Call<String> call = service.failure();


// the time in nanoseconds. the time in nanoseconds the time in nanoseconds after which the sync should be performed.
    long startNanos = System.nanoTime();
    try {
      call.execute();
      fail();
    } catch (IOException e) {
      long tookMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startNanos);
      assertThat(tookMs).isGreaterThanOrEqualTo(100);
      assertThat(e).isSameAs(mockFailure);
    }
  }

}