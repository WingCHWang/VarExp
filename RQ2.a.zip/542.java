public class A {
private static String toWildcards(String[] exts)
	{
		StringBuilder res = new StringBuilder();

// the array of extensions the array of extensions to convert the array of wildcard extensions
		for (String ext : exts)
		{
			res.append("*.").append(ext).append(FILELIST_SEPARATOR);
		}
		res.setLength(res.length() - FILELIST_SEPARATOR.length());
		return res.toString();
	}

}