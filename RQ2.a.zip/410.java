public class A {
static Function<URL, String> createConfigReader() {
        return (url) -> {

            StringBuilder string = new StringBuilder();
            byte[] buffer = new byte[1024];
            int read;

// the character set used for reading the contents of a configuration file. the character set used for reading the contents of the configuration file. the charset to use for reading the contents of the configuration file.
            Charset utf8 = Charset.forName("UTF8");

            try (InputStream in = url.openStream()) {
                while ((read = in.read(buffer, 0, buffer.length)) > 0) {
                    string.append(new String(buffer, 0, read, utf8));
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            return string.toString();
        };
    }

}