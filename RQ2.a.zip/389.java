public class A {
@Test
    public void testVisitListOfValues() {


// The metadata to test. the metadata to test. the metadata to test
        ConfigValueMetadata listMd1 = ConfigValueMetadata.builder().type(Integer.TYPE).build();

        ConfigObjectMetadata m1Config = ConfigObjectMetadata
                .builder("m1root")
                .description("Root config of M1")
                .type(ConfigRoot1.class)
                .addProperty(ConfigListMetadata.builder("p1").elementType(listMd1).build())
                .build();

        assertLines(m1Config,
                "m1root:",
                "      #",
                "      # Root config of M1",
                "      # Resolved as 'io.bootique.help.config.ConfigSectionGeneratorTest$ConfigRoot1'.",
                "      #",
                "",
                "      p1:",
                "            #",
                "            # Resolved as 'List'.",
                "            #",
                "            - <int>"
        );
    }

}