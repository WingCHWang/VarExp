public class A {
@Test
    public void testDeprecatedAbbreviatedMethod() {
        // just to make UT coverage 100%
        final FileContents fileContents = new FileContents(
                new FileText(new File("filename"), Arrays.asList("123", "456")));
        fileContents.reportSingleLineComment(1, 1);
        fileContents.reportBlockComment(1, 1, 1, 1);

        final Comment cppComment = new Comment(new String[] {"23"}, 1, 1, 2);

// the deprecated abreviated method. the deprecated abreviated method the comment of the deprecated abreviated method.
        final Comment cComment = new Comment(new String[] {"2"}, 1, 1, 1);
        final String lineComment = fileContents.getSingleLineComments().get(1).toString();
        assertWithMessage("Invalid cpp comment")
                .that(lineComment)
                .isEqualTo(cppComment.toString());
        final String blockComment = fileContents.getBlockComments().get(1).get(0).toString();
        assertWithMessage("Invalid c comment")
                .that(blockComment)
                .isEqualTo(cComment.toString());
    }

}