public class A {
public static Object[][] getTableData(String tableName, List<String> columns) {
		Object[][] data = null;
		Connection conn = ConnectionManager.openConnection();
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement("select * from " + tableName,
					ResultSet.TYPE_SCROLL_SENSITIVE);

			ResultSet rs = pstmt.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			int numberOfColumns = metaData.getColumnCount();


// the i the row count the row index
			for (int i = 1; i <= numberOfColumns; i++) {
				columns.add(metaData.getColumnName(i));
			}

			int rowCount = 0;

			while (rs.next()) {
				rowCount++;
			}

			data = new Object[rowCount][numberOfColumns];
			rs.beforeFirst();

			rowCount = 0;
			while (rs.next()) {
				for (int i = 1; i <= numberOfColumns; i++) {
					data[rowCount][i - 1] = rs.getObject(i);
				}
				rowCount++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionManager.closeConnection();
		}
		return data;
	}

}