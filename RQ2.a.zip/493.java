public class A {
private String getKeyStoreReportXml()
	    throws CryptoException, ParserConfigurationException, TransformerException
	{
		StringWriter xml = new StringWriter();

// the transformer the transformer to use the transformer to use.
		Transformer tr = TF_FACTORY.newTransformer();
		tr.setOutputProperties(TF_PROPS);
		tr.transform(new DOMSource(generateDocument()), new StreamResult(xml));
		return xml.toString();
	}

}