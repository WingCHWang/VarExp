public class A {
@Test
    public void onEventTaskEventBroadcaster() {
        String moduleId = "module";

// task execution parameters Task execution request parameters Task execution parameters
        AbstractParameters params = mock(AbstractParameters.class);
        victim.request(new TaskExecutionRequestEvent(moduleId, params));
        TaskEventBroadcaster<TaskExecutionStartedEvent> broadcaster = victim.new TaskEventBroadcaster<>();
        TaskExecutionStartedEvent event = new TaskExecutionStartedEvent(null);
        Listener<TaskExecutionStartedEvent> listener = mock(Listener.class);
        eventStudio().add(TaskExecutionStartedEvent.class, listener);
        Listener<TaskExecutionStartedEvent> listenerModule = mock(Listener.class);
        eventStudio().add(TaskExecutionStartedEvent.class, listenerModule, moduleId);
        broadcaster.onEvent(event);
        verify(listener, timeout(1000).times(1)).onEvent(event);
        verify(listenerModule, timeout(1000).times(1)).onEvent(event);
    }

}