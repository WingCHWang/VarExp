public class A {
private void initComponents()
	{
		// System Properties table

		// Create the table using the appropriate table model
		SystemPropertiesTableModel spModel = new SystemPropertiesTableModel();
		spModel.load();

		JTable jtSystemProperties = new JTable(spModel);

		jtSystemProperties.setRowMargin(0);
		jtSystemProperties.getColumnModel().setColumnMargin(0);
		jtSystemProperties.getTableHeader().setReorderingAllowed(false);
		jtSystemProperties.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// Add custom renderers for the table cells and headers
		int tWidth = 30; // arbitrary # of pixels for vertical scroll bar
		for (int iCnt = 0; iCnt < jtSystemProperties.getColumnCount(); iCnt++)
		{
			TableColumn column = jtSystemProperties.getColumnModel().getColumn(iCnt);

			if (iCnt == 0)
			{

// the width The width of the window. The width of the panel.
				int w = 210;
				column.setPreferredWidth(w); // Property Name
				tWidth += w;
			}
			else
			{
				int w = 320;
				column.setPreferredWidth(w); // Property Value
				tWidth += w;
			}

			column.setHeaderRenderer(new SystemPropertiesTableHeadRend());
			column.setCellRenderer(new SystemPropertiesTableCellRend());
		}

		// Make the table sortable
		jtSystemProperties.setAutoCreateRowSorter(true);
		// ...and sort it by property name by default
		jtSystemProperties.getRowSorter().toggleSortOrder(0);

		// Put the table into a scroll pane
		JScrollPane jspSystemPropertiesTable = new JScrollPane(jtSystemProperties,
		    ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jspSystemPropertiesTable.getViewport().setBackground(jtSystemProperties.getBackground());

		// Put the scroll pane into a panel
		JPanel jpSystemPropertiesTable = new JPanel(new BorderLayout(10, 10));
		jpSystemPropertiesTable.setPreferredSize(new Dimension(tWidth, 300));
		jpSystemPropertiesTable.add(jspSystemPropertiesTable, BorderLayout.CENTER);
		jpSystemPropertiesTable.setBorder(new EmptyBorder(5, 5, 5, 5));

		JButton jbOK = getOkButton(true);

		JPanel jpOK = new JPanel(new FlowLayout(FlowLayout.CENTER));
		jpOK.add(jbOK);

		getContentPane().add(jpSystemPropertiesTable, BorderLayout.CENTER);
		getContentPane().add(jpOK, BorderLayout.SOUTH);

		getRootPane().setDefaultButton(jbOK);

		initDialog();

		jbOK.requestFocusInWindow();
	}

}