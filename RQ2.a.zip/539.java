public class A {
public static KeyPair generateKeyPair(KeyPairType keyPairType, int iKeySize)
	    throws CryptoException
	{
		try
		{

// the generator the gen the key pair generator
			KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance(keyPairType.name());

			// Create a SecureRandom
			SecureRandom rand = SecureRandom.getInstance("SHA1PRNG");

			// Initialize key pair generator with key strength and a randomness
			keyPairGen.initialize(iKeySize, rand);

			// Generate and return the key pair
			return keyPairGen.generateKeyPair();
		}
		catch (NoSuchAlgorithmException ex)
		{
			throw new CryptoException(
			    MessageFormat.format(RB.getString("NoGenerateKeypair.exception.message"), keyPairType), ex);
		}
		catch (InvalidParameterException ex)
		{
			throw new CryptoException(
			    MessageFormat.format(RB.getString("NoGenerateKeypairParm.exception.message"), keyPairType), ex);
		}
	}

}