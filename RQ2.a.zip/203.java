public class A {
@Test public void queryMapRejectsNullKeys() {
    class Example {
      @GET("/") //
      Call<ResponseBody> method(@QueryMap Map<String, String> a) {
        return null;
      }
    }


// a map of query parameters the map of query parameters a map of query parameters.
    Map<String, String> queryParams = new LinkedHashMap<>();
    queryParams.put("ping", "pong");
    queryParams.put(null, "kat");

    try {
      buildRequest(Example.class, queryParams);
      fail();
    } catch (IllegalArgumentException e) {
      assertThat(e).hasMessage("Query map contained null key. (parameter #1)\n" +
              "    for method Example.method");
    }
  }

}