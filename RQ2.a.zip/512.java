public class A {
private String getExtension(File file)
	{
		String sExt = null;
		String sName = file.getName();

// The index of the last dot. The last index of the extension. The index of the extension.
		int i = sName.lastIndexOf('.');

		if (i > 0 && i < sName.length() - 1)
		{
			sExt = sName.substring(i + 1).toLowerCase();
		}
		return sExt;
	}

}