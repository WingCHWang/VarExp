public class A {
private CommandOutcome run() {
            BQInternalTestFactory.Builder builder = testFactory
                    .app("--a")

// the BQCoreModule the b the bq core module
                    .module(b -> BQCoreModule.extend(b)
                            .addCommand(mainCommand)
                            .addCommand(successfulCommand)
                            .addCommand(failingCommand)
                            .decorateCommand(mainCommand.getClass(), decorator));

            if (moduleProvider != null) {
                builder.module(moduleProvider);
            }

            return builder.createRuntime().run();
        }

}