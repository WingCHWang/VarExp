public class A {
@Test public void multipartPartMapRejectsNullValues() {
    class Example {
      @Multipart //
      @POST("/foo/bar/") //
      Call<ResponseBody> method(@PartMap Map<String, RequestBody> parts) {
        return null;
      }
    }


// the params request parameters a map of request parameters
    Map<String, RequestBody> params = new LinkedHashMap<>();
    params.put("ping", RequestBody.create(null, "pong"));
    params.put("kit", null);

    try {
      buildRequest(Example.class, params);
      fail();
    } catch (IllegalArgumentException e) {
      assertThat(e).hasMessage("Part map contained null value for key 'kit'. (parameter #1)\n" +
              "    for method Example.method");
    }
  }

}