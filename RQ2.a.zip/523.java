public class A {
private void showOptions()
	{
		DOptions dOptions = new DOptions(this, m_bUseCaCerts, m_fCaCertsFile);
		dOptions.setLocationRelativeTo(this);
		SwingHelper.showAndWait(dOptions);

		// Store/apply the chosen options:

		// CA certificates file

// The file to store the options in. The file to store/apply the options to. The file to store/apply the chosen options.
		File fTmp = dOptions.getCaCertsFile();

		if (!fTmp.equals(m_fCaCertsFile))
		{
			// CA certificates file changed - any stored CA certificates keystore is now invalid
			m_caCertsKeyStore = null;
		}

		m_fCaCertsFile = fTmp;

		// Use CA certificates?
		m_bUseCaCerts = dOptions.isUseCaCerts();

		// Look & feel
		String newLookFeelClassName = dOptions.getLookFeelClassName();

		// Look & feel decoration
		boolean bLookFeelDecoration = dOptions.isLookFeelDecoration();

		// Look & feel/decoration changed?
		// Note: UIManager.LookAndFeelInfo.getName() and LookAndFeel.getName() can be different for the same
		// L&F (one example is the GTK+ one in J2SE 5 RC2 (Linux), where the former is "GTK+" and the latter
		// is "GTK look and feel"). Therefore, compare the class names instead.
		if (newLookFeelClassName != null &&
		    (!newLookFeelClassName.equals(UIManager.getLookAndFeel().getClass().getName()) ||
		        bLookFeelDecoration != JFrame.isDefaultLookAndFeelDecorated()))
		{
			// Yes - save selections to be picked up by application preferences,
			lookFeelClassName = newLookFeelClassName;
			m_bLookFeelDecorationOptions = bLookFeelDecoration;
			saveAppPrefs();

			JFrame.setDefaultLookAndFeelDecorated(bLookFeelDecoration);
			JDialog.setDefaultLookAndFeelDecorated(bLookFeelDecoration);
			try
			{
				UIManager.setLookAndFeel(lookFeelClassName);
				SwingUtilities.updateComponentTreeUI(getRootPane());
				pack();
			}
			catch (Exception e)
			{
				DThrowable.showAndWait(this, null, e);
			}
		}
	}

}