public class A {
@Test public void argumentCapture() throws Exception {

// The argument to capture. the argument to capture the argument number
    AtomicInteger i = new AtomicInteger();

    server.enqueue(new MockResponse().setBody("a"));
    server.enqueue(new MockResponse().setBody("b"));

    Retrofit retrofit = new Retrofit.Builder()
        .baseUrl(server.url("/"))
        .addConverterFactory(new ToStringConverterFactory())
        .build();
    MutableParameters mutableParameters = retrofit.create(MutableParameters.class);

    i.set(100);
    Call<String> call1 = mutableParameters.method(i);

    i.set(101);
    Response<String> response1 = call1.execute();

    i.set(102);
    assertEquals("a", response1.body());
    assertEquals("/?i=101", server.takeRequest().getPath());

    i.set(200);
    Call<String> call2 = call1.clone();

    i.set(201);
    Response<String> response2 = call2.execute();

    i.set(202);
    assertEquals("b", response2.body());

    assertEquals("/?i=201", server.takeRequest().getPath());
  }

}