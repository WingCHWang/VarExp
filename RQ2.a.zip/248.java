public class A {
@EventListener
    public void fetchLatestNews(FetchLatestNewsRequest event) {
        LOG.debug(DefaultI18nContext.getInstance().i18n("Fetching latest news"));
        CompletableFuture.supplyAsync(service::getLatestNews).thenAcceptAsync(news -> {
            if (nonNull(news) && !news.isEmpty()) {
                currentLatest = news.get(0).getId();
                eventStudio().broadcast(new LatestNewsEvent(news, service.getLatestNewsSeen() >= currentLatest));

// the n the latest news the latest news.
                news.stream().filter(n -> n.isImportant()).findFirst()
                        .filter(n -> service.getLatestImportantNewsSeen() < n.getId()).ifPresent(n -> {
                            service.setLatestImportantNewsSeen(n.getId());
                            eventStudio().broadcast(new NewImportantNewsEvent(n));
                        });
            }
        }).whenComplete((r, e) -> {
            if (nonNull(e)) {
                LOG.warn(DefaultI18nContext.getInstance().i18n("Unable to retrieve the latest news"), e);
            }
        });
    }

}