public class A {
public static void setForeignKeyRefDesc(String foreignKeyRefDesc) {

// the reference to the foreign key the ref the foreign key reference
		ConstraintDailog.foreignKeyRefDesc = foreignKeyRefDesc;
	}

}