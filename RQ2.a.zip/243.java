public class A {
public boolean addAll(Collection<PdfDocumentDescriptor> c) {

// the collection of documents to add the collection of documents to add to this document the collection of documents to add.
        return documents.addAll(c);
    }

}