public class A {
@Override
	public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
	    throws BadLocationException
	{

// The length of the string to be inserted. the length of the string to be inserted. the length of the string to be inserted
		int strLen;
		if (string == null || (strLen = string.length()) == 0)
		{
			// Always allow empty inserts
			super.insertString(fb, offset, string, attr);
			return;
		}

		if (fb.getDocument().getLength() + strLen > maxLength)
		{
			Toolkit.getDefaultToolkit().beep();
			return;
		}

		super.insertString(fb, offset, string, attr);
	}

}