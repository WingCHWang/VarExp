public class A {

// the minimum number of tasks to request. the minimum number of tasks to request the minimum priority of the task execution.
@EventListener(priority = Integer.MIN_VALUE + 1)
    public void request(TaskExecutionRequestEvent event) {
        this.latest = event;
    }

}