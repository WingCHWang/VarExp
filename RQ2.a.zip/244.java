public class A {
public void setDate(String dateString) {

// the iso the iso date format the date format
        this.date = LocalDate.parse(dateString, DateTimeFormatter.BASIC_ISO_DATE);
    }

}