public class A {
private void initTable()
	{
		// The table data model
		KeyStoreTableModel ksModel = new KeyStoreTableModel(this);

		// The table itself
		m_jtKeyStore = new KeyStoreTable(ksModel);

		m_jtKeyStore.setShowGrid(false);
		m_jtKeyStore.setRowMargin(0);
		m_jtKeyStore.getColumnModel().setColumnMargin(0);
		m_jtKeyStore.getTableHeader().setReorderingAllowed(false);
		m_jtKeyStore.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		// Top accommodate entry icons with spare space (16 pixels tall)
		m_jtKeyStore.setRowHeight(18);

		// Add custom renderers for the table headers and cells
		for (int iCnt = 0; iCnt < m_jtKeyStore.getColumnCount(); iCnt++)
		{
			TableColumn column = m_jtKeyStore.getColumnModel().getColumn(iCnt);
			column.setHeaderRenderer(new KeyStoreTableHeadRend());
			column.setCellRenderer(new KeyStoreTableCellRend());
		}

		// Make the first column small and not resizable (it holds icons to represent the different entry
		// types)
		TableColumn typeCol = m_jtKeyStore.getColumnModel().getColumn(0);
		typeCol.setResizable(false);
		typeCol.setMinWidth(20);
		typeCol.setMaxWidth(20);
		typeCol.setPreferredWidth(20);

		// Set alias columns width according to the relevant application property unless the property is not
		// present or is invalid.
		int iAliasWidth = PREFS.getInt(RB.getString("AppPrefs.AliasWidth"), 0);


// the table column the table column to be added to the table the column
		TableColumn aliasCol = m_jtKeyStore.getColumnModel().getColumn(1);
		aliasCol.setMinWidth(20);
		aliasCol.setMaxWidth(10000);

		if (iAliasWidth <= 0)
		{
			aliasCol.setPreferredWidth(350);
		}
		else
		{
			aliasCol.setPreferredWidth(iAliasWidth);
		}

		// Make the table sortable
		m_jtKeyStore.setAutoCreateRowSorter(true);
		// ...and sort it by alias by default
		m_jtKeyStore.getRowSorter().toggleSortOrder(1);

		// Get usual double click edit start out of the way - we want double click to show the
		// entry, even in editable columns. In-place edit can be invoked with F2.
		TableCellEditor cellEditor = m_jtKeyStore.getDefaultEditor(String.class);
		if (cellEditor instanceof DefaultCellEditor)
		{
			((DefaultCellEditor) cellEditor).setClickCountToStart(1000);
		}

		// Put the table into a scroll pane
		JScrollPane jspKeyStoreTable = new JScrollPane(m_jtKeyStore, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
		    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jspKeyStoreTable.getViewport().setBackground(m_jtKeyStore.getBackground());

		// Get the size of the keystore table panel from the application preferences
		int iWidth = PREFS.getInt(RB.getString("AppPrefs.TableWidth"), 0);
		int iHeight = PREFS.getInt(RB.getString("AppPrefs.TableHeight"), 0);

		// Put the scroll pane into a panel. The preferred size of the panel dictates the size of the entire
		// frame
		m_jpKeyStoreTable = new JPanel(new BorderLayout(10, 10));

		if (iWidth <= 0 || iHeight <= 0)
		{
			m_jpKeyStoreTable.setPreferredSize(new Dimension(DEFAULT_TABLE_WIDTH, DEFAULT_TABLE_HEIGHT));
		}
		else
		{
			m_jpKeyStoreTable.setPreferredSize(new Dimension(iWidth, iHeight));
		}

		m_jpKeyStoreTable.add(jspKeyStoreTable, BorderLayout.CENTER);
		m_jpKeyStoreTable.setBorder(new EmptyBorder(3, 3, 3, 3));

		// Add mouse listeners to show pop-up menus when table entries are clicked upon; maybeShowPopup for
		// both mousePressed and mouseReleased for cross-platform compatibility. Also add listeners to show an
		// entry's certificate details if it is double-clicked
		m_jtKeyStore.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseClicked(MouseEvent evt)
			{
				keyStoreTableDoubleClick(evt);
			}

			@Override
			public void mousePressed(MouseEvent evt)
			{
				maybeShowPopup(evt);
			}

			@Override
			public void mouseReleased(MouseEvent evt)
			{
				maybeShowPopup(evt);
			}
		});
		m_jpKeyStoreTable.setTransferHandler(m_jtKeyStore.getTransferHandler());
		getContentPane().add(m_jpKeyStoreTable, BorderLayout.CENTER);
	}

}