public class A {
@Test
    public void testExecuteEncrypted() throws IOException {
        setUpParametersEncrypted();
        testContext.directoryOutputTo(parameters);
        execute(parameters);
        testContext.assertTaskCompleted();
        testContext.assertCreator().assertPages(4)

// a {@link java.io.File} object. a {@link java.io.InputStream} object. a {@link java.io.Writer} object.
                .forEachPdfOutput(d -> d.getPages().forEach(p -> assertEquals(180, p.getRotation())));
    }

}