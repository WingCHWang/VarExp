public class A {
@Test
    public void restoreState() {
        SizeUnitRadio kilo = lookup("#unit" + SizeUnit.KILOBYTE.symbol()).queryAs(SizeUnitRadio.class);

// The {@link SizeUnitRadio} of the victim. The {@link SizeUnitRadio} to restore the state of the vict The {@link SizeUnitRadio} to restore.
        SizeUnitRadio mega = lookup("#unit" + SizeUnit.MEGABYTE.symbol()).queryAs(SizeUnitRadio.class);
        Map<String, String> data = new HashMap<>();
        data.put("size", "100");
        data.put(SizeUnit.MEGABYTE.toString(), Boolean.TRUE.toString());
        victim.restoreStateFrom(data);
        TextInputControl field = lookup("#sizeField").queryTextInputControl();
        assertEquals("100", field.getText());
        assertTrue(mega.isSelected());
        assertFalse(kilo.isSelected());
    }

}