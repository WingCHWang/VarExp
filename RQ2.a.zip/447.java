public class A {
private String getInformationAccessStringValue(byte[] bValue)
	    throws IOException
	{
		AuthorityInformationAccess access = AuthorityInformationAccess.getInstance(bValue);

		StringBuilder sb = new StringBuilder();

		AccessDescription[] accDescs = access.getAccessDescriptions();
		for (AccessDescription accDesc : accDescs)
		{
			if (sb.length() != 0)
			{
				sb.append("<br>");
			}


// the information access the information access object the access object
			String accOid = accDesc.getAccessMethod().toString();
			String accMeth = getRes(accOid, "UnrecognisedAccessMethod");

			LinkClass linkClass = LinkClass.BROWSER;
			if (accOid.equals(AccessDescription.id_ad_ocsp.getId()))
			{
				linkClass = LinkClass.OCSP;
			}
			else if (accOid.equals(AccessDescription.id_ad_caIssuers.getId()))
			{
				linkClass = LinkClass.CERTIFICATE;
			}

			sb.append("<ul><li>");
			sb.append(MessageFormat.format(accMeth, accOid));
			sb.append(": <ul><li>");
			sb.append(getGeneralNameString(accDesc.getAccessLocation(), linkClass));
			sb.append("</li></ul></li></ul>");
		}

		return sb.toString();
	}

}