public class A {
@Test
    public void testGetAllSubconfigs() {

        ConfigObjectMetadata o1 = ConfigObjectMetadata.builder().build();
        ConfigObjectMetadata o2 = ConfigObjectMetadata.builder().build();

// a ConfigObjectMetadata . a ConfigObjectMetadata.
        ConfigObjectMetadata o3 = ConfigObjectMetadata.builder().build();

        ConfigObjectMetadata o4 = ConfigObjectMetadata.builder().addSubConfig(o1).build();
        ConfigObjectMetadata o5 = ConfigObjectMetadata.builder().addSubConfig(o2).addSubConfig(o3).build();

        ConfigObjectMetadata o6 = ConfigObjectMetadata.builder().addSubConfig(o4).addSubConfig(o5).build();

        List<ConfigMetadataNode> all6 = o6.getAllSubConfigs().collect(toList());
        assertEquals(6, all6.size());
        assertTrue(all6.contains(o1));
        assertTrue(all6.contains(o2));
        assertTrue(all6.contains(o3));
        assertTrue(all6.contains(o4));
        assertTrue(all6.contains(o5));
        assertTrue(all6.contains(o6));

        List<ConfigMetadataNode> all4 = o4.getAllSubConfigs().collect(toList());
        assertEquals(2, all4.size());
        assertTrue(all4.contains(o1));
        assertTrue(all4.contains(o4));

        List<ConfigMetadataNode> all1 = o1.getAllSubConfigs().collect(toList());
        assertEquals(1, all1.size());
        assertTrue(all1.contains(o1));
    }

}