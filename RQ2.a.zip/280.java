public class A {
public void mouseClicked(MouseEvent e) {

// the mouse event the mouse event. the event
			checkForPopup(e);
		}

}