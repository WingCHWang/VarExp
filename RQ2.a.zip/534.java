public class A {
protected JButton getOkButton(boolean escPresses)
	{
		Action okAction = new AbstractAction()
		{
			@Override
			public void actionPerformed(ActionEvent evt)
			{
				okPressed();
			}
		};

		JButton jbOK = new JButton(RB.getString("PortecleJDialog.jbOk.text"));

		jbOK.addActionListener(okAction);


// the esc key. the esc key the esc button.
		if (escPresses)
		{
			jbOK.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
			    ESC_KEY);
			jbOK.getActionMap().put(ESC_KEY, okAction);
		}

		return jbOK;
	}

}