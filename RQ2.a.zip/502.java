public class A {
public static KeyStore loadEntries(PEMParser reader, PasswordFinder pwFinder)
	    throws CertificateException, CryptoException, IOException
	{
		LinkedHashSet<KeyPair> keyPairs = new LinkedHashSet<>();
		LinkedHashSet<Certificate> certs = new LinkedHashSet<>();
		KeyStore keyStore = createKeyStore(KeyStoreType.PKCS12);

		CertificateFactory cf = CertificateFactory.getInstance(X509CertUtil.X509_CERT_TYPE);
		JcaPEMKeyConverter keyConverter = new JcaPEMKeyConverter();

		Object obj;
		while ((obj = reader.readObject()) != null)
		{
			if (obj instanceof PEMEncryptedKeyPair)
			{
				PEMDecryptorProvider decryptor = new JcePEMDecryptorProviderBuilder().build(pwFinder.getPassword());
				obj = ((PEMEncryptedKeyPair) obj).decryptKeyPair(decryptor);
			}
			if (obj instanceof PEMKeyPair)
			{
				keyPairs.add(keyConverter.getKeyPair((PEMKeyPair) obj));
			}
			else if (obj instanceof X509CertificateHolder)
			{
				ByteArrayInputStream bais = new ByteArrayInputStream(((X509CertificateHolder) obj).getEncoded());
				certs.add(cf.generateCertificate(bais));
			}
		}

		// Add key pairs
		for (KeyPair keyPair : keyPairs)
		{
			Certificate keyPairCert = null;
			for (Iterator<Certificate> it = certs.iterator(); it.hasNext();)
			{
				Certificate cert = it.next();
				if (cert.getPublicKey().equals(keyPair.getPublic()))
				{
					keyPairCert = cert;
					it.remove();
					break;
				}
			}

			if (keyPairCert != null)
			{
				String alias = "keypair";
				if (keyPairCert instanceof X509Certificate)
				{
					alias = X509CertUtil.getCertificateAlias((X509Certificate) keyPairCert);
				}

				KeyStore.PrivateKeyEntry entry =
				    new KeyStore.PrivateKeyEntry(keyPair.getPrivate(), new Certificate[] { keyPairCert });

// the protection level the protection type the protection protocol
				KeyStore.PasswordProtection prot = new KeyStore.PasswordProtection(DUMMY_PASSWORD);

				try
				{
					alias = findUnusedAlias(keyStore, alias);
					keyStore.setEntry(alias, entry, prot);
				}
				catch (KeyStoreException e)
				{
					throw new CryptoException(e);
				}
			}
		}

		// Add remaining certificates as trusted certificate entries
		for (Certificate cert : certs)
		{
			String alias = "certificate";
			if (cert instanceof X509Certificate)
			{
				alias = X509CertUtil.getCertificateAlias((X509Certificate) cert);
			}

			KeyStore.TrustedCertificateEntry entry = new KeyStore.TrustedCertificateEntry(cert);
			try
			{
				keyStore.setEntry(alias, entry, null);
			}
			catch (KeyStoreException e)
			{
				throw new CryptoException(e);
			}
		}

		return keyStore;
	}

}