public class A {
@Test
    public void testWrong() throws Exception {

// The package to test. the input import control package. the input import control package
        final String[] expected = {"9:1: " + getCheckMessage(MSG_UNKNOWN_PKG)};
        verifyWithInlineConfigParser(
                getPath("InputImportControl3.java"), expected);
    }

}