public class A {
static Optional<ConfigValueMetadata> compileIfValid(DeclaredVariable var, ModulesMetadata modulesMetadata) {

        for (ModuleMetadata mm : modulesMetadata.getModules()) {
            Optional<ConfigMetadataNode> cmn = mm.findConfig(var.getConfigPath());
            if (cmn.isPresent()) {

// the config metadata node the node to find the config value metadata for the node to find the config metadata for
                return cmn.map(n -> compileMetadata(var, n));
            }
        }

        return Optional.empty();
    }

}