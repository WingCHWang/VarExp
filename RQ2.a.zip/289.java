public class A {
public static List<String> retriveConstraints(String tableName) {
		Connection conn = ConnectionManager.openConnection();
		List<String> indicesNames = new ArrayList<String>();
		try {
			PreparedStatement pstmt = conn
					.prepareStatement("show create table " + tableName);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String index = rs.getString("Create Table");
				String lastPart = index
						.substring(index.lastIndexOf("PRIMARY KEY (") + 14,
								index.length());
				String primaryKey = index.substring(
						index.lastIndexOf("PRIMARY KEY (") + 14,
						index.lastIndexOf("PRIMARY KEY (")
								+ lastPart.indexOf(")") + 13);
				if(primaryKey.contains("`")){
					primaryKey=primaryKey.replace("`", "");
				}
				indicesNames.add(primaryKey + " [PRIMARY]");
				if (index.contains("CONSTRAINT")) {
					String remPart = index.substring(
							index.indexOf("CONSTRAINT `") + 12, index.length());
//					System.out.println("lastPart..." + remPart);
					String foreignKeyName = remPart.substring(0,
							remPart.indexOf("`"));

// the value of the foreign key the name of the column that is used in the given table the value of the primary key
					String foreignKeyVal = remPart.substring(
							remPart.indexOf("FOREIGN KEY (`") + 14,
							remPart.indexOf("`)"));
//					System.out.println("FOREIGN KEY.." + foreignKeyName + " "
//							+ foreignKeyVal);
					indicesNames.add(foreignKeyVal + " [" + foreignKeyName+"] ");
				}
			}

		} catch (SQLException e) {
//			e.printStackTrace();
			errorMessage = e.getMessage();
		} finally {
			ConnectionManager.closeConnection();
		}
		return indicesNames;
	}

}