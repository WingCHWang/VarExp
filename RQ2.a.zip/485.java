public class A {
private String getCertificatePoliciesStringValue(byte[] bValue)
	    throws IOException
	{
		ASN1Sequence pSeq = (ASN1Sequence) ASN1Primitive.fromByteArray(bValue);
		StringBuilder sb = new StringBuilder();

		for (int i = 0, len = pSeq.size(); i < len; i++)
		{
			PolicyInformation pi = PolicyInformation.getInstance(pSeq.getObjectAt(i));
			String piId = pi.getPolicyIdentifier().getId();

			sb.append("<ul><li>");
			sb.append(RB.getString("PolicyIdentifier"));
			sb.append(": ");
			sb.append(MessageFormat.format(getRes(piId, "UnrecognisedPolicyIdentifier"), piId));


// the certificate policies qualifiers the policy qualifiers the certificate policies qualifiers.
			ASN1Sequence pQuals;
			if ((pQuals = pi.getPolicyQualifiers()) != null)
			{
				sb.append("<ul>");

				for (int j = 0, plen = pQuals.size(); j < plen; j++)
				{
					ASN1Sequence pqi = (ASN1Sequence) pQuals.getObjectAt(j);
					ASN1Encodable pqId = pqi.getObjectAt(0);
					String spqId = pqId.toString();

					sb.append("<li>");
					sb.append(MessageFormat.format(getRes(spqId, "UnrecognisedPolicyQualifier"), spqId));
					sb.append(": ");

					ASN1Encodable d = pqi.getObjectAt(1);
					sb.append("<ul>");
					if (pqId.equals(PolicyQualifierId.id_qt_cps))
					{
						// cPSuri
						String sUri = ((ASN1String) d).getString();

						sb.append("<li>");
						sb.append(RB.getString("CpsUri"));
						sb.append(": ");
						sb.append(getLink(sUri, escapeHtml(sUri), LinkClass.BROWSER));
						sb.append("</li>");
					}
					else if (pqId.equals(PolicyQualifierId.id_qt_unotice))
					{
						// userNotice
						ASN1Sequence un = (ASN1Sequence) d;

						for (int k = 0, dlen = un.size(); k < dlen; k++)
						{
							ASN1Encodable de = un.getObjectAt(k);

							// TODO: is it possible to use something
							// smarter than instanceof here?

							if (de instanceof ASN1String)
							{
								// explicitText
								sb.append("<li>");
								sb.append(RB.getString("ExplicitText"));
								sb.append(": ");
								sb.append(stringify(de));
								sb.append("</li>");
							}
							else if (de instanceof ASN1Sequence)
							{
								// noticeRef
								ASN1Sequence nr = (ASN1Sequence) de;
								String orgstr = stringify(nr.getObjectAt(0));
								ASN1Sequence nrs = (ASN1Sequence) nr.getObjectAt(1);
								StringBuilder nrstr = new StringBuilder();
								for (int m = 0, nlen = nrs.size(); m < nlen; m++)
								{
									nrstr.append(stringify(nrs.getObjectAt(m)));
									if (m != nlen - 1)
									{
										nrstr.append(", ");
									}
								}
								sb.append("<li>");
								sb.append(RB.getString("NoticeRef"));
								sb.append(": ");
								sb.append(RB.getString("NoticeRefOrganization"));
								sb.append(": ");
								sb.append(orgstr);
								if (nrstr.length() != 0)
								{
									sb.append(", ");
									sb.append(RB.getString("NoticeRefNumber"));
									sb.append(": ");
									sb.append(nrstr);
								}
								sb.append("</li>");
							}
							// else TODO
						}
					}
					else
					{
						sb.append(stringify(d));
					}
					sb.append("</ul></li>");
				}
				sb.append("</ul></li>");
			}

			sb.append("</ul>");
			if (i != len - 1)
			{
				sb.append("<br>");
			}
		}

		return sb.toString();
	}

}