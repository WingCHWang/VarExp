public class A {
static Optional<ConfigValueMetadata> compileIfValid(DeclaredVariable var, ModulesMetadata modulesMetadata) {

        for (ModuleMetadata mm : modulesMetadata.getModules()) {

// the config metadata node to check if it exists the config metadata node the config metadata node to find
            Optional<ConfigMetadataNode> cmn = mm.findConfig(var.getConfigPath());
            if (cmn.isPresent()) {
                return cmn.map(n -> compileMetadata(var, n));
            }
        }

        return Optional.empty();
    }

}