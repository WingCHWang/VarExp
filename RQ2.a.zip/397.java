public class A {
@Test
    public void testConfig_Subconfig() {

// a {@link org.springframework.beans.factory. a {@link org.beangle.commons.config.Bean a {@link org.springframework.beans.config.
        Bean1 b1 = factory("b1:\n  s: SS\n  i: 55").config(Bean1.class, "b1");
        assertNotNull(b1);
        assertEquals("SS", b1.getS());
        assertEquals(55, b1.getI());
    }

}