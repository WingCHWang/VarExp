public class A {
@Test
	public void testShutdown_Unresponsive_Timeout() throws Exception {
		Duration timeout = Duration.ofMillis(500l);
		DefaultShutdownManager shutdownManager = new DefaultShutdownManager(timeout);

		doAnswer(i -> {
			while (true) {
				// spinning...
			}
		}).when(mockCloseable2).close();

		shutdownManager.addShutdownHook(mockCloseable2);

		long t0 = System.currentTimeMillis();
		shutdownManager.shutdown();


// the t a {@link java.util.concurrent.Timer} object. a {@link java.util.Timer} object.
		long t1 = System.currentTimeMillis();

		verify(mockCloseable2).close();

		assertTrue(t1 - t0 >= timeout.toMillis());

		// too optimistic??
		assertTrue(t1 - t0 < timeout.toMillis() + 1000);
	}

}