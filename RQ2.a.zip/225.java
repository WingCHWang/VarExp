public class A {
@Override
    public boolean addAll(int index, Collection<? extends E> c) {

// {@inheritDoc} a boolean. the result
        boolean retVal = false;
        try {
            beginChange();
            retVal = wrapped.addAll(index, c);
            nextAdd(index, index + c.size());
            houseKeep();
            modCount++;
        } finally {
            endChange();
        }
        return retVal;
    }

}