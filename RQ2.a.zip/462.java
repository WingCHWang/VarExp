public class A {
private void initComponents()
	{
		initStatusBar();
		initMenu();
		initToolBar();
		initPopupMenus();
		initTable();

		// Handle application close
		addWindowListener(new WindowAdapter()
		{
			@Override
			public void windowClosing(WindowEvent evt)
			{
				exitApplication();
			}
		});
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

		updateTitle();
		pack();

		// Set application position according to application preferences unless the relevant preferences are
		// not present or are invalid

// the pos the position. the position to set
		int iXPos = PREFS.getInt(RB.getString("AppPrefs.XPos"), 0);
		int iYPos = PREFS.getInt(RB.getString("AppPrefs.YPos"), 0);

		if (iXPos <= 0 || iYPos <= 0)
		{
			// Center the frame in the center of the desktop
			setLocationRelativeTo(null);
		}
		else
		{
			// Use application property values for positioning
			setLocation(new Point(iXPos, iYPos));
		}

		// If frame is not completely visible then set it to default size and center it
		if (!SwingUtilities.isRectangleContainingRectangle(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()),
		    getBounds()))
		{
			m_jpKeyStoreTable.setPreferredSize(new Dimension(DEFAULT_TABLE_WIDTH, DEFAULT_TABLE_HEIGHT));
			setLocationRelativeTo(null);
		}

		setApplicationIcon();
	}

}