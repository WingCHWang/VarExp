public class A {
@Override
	public String getColumnName(int iCol)
	{

// The column. The column to get the name from. The column to get the name.
		return COLUMN_NAMES[iCol];
	}

}