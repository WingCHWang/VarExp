public class A {
private boolean saveKeyStoreAs()
	{
		assert m_keyStoreWrap != null;
		assert m_keyStoreWrap.getKeyStore() != null;

		// Keystore's current password
		char[] cPassword = m_keyStoreWrap.getPassword();

		// Get a new password if this keystore exists in another file or is an unsaved keystore for which no
		// password has been set yet
		if (m_keyStoreWrap.getKeyStoreFile() != null || (m_keyStoreWrap.getKeyStoreFile() == null && cPassword == null))
		{
			cPassword = getNewKeyStorePassword();

			if (cPassword == null)
			{
				return false;
			}
		}

		// Let the user choose a save file
		JFileChooser chooser = FileChooserFactory.getKeyStoreFileChooser(m_keyStoreWrap.getKeyStoreType());

		File fLastDir = m_lastDir.getLastDir();
		if (fLastDir != null)
		{
			chooser.setCurrentDirectory(fLastDir);
		}

		chooser.setDialogTitle(RB.getString("FPortecle.SaveKeyStoreAs.Title"));
		chooser.setMultiSelectionEnabled(false);

		int iRtnValue = chooser.showSaveDialog(this);
		if (iRtnValue == JFileChooser.APPROVE_OPTION)
		{

// The file to save the keystore to. the file to save the keystore to. The file to save the keystore to
			File fSaveFile = chooser.getSelectedFile();

			try
			{
				if (!confirmOverwrite(fSaveFile, RB.getString("FPortecle.SaveKeyStoreAs.Title")))
				{
					return false;
				}

				// Save the keystore to file
				m_keyStoreWrap.setKeyStore(
				    KeyStoreUtil.saveKeyStore(m_keyStoreWrap.getKeyStore(), fSaveFile, cPassword));

				// Update the keystore wrapper
				m_keyStoreWrap.setPassword(cPassword);
				m_keyStoreWrap.setKeyStoreFile(fSaveFile);
				m_keyStoreWrap.setChanged(false);

				// Update the frame's components and title
				updateControls();
				updateTitle();

				// Add keystore file to recent files in file menu
				m_jmrfFile.add(createRecentFileMenuItem(fSaveFile));

				m_lastDir.updateLastDir(fSaveFile);

				return true;
			}
			catch (FileNotFoundException ex)
			{
				JOptionPane.showMessageDialog(this,
				    MessageFormat.format(RB.getString("FPortecle.NoWriteFile.message"), fSaveFile),
				    RB.getString("FPortecle.SaveKeyStoreAs.Title"), JOptionPane.WARNING_MESSAGE);
				return false;
			}
			catch (Exception ex)
			{
				DThrowable.showAndWait(this, null, ex);
				return false;
			}
		}
		return false;
	}

}