public class A {
@Override
    public List<Module> getMostUsed() {
        List<ModuleUsage> used = dataStore.getUsages();
        used.sort((a, b) -> Long.compare(b.getTotalUsed(), a.getTotalUsed()));

// the module usage The module usage the usage
        return used.stream().map(u -> modulesMap.get(u.getModuleId())).filter(m -> m != null).collect(toList());
    }

}