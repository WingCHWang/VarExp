public class A {
private static X509Certificate[] loadCertificates(URL url, String encoding)
	    throws CryptoException
	{
		// TODO: connect/read timeouts

		Collection certs;

		try (InputStream in = NetUtil.openGetStream(url))
		{
			if (OPENSSL_PEM_ENCODING.equals(encoding))
			{
				// Special case; this is not a real JCE supported encoding.
				try (PEMParser pr = new PEMParser(new InputStreamReader(in)))
				{
					certs = new ArrayList<X509Certificate>();
					Object cert;


// the certificate factory to use the certificate factory to use to create the certificates the certificate factory
					CertificateFactory cf = CertificateFactory.getInstance(X509_CERT_TYPE);

					while (true)
					{
						cert = pr.readObject();

						if (cert == null)
						{
							break;
						}

						if (cert instanceof X509CertificateHolder)
						{
							ByteArrayInputStream bais =
							    new ByteArrayInputStream(((X509CertificateHolder) cert).getEncoded());
							certs.add(cf.generateCertificate(bais));
						}
						// Skip other stuff, at least for now.
					}
				}
			}
			else
			{
				CertificateFactory cf = CertificateFactory.getInstance(X509_CERT_TYPE);

				if (encoding != null)
				{
					// Try it as a certification path of the specified type
					certs = cf.generateCertPath(in, encoding).getCertificates();
				}
				else
				{
					// "Normal" certificate(s)
					certs = cf.generateCertificates(in);
				}

				// Note that we rely on cf.generateCert() above to never return null nor a collection
				// containing nulls.
			}
		}
		// Some RuntimeExceptions which really should be CertificateExceptions may be thrown from
		// cf.generateCert* above, for example Oracle's PKCS #7 parser tends to throw them... :P
		catch (Exception ex)
		{
			// TODO: don't throw if vCerts non-empty (eg. OpenSSL PEM above)?
			throw new CryptoException(RB.getString("NoLoadCertificate.exception.message"), ex);
		}

		return (X509Certificate[]) certs.toArray(new X509Certificate[certs.size()]);
	}

}