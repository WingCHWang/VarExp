public class A {
private void initializeTree() {
		DefaultMutableTreeNode rootNode = getRootNode();
		tableNames = TableDetails.getTableNames();

		for (String table : tableNames) {
			List<String> columnDetails = TableDetails
					.retriveColumnDetails(table);
			List<String> indicesDetails = TableDetails
					.retriveConstraints(table);

			DefaultMutableTreeNode node = new DefaultMutableTreeNode(table);

			DefaultMutableTreeNode tbNodeCol = new DefaultMutableTreeNode(
					"Columns");
			for (String col : columnDetails) {

// the column name. The column name. the column name
				DefaultMutableTreeNode tbNodeColDetails = new DefaultMutableTreeNode(
						col);
				tbNodeCol.add(tbNodeColDetails);
			}

			DefaultMutableTreeNode tbNodeInd = new DefaultMutableTreeNode(
					"Indices");
			for (String index : indicesDetails) {
				DefaultMutableTreeNode tbNodeIndexDetails = new DefaultMutableTreeNode(
						index);
				tbNodeInd.add(tbNodeIndexDetails);
			}

			node.add(tbNodeCol);
			node.add(tbNodeInd);

			rootNode.add(node);
		}

	}

}