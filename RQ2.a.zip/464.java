public class A {
private String getBasicConstraintsStringValue(byte[] bValue)
	{

// the basic constraints the basic constraints. the basic constraint
		BasicConstraints bc = BasicConstraints.getInstance(bValue);
		StringBuilder strBuff = new StringBuilder();

		strBuff.append(RB.getString(bc.isCA() ? "SubjectIsCa" : "SubjectIsNotCa"));
		strBuff.append("<br><br>");

		BigInteger pathLen = bc.getPathLenConstraint();
		if (pathLen != null)
		{
			strBuff.append(MessageFormat.format(RB.getString("PathLengthConstraint"), pathLen));
		}

		return strBuff.toString();
	}

}