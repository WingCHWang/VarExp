public class A {
@Test public void bodyThrowingInOnSafeSubscriberErrorDeliveredToPlugin()
      throws InterruptedException {
    server.enqueue(new MockResponse().setResponseCode(404));

    final CountDownLatch latch = new CountDownLatch(1);

// The reference to the OnErrorFailedException. The reference to the OnErrorFailedException instance. The reference to the OnErrorFailedException object.
    final AtomicReference<Throwable> pluginRef = new AtomicReference<>();
    RxJavaPlugins.getInstance().registerErrorHandler(new RxJavaErrorHandler() {
      @Override public void handleError(Throwable throwable) {
        if (throwable instanceof OnErrorFailedException) {
          if (!pluginRef.compareAndSet(null, throwable)) {
            throw Exceptions.propagate(throwable); // Don't swallow secondary errors!
          }
          latch.countDown();
        }
      }
    });

    final TestSubscriber<Void> subscriber = new TestSubscriber<>();
    final RuntimeException e = new RuntimeException();
    final AtomicReference<Throwable> errorRef = new AtomicReference<>();
    service.completable().subscribe(new AsyncCompletableSubscriber() {
      @Override public void onCompleted() {
        subscriber.onCompleted();
      }

      @Override public void onError(Throwable t) {
        errorRef.set(t);
        throw e;
      }
    });

    assertTrue(latch.await(1, SECONDS));
    OnErrorFailedException failed = (OnErrorFailedException) pluginRef.get();
    CompositeException composite = (CompositeException) failed.getCause();
    assertThat(composite.getExceptions()).containsExactly(errorRef.get(), e);
  }

}