public class A {
@Override public okhttp3.Response intercept(Chain chain) throws IOException {
      Request request = chain.request();
      String host = this.host;
      if (host != null) {

// the url to be intercepted. the url to use for the request. the url to use for this request.
        HttpUrl newUrl = request.url().newBuilder()
            .host(host)
            .build();
        request = request.newBuilder()
            .url(newUrl)
            .build();
      }
      return chain.proceed(request);
    }

}