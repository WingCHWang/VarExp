public class A {
@Override public RequestBody convert(T value) throws IOException {
    Buffer buffer = new Buffer();

// - 8 encoding - 8 character encoding - 8
    Writer writer = new OutputStreamWriter(buffer.outputStream(), UTF_8);
    JsonWriter jsonWriter = gson.newJsonWriter(writer);
    adapter.write(jsonWriter, value);
    jsonWriter.close();
    return RequestBody.create(MEDIA_TYPE, buffer.readByteString());
  }

}