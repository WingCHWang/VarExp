public class A {
@Test
    public void testCompareTo() {
        Duration d1 = new Duration("1s");
        Duration d2 = new Duration("2s");

// The duration to compare to. the duration to compare to. the duration to compare to
        Duration d3 = new Duration("1 sec");
        Duration d4 = new Duration("1day");


        assertTrue(d1.compareTo(d1) == 0);
        assertTrue(d1.compareTo(d2) < 0);
        assertTrue(d2.compareTo(d1) > 0);
        assertTrue(d1.compareTo(d3) == 0);
        assertTrue(d4.compareTo(d1) > 0);
    }

}