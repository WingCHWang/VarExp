public class A {
@Override
	public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
	    throws BadLocationException
	{
		int textLen;
		if (text == null || (textLen = text.length()) == 0)
		{
			// Always allow removal
			super.replace(fb, offset, length, text, attrs);
			return;
		}


// The number of characters to be replaced. The number of characters to replace. The number of characters to be added.
		int numAdded = textLen - length;
		if (fb.getDocument().getLength() + numAdded > maxLength)
		{
			Toolkit.getDefaultToolkit().beep();
			return;
		}

		super.replace(fb, offset, length, text, attrs);
	}

}