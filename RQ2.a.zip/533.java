public class A {
public String getStringValue()
	    throws IOException, ParseException
	{
		// Get octet string from extension

// the b value of the extension. the byte array containing the extension value. the byte array of the extension value.
		byte[] bOctets = ((ASN1OctetString) ASN1Primitive.fromByteArray(m_bValue)).getOctets();

		// Octet string processed differently depending on extension type
		if (m_Oid.equals(X509ObjectIdentifiers.commonName))
		{
			return getCommonNameStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.subjectKeyIdentifier))
		{
			return getSubjectKeyIdentifierStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.keyUsage))
		{
			return getKeyUsageStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.privateKeyUsagePeriod))
		{
			return getPrivateKeyUsagePeriod(bOctets);
		}
		else if (m_Oid.equals(Extension.issuerAlternativeName) || m_Oid.equals(Extension.subjectAlternativeName))
		{
			return getAlternativeName(bOctets);
		}
		else if (m_Oid.equals(Extension.basicConstraints))
		{
			return getBasicConstraintsStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.cRLNumber))
		{
			return getCrlNumberStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.reasonCode))
		{
			return getReasonCodeStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.instructionCode))
		{
			return getHoldInstructionCodeStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.invalidityDate))
		{
			return getInvalidityDateStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.deltaCRLIndicator))
		{
			return getDeltaCrlIndicatorStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.certificateIssuer))
		{
			return getCertificateIssuerStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.policyMappings))
		{
			return getPolicyMappingsStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.authorityKeyIdentifier))
		{
			return getAuthorityKeyIdentifierStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.policyConstraints))
		{
			return getPolicyConstraintsStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.extendedKeyUsage))
		{
			return getExtendedKeyUsageStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.inhibitAnyPolicy))
		{
			return getInhibitAnyPolicyStringValue(bOctets);
		}
		else if (m_Oid.equals(MiscObjectIdentifiers.entrustVersionExtension))
		{
			return getEntrustVersionExtensionStringValue(bOctets);
		}
		else if (m_Oid.equals(PKCSObjectIdentifiers.pkcs_9_at_smimeCapabilities))
		{
			return getSmimeCapabilitiesStringValue(bOctets);
		}
		else if (m_Oid.equals(MicrosoftObjectIdentifiers.microsoftCaVersion))
		{
			return getMicrosoftCAVersionStringValue(bOctets);
		}
		else if (m_Oid.equals(MicrosoftObjectIdentifiers.microsoftPrevCaCertHash))
		{
			return getMicrosoftPreviousCACertificateHashStringValue(bOctets);
		}
		else if (m_Oid.equals(MicrosoftObjectIdentifiers.microsoftCertTemplateV2))
		{
			return getMicrosoftCertificateTemplateV2StringValue(bOctets);
		}
		else if (m_Oid.equals(MicrosoftObjectIdentifiers.microsoftAppPolicies))
		{
			return getUnknownOidStringValue(bOctets); // TODO
		}
		else if (m_Oid.equals(MicrosoftObjectIdentifiers.microsoftCrlNextPublish))
		{
			return getMicrosoftCrlNextPublish(bOctets);
		}
		else if (m_Oid.equals(Extension.authorityInfoAccess) || m_Oid.equals(Extension.subjectInfoAccess))
		{
			return getInformationAccessStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.logoType))
		{
			return getLogotypeStringValue(bOctets);
		}
		else if (m_Oid.equals(MiscObjectIdentifiers.novellSecurityAttribs))
		{
			return getNovellSecurityAttributesStringValue(bOctets);
		}
		else if (m_Oid.equals(MiscObjectIdentifiers.netscapeCertType))
		{
			return getNetscapeCertificateTypeStringValue(bOctets);
		}
		else if (m_Oid.equals(MiscObjectIdentifiers.netscapeSSLServerName) ||
		    m_Oid.equals(MiscObjectIdentifiers.netscapeCertComment) ||
		    m_Oid.equals(MiscObjectIdentifiers.verisignDnbDunsNumber) ||
		    m_Oid.equals(MicrosoftObjectIdentifiers.microsoftCertTemplateV1))
		{
			return getASN1ObjectString(bOctets);
		}
		else if (m_Oid.equals(MiscObjectIdentifiers.netscapeCApolicyURL))
		{
			return getNetscapeExtensionURLValue(bOctets, LinkClass.BROWSER);
		}
		else if (m_Oid.equals(MiscObjectIdentifiers.netscapeBaseURL) ||
		    m_Oid.equals(MiscObjectIdentifiers.netscapeRenewalURL) ||
		    m_Oid.equals(MiscObjectIdentifiers.netscapeRevocationURL) ||
		    m_Oid.equals(MiscObjectIdentifiers.netscapeCARevocationURL))
		{
			return getNetscapeExtensionURLValue(bOctets, LinkClass.CRL);
		}
		else if (m_Oid.equals(Extension.cRLDistributionPoints))
		{
			return getCrlDistributionPointsStringValue(bOctets);
		}
		else if (m_Oid.equals(Extension.certificatePolicies))
		{
			return getCertificatePoliciesStringValue(bOctets);
		}

		// TODO:
		// - CERTIFICATE_POLICIES_OLD_OID
		// - AUTHORITY_KEY_IDENTIFIER_OLD_OID
		// - BASIC_CONSTRAINTS_OLD_0_OID

		// Don't know how to process the extension
		// and clear text
		else
		{
			return getUnknownOidStringValue(bOctets);
		}
	}

}