public class A {
@Override
    public boolean addAll(int index, Collection<? extends E> c) {

// a {@link java.util.Collection} object. a {@link java.util.Collection} object a {@link Collection} of {@link E}.
        boolean retVal = false;
        try {
            beginChange();
            retVal = wrapped.addAll(index, c);
            nextAdd(index, index + c.size());
            houseKeep();
            modCount++;
        } finally {
            endChange();
        }
        return retVal;
    }

}