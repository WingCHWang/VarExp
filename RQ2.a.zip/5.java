public class A {
public void setVal(int val) {

// the new value of the field the value of the field. the value of the field
            this.val = val;
        }

}