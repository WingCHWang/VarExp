public class A {
private static String appNameFromJar(Class<?> mainClass) {

        URL url;
        try {
            url = mainClass.getProtectionDomain().getCodeSource().getLocation();
        } catch (Exception e) {
            return null;
        }


// the url of the jar file the URL of the jar file the jar file
        String urlString = url.toExternalForm();

        // e.g. the app is started from an unpacked .jar
        if (!urlString.endsWith(".jar")) {
            return null;
        }

        int slash = urlString.lastIndexOf('/');
        return slash < 0 && slash >= urlString.length() - 1 ? urlString : urlString.substring(slash + 1);
    }

}