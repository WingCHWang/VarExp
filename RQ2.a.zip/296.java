public class A {
public static void setForeignKeyRefDesc(String foreignKeyRefDesc) {

// the description of the foreign key reference the description the description of the foreign key
		ConstraintDailog.foreignKeyRefDesc = foreignKeyRefDesc;
	}

}