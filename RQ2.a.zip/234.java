public class A {
@Test
    public void select() {

// a {@link DashboardButton} a {@link DashboardButton} object. The dashboard button to select.
        victim.getChildren().stream().filter(n -> n instanceof DashboardButton).map(n -> (DashboardButton) n)
                .noneMatch(DashboardButton::isSelected);
        victim.setCurrentDashboardItem(new SetActiveDashboardItemRequest("id1"));
        long selected = victim.getChildren().stream().filter(n -> n instanceof DashboardButton)
                .map(n -> (DashboardButton) n).filter(DashboardButton::isSelected).count();
        assertEquals(1, selected);
    }

}