public class A {
private JMenuItem getMenuItem(String s, ActionListener al) {

// the text to display the text the text to display.
		JMenuItem menuItem = new JMenuItem(s);
		menuItem.addActionListener(al);
		return menuItem;
	}

}