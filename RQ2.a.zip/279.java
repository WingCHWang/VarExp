public class A {
public void paint(Graphics g) {
		List<Model> models = diagram.getModels();

		for (Model model : models) {

// the location to paint to. the starting and release point. the location to paint to
			Point definingLoc1 = model.getStartingPoint();
			Point definingLoc2 = model.getReleasePoint();
			model.paint(definingLoc1, definingLoc2);
		}
	}

}