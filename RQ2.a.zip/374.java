public class A {
@Test
    public void testList_SingleLevel() {


// list of single level List of single level - List of single level
        List<Object> l = factory("- SS\n- 55").config(new TypeRef<List<Object>>() {
        }, "");

        assertNotNull(l);
        assertEquals("SS", l.get(0));
        assertEquals(55, l.get(1));
    }

}