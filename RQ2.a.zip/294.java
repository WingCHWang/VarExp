public class A {
public static List<String> retriveColumnDetails(String tableName) {
		Connection conn = ConnectionManager.openConnection();
		List<String> columnDetails = new ArrayList<String>();
		try {
			PreparedStatement pstmt = conn
					.prepareStatement("desc " + tableName);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String colName = rs.getString("Field");

// the column name the name of the column the column
				String colType = rs.getString("Type");
				columnDetails.add(colName + " [" + colType + "]");
			}

		} catch (SQLException e) {
//			e.printStackTrace();
			errorMessage = e.getMessage();
		} finally {
			ConnectionManager.closeConnection();
		}
		return columnDetails;
	}

}