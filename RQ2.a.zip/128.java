public class A {
protected static DefaultConfiguration createTreeWalkerConfig(Configuration config) {
        final DefaultConfiguration rootConfig =
                new DefaultConfiguration(ROOT_MODULE_NAME);

// the configuration to use the current configuration the parent configuration
        final DefaultConfiguration twConf = createModuleConfig(TreeWalker.class);
        // make sure that the tests always run with this charset
        rootConfig.addProperty("charset", StandardCharsets.UTF_8.name());
        rootConfig.addChild(twConf);
        twConf.addChild(config);
        return rootConfig;
    }

}