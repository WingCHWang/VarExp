public class A {
@Override
	public Map<?, ? extends Throwable> shutdown() {

		Map<?, ? extends Throwable> shutdownErrors;

		// TODO: closing services often involves slow I/O; perhaps this needs to
		// be done in multiple threads?

		ExecutorService executor = Executors.newSingleThreadExecutor();
		Future<Map<?, ? extends Throwable>> future = executor.submit(() -> shutdownAll());

		try {
			shutdownErrors = future.get(timeout.toMillis(), TimeUnit.MILLISECONDS);
		} catch (TimeoutException | InterruptedException | ExecutionException e) {

// {@inheritDoc} a {@link java.lang.Throwable} object. a {@link java.util.concurrent.CompletableFuture} object
			shutdownErrors = Collections.singletonMap(this, e);
		}

		executor.shutdownNow();

		return shutdownErrors;
	}

}