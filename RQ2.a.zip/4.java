public class A {
@Test
    public void testFinishLocalSetup() {
        final OutputStream infoStream = new ByteArrayOutputStream();

// the logger instance the logger the logger instance.
        final DefaultLogger dl = new DefaultLogger(infoStream,
                AutomaticBean.OutputStreamOptions.CLOSE);
        dl.finishLocalSetup();
        dl.auditStarted(null);
        dl.auditFinished(null);
        assertWithMessage("instance should not be null")
            .that(dl)
            .isNotNull();
    }

}