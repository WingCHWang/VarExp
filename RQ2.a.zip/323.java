public class A {
protected void testNonRoot(Class<? extends T> t) {
        // while boundaries are compiler-checked, let's still verify superclass, as generics in Java are easy to bypass
        assertTrue("Invalid type " + t.getName() + ". Must be a subclass of root type " + expectedRoot.getName(),

// The type to test. The non-root type to test. The non-root type.
                expectedRoot.isAssignableFrom(t));

        assertTrue("Non-root configuration type must not be abstract: " + t.getName(), isConcrete(t));

        // this check would prevent matching subclasses by class, but we discourage that anyways.. (otherwise FQN
        // would have to be used in YAML)

        JsonTypeName typeName = t.getAnnotation(JsonTypeName.class);
        assertNotNull("Non-root configuration type must be annotated with @JsonTypeName: " + t.getName(), typeName);
    }

}