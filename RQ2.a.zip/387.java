public class A {
public DefaultEnvironment build() {

// the new {@link DefaultEnvironment} instance the new {@link DefaultEnvironment} instance. the environment to build
            DefaultEnvironment env = new DefaultEnvironment();
            env.properties = buildProperties();
            return env;
        }

}