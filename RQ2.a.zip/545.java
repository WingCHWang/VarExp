public class A {
public void testNonResolvedVersionRangeConsistentlyYieldsNullVersions()
        throws Exception
    {

// The version range to test. the version range to test. the version range to test
        VersionRange vr = VersionRange.createFromVersionSpec( "[1.0,2.0)" );
        artifact = new DefaultArtifact( groupId, artifactId, vr, scope, type, null, artifactHandler );
        assertEquals( null, artifact.getVersion() );
        assertEquals( null, artifact.getBaseVersion() );
    }

}