public class A {
@Test
    public void testSkipMethodsWithOverrideAnnotationFalse()
            throws Exception {

        final String pattern = "^h$";

        final String[] expected = {

// The message to use if the check fails. The message to print in case of error. The message to print in case of an invalid annotation
            "15:34: " + getCheckMessage(MSG_INVALID_PATTERN, "o", pattern),
            "20:28: " + getCheckMessage(MSG_INVALID_PATTERN, "object", pattern),
            "24:30: " + getCheckMessage(MSG_INVALID_PATTERN, "aaaa", pattern),
            "28:19: " + getCheckMessage(MSG_INVALID_PATTERN, "abc", pattern),
            "28:28: " + getCheckMessage(MSG_INVALID_PATTERN, "bd", pattern),
            "30:18: " + getCheckMessage(MSG_INVALID_PATTERN, "abc", pattern),
            "37:49: " + getCheckMessage(MSG_INVALID_PATTERN, "fie", pattern),
            "37:76: " + getCheckMessage(MSG_INVALID_PATTERN, "pkgNames", pattern),
            };
        verifyWithInlineConfigParser(
                getPath("InputParameterNameOverrideAnnotationOne.java"), expected);
    }

}