public class A {
private JarFile[] getClassPathJars()
	    throws IOException
	{
		// Store JARs
		ArrayList<JarFile> vJars = new ArrayList<>();

		// Split class path into it's components using the path separator
		String sClassPath = System.getProperty("java.class.path");
		String sPathSeparator = System.getProperty("path.separator");


// The token list. The token string. The class path token.
		StringTokenizer strTok = new StringTokenizer(sClassPath, sPathSeparator);

		// Store each JAR found on class path
		while (strTok.hasMoreTokens())
		{
			String sClassPathEntry = strTok.nextToken();

			File file = new File(sClassPathEntry);

			if (isJarFile(file))
			{
				vJars.add(new JarFile(file));
			}
		}

		/*
		 * If only one JAR was found assume that application was started using "jar" option - look in JAR manifest's
		 * Class-Path entry for the rest of the JARs
		 */
		if (vJars.size() == 1)
		{
			// Get manifest
			JarFile jarFile = vJars.get(0);
			Manifest manifest = jarFile.getManifest();

			if (manifest != null) // Manifest may not exist
			{
				// Get Class-Path entry
				Attributes attributes = manifest.getMainAttributes();
				String sJarClassPath = attributes.getValue("Class-Path");

				if (sJarClassPath != null)
				{
					// Split "JAR class path" using spaces
					strTok = new StringTokenizer(sJarClassPath, " ");

					// Store each JAR found on "JAR class path"
					while (strTok.hasMoreTokens())
					{
						String sJarClassPathEntry = strTok.nextToken();

						File file = new File(new File(jarFile.getName()).getParent(), sJarClassPathEntry);

						if (isJarFile(file))
						{
							vJars.add(new JarFile(file));
						}
					}
				}
			}
		}

		// Return JARs in an array
		return vJars.toArray(new JarFile[vJars.size()]);
	}

}