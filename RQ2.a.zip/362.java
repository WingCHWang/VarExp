public class A {
@Test
    public void testDefault() {
        ModulesMetadata md = runtimeFactory.app().createRuntime().getInstance(ModulesMetadata.class);

        assertEquals("Expected BQCoreModule + 2 test modules", 3, md.getModules().size());


// the metadata of the default module the metadata of the default module. the module metadata
        Optional<ModuleMetadata> coreMd = md.getModules()
                .stream()
                .filter(m -> "BQCoreModule".equals(m.getName()))
                .findFirst();
        assertTrue(coreMd.isPresent());
        assertEquals("The core of Bootique runtime.", coreMd.get().getDescription());
    }

}