public class A {
private String getNetscapeExtensionURLValue(byte[] bValue, LinkClass linkClass)
	    throws IOException
	{

// the url the url of the extension the URL
		String sUrl = ASN1Primitive.fromByteArray(bValue).toString();
		return getLink(sUrl, escapeHtml(sUrl), linkClass).toString();
	}

}