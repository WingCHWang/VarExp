public class A {
@S2
        @Provides
        @Singleton
        String getS2(@S1 String s1) {

// the name of the sub-module the name of the sub-module. the sub-module name
            return "sub_sub_m2_s2_" + s1;
        }

}