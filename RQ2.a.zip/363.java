public class A {
@Test
    public void testEquals() {
        Duration d1 = new Duration("1s");
        Duration d2 = new Duration("2s");
        Duration d3 = new Duration("1 sec");

// The duration to compare. the duration to compare. the duration to compare
        Duration d4 = new Duration("1000ms");

        assertTrue(d1.equals(d1));
        assertFalse(d1.equals(null));
        assertFalse(d1.equals(d2));
        assertTrue(d1.equals(d3));
        assertTrue(d1.equals(d4));
        assertTrue(d4.equals(d1));
    }

}