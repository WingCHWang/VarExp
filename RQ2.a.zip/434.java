public class A {
@Override
	public boolean accept(File file)
	{
		if (file.isDirectory())
		{
			return true;
		}


// The extension to check. The file extension to check. The file extension.
		String sFileExt = getExtension(file);

		if (sFileExt == null)
		{
			return false;
		}

		for (String sExt : m_sExts)
		{
			if (sFileExt.equalsIgnoreCase(sExt))
			{
				return true;
			}
		}
		return false;
	}

}