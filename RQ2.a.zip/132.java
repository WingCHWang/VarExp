public class A {
@Test
    public void testSetupInvalidChildFromBaseClass() {
        final TestBean testBean = new TestBean();

// the parent configuration the parent configuration. parent configuration
        final DefaultConfiguration parentConf = new DefaultConfiguration("parentConf");
        final DefaultConfiguration childConf = new DefaultConfiguration("childConf");
        TestUtil.setInternalState(testBean, "configuration", parentConf);

        try {
            testBean.setupChild(childConf);
            assertWithMessage("expecting checkstyle exception")
                    .fail();
        }
        catch (CheckstyleException ex) {
            assertWithMessage("Invalid exception message")
                    .that(ex)
                    .hasMessageThat()
                    .isEqualTo("childConf is not allowed as a "
                            + "child in parentConf. Please review 'Parent Module' section "
                            + "for this Check in web documentation if Check is standard.");
        }
    }

}