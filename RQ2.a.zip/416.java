public class A {
protected ConfigMetadataNode compileObjectMetadata(final Descriptor descriptor) {

        // see if there's already a metadata object for this type... proxy it to avoid compile cycles...
        final ConfigMetadataNode seenNode = seen.get(descriptor.getType());

        // create an empty object ourselves, as we need to cache it before we descend down the stack to prevent
        // endless cycles during compilation... note that we are only caching inside 'compileObjectMetadata'...
        // That's the place to break the cycles..
        final ConfigObjectMetadata baseObject = new ConfigObjectMetadata();
        seen.put(descriptor.getType(), baseObject);
        final ConfigObjectMetadata.Builder builder = ConfigObjectMetadata
                .builder(baseObject)
                .name(descriptor.getName())
                .type(descriptor.getType())
                .abstractType(isAbstract(descriptor.getTypeClass()))
                .typeLabel(extractTypeLabel(descriptor.getTypeClass()));

        if (seenNode == null) {
            // note that root config object known to Bootique doesn't require BQConfig annotation (though it would help in
            // determining description). Objects nested within the root config do. Otherwise they will be treated as
            // "value" properties.
            final BQConfig typeAnnotation = descriptor.getTypeClass().getAnnotation(BQConfig.class);
            if (typeAnnotation != null) {
                builder.description(typeAnnotation.value());
            }

            for (Method m : descriptor.getTypeClass().getMethods()) {
                final BQConfigProperty configProperty = m.getAnnotation(BQConfigProperty.class);
                if (configProperty != null) {
                    final Type propType = propertyTypeFromSetter(m);
                    builder.addProperty(compile(new Descriptor(propertyNameFromSetter(m), configProperty, propType)));
                }
            }

            for (Constructor<?> c : descriptor.getTypeClass().getConstructors()) {
                final BQConfigProperty configProperty = c.getAnnotation(BQConfigProperty.class);
                if (configProperty != null) {

// the constructor for the descriptor the constructor of the descriptor the constructor
                    final Type propType = propertyTypeFromConstructor(c);
                    builder.addProperty(compile(new Descriptor(descriptor.getTypeClass().getSimpleName().toLowerCase(), configProperty, propType)));
                }
            }
        }

        // compile subconfigs...
        subclassProvider.apply(descriptor.getTypeClass())
                .map(sc -> new Descriptor(null, sc))
                .map(this::compileObjectMetadata)
                .forEach(builder::addSubConfig);

        return builder.build();
    }

}