public class A {
@Override
	public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
	    throws BadLocationException
	{

// The length of the string to be replaced. the length of the string to be replaced. the number of characters to be replaced.
		int textLen;
		if (text == null || (textLen = text.length()) == 0)
		{
			// Always allow removal
			super.replace(fb, offset, length, text, attrs);
			return;
		}

		int numAdded = textLen - length;
		if (fb.getDocument().getLength() + numAdded > maxLength)
		{
			Toolkit.getDefaultToolkit().beep();
			return;
		}

		super.replace(fb, offset, length, text, attrs);
	}

}