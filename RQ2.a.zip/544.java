public class A {
public void testGetRepositorySystem()
    {
        ServiceLocator locator = MavenRepositorySystemUtils.newServiceLocator();

// the repository the repository to test the repository to test.
        RepositorySystem repoSys = locator.getService( RepositorySystem.class );
        assertNotNull( repoSys );
    }

}