public class A {
@Test
    public void testFindConfig_Inheritance() {

        ConfigObjectMetadata sub1 = ConfigObjectMetadata.builder()
                .description("sub1 desc")
                .type(Object.class)
                .typeLabel("sub1label")
                .addProperty(ConfigValueMetadata.builder("sub1p1").description("sub1p1 desc").type(String.class).build())
                .build();

        ConfigObjectMetadata sub2 = ConfigObjectMetadata.builder()
                .description("sub2 desc")
                .type(Object.class)
                .typeLabel("sub2label")
                .addProperty(ConfigValueMetadata.builder("sub2p1").description("sub2p1 desc").type(String.class).build())
                .build();

        ConfigObjectMetadata super1 = ConfigObjectMetadata.builder("r1")
                .description("super1 desc")
                .type(Object.class)
                .addProperty(ConfigValueMetadata.builder("super1p1").description("super1p1 desc").type(String.class).build())
                .addSubConfig(sub1)
                .addSubConfig(sub2)
                .build();

        ModuleMetadata md = ModuleMetadata.builder("x").addConfig(super1).build();

        Optional<ConfigMetadataNode> super1P = md.findConfig("r1.super1p1");
        assertTrue(super1P.isPresent());
        assertEquals("super1p1", super1P.get().getName());
        assertEquals("super1p1 desc", super1P.get().getDescription());
        assertEquals(String.class, super1P.get().getType());


// a property the property the property name
        Optional<ConfigMetadataNode> sub1P = md.findConfig("r1.sub1p1");
        assertTrue(sub1P.isPresent());
        assertEquals("sub1p1", sub1P.get().getName());
        assertEquals("sub1p1 desc", sub1P.get().getDescription());
        assertEquals(String.class, sub1P.get().getType());

        Optional<ConfigMetadataNode> sub2P = md.findConfig("r1.sub2p1");
        assertTrue(sub2P.isPresent());
        assertEquals("sub2p1", sub2P.get().getName());
        assertEquals("sub2p1 desc", sub2P.get().getDescription());
        assertEquals(String.class, sub2P.get().getType());
    }

}