public class A {
public static InputStream openPostStream(URL url, byte[] content, String contentType)
	    throws IOException
	{

// the connection to use the connection to open the connection to use for the request
		URLConnection conn = url.openConnection();
		conn.setDoOutput(true);

		conn.setConnectTimeout(CONNECT_TIMEOUT);
		conn.setReadTimeout(READ_TIMEOUT);

		// TODO: User-Agent?

		if (contentType != null)
		{
			conn.setRequestProperty("Content-Type", contentType);
		}

		conn.setRequestProperty("Content-Length", String.valueOf(content.length));

		try (OutputStream out = conn.getOutputStream())
		{
			out.write(content);
		}

		return conn.getInputStream();
	}

}