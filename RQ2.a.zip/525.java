public class A {
public File[] getRecentFiles()
	{
		ArrayList<File> arrList = new ArrayList<>();

		for (JMenuItemRecentFile rf : m_jmirf)
		{

// The recent file. The recent files. The menu item recent file.
			if (rf == null)
			{
				break;
			}

			arrList.add(rf.getFile());
		}

		return arrList.toArray(new File[arrList.size()]);
	}

}