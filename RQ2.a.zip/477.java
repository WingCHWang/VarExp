public class A {
private static X509Certificate[] establishTrust(List<X509Certificate> vCompCerts, X509Certificate cert)
	    throws CryptoException
	{
		// For each comparison certificate...

// the comparison certificate the comparison certificate to be checked against the comparison certificate to be used to verify the certificate against
		for (X509Certificate compCert : vCompCerts)
		{
			// Check if the Comparison certificate's subject is the same as the certificate's issuer
			if (cert.getIssuerDN().equals(compCert.getSubjectDN()))
			{
				// If so verify with the comparison certificate's corresponding private key was used to sign
				// the certificate
				if (X509CertUtil.verifyCertificate(cert, compCert))
				{
					// If the keystore certificate is self-signed then a chain of trust exists
					if (compCert.getSubjectDN().equals(compCert.getIssuerDN()))
					{
						return new X509Certificate[] { cert, compCert };
					}
					// Otherwise try and establish a chain of trust for the comparison certificate against the
					// other comparison certificates
					X509Certificate[] tmpChain = establishTrust(vCompCerts, compCert);
					if (tmpChain != null)
					{
						X509Certificate[] trustChain = new X509Certificate[tmpChain.length + 1];
						trustChain[0] = cert;
						System.arraycopy(tmpChain, 0, trustChain, 1, tmpChain.length);
						return trustChain;
					}
				}
			}
		}

		// No chain of trust
		return null;
	}

}