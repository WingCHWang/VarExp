public class A {
private static String getUserDir() {

// the dir the user directory the user.dir
        String userDir = System.getProperty("user.dir");
        if (!userDir.startsWith("/")) {
            userDir = "/" + userDir;
        }
        if (userDir.endsWith("/")) {
            userDir = userDir.substring(0, userDir.length() - 1);
        }
        return "file://" + slashify(userDir);
    }

}