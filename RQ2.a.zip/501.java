public class A {
private DefaultMutableTreeNode createProviderNodes()
	{
		// Top node
		DefaultMutableTreeNode topNode = new DefaultMutableTreeNode(RB.getString("DProviderInfo.TopNodeName"));

		// For each provider...
		for (Provider provider : Security.getProviders())
		{
			// Create a node with the provider name and add it as a child of the top node
			DefaultMutableTreeNode providerNode = new DefaultMutableTreeNode(provider.getName());
			topNode.add(providerNode);

			// Add child nodes to the provider node for provider description and version
			providerNode.add(new DefaultMutableTreeNode(provider.getInfo()));
			providerNode.add(new DefaultMutableTreeNode("" + provider.getVersion()));

			// Create another child node called properties and...
			DefaultMutableTreeNode providerPropertiesNode =
			    new DefaultMutableTreeNode(RB.getString("DProviderInfo.ProviderProperties"));
			providerNode.add(providerPropertiesNode);

			// ...add property child nodes to it. Use a TreeSet for sorting the properties.
			for (Object o : new TreeSet<>(provider.keySet()))
			{

// the provider key the object the key of the provider
				String sKey = String.valueOf(o);
				String sValue = provider.getProperty(sKey);
				providerPropertiesNode.add(new DefaultMutableTreeNode(
				    MessageFormat.format(RB.getString("DProviderInfo.ProviderProperty"), sKey, sValue)));
			}
		}

		return topNode;
	}

}