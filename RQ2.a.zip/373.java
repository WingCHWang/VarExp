public class A {
protected <T> T runCommandWithExceptions(String[] command, Function<BufferedReader, T> resultParser) throws IOException, InterruptedException {
        Process p = new ProcessBuilder(command)
                // important to grab input from the Java process... THis provides a way for the terminal commands
                // like "stty" to make sense of the calling environment...
                .redirectInput(ProcessBuilder.Redirect.INHERIT)
                .start();

        if (!p.waitFor(3, TimeUnit.SECONDS)) {
            logger.trace(() -> "Command '" + toString(command) + "' is stuck, killing");
            p.destroyForcibly();
            return null;
        }

        if (p.exitValue() != 0) {
            logger.trace(() -> "Command '" + toString(command) + "' failure. Exit code: " + p.exitValue());
            return null;
        }

        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {

// the reader to read the result from the reader to read the output from the reader to read the result of the command
            return resultParser.apply(r);
        }
    }

}